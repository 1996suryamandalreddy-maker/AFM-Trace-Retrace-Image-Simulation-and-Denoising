"""Wire the real RK45 driven-cantilever solver into the descriptor-aligned notebook.

Patches four cells in `Descriptor-aligned DT-SPM framework.ipynb`:

- Cell 4  : UserInputs defaults aligned with the calibration-grating cantilever
            (k = 3 N/m, f0 = 75 kHz, Q_air = 200) — the parameters that the FD
            calibration was actually performed against.
- Cell 10 : new `load_FD_fit_results()` + `analytic_FD_real()` that drive
            `simulate_curve_rk45_extended_python` with the persisted fitted
            parameters from `output/fd_calibration_cali_fd_results.joblib`;
            `analytic_FD_TierA` becomes a thin alias for backward compatibility.
- Cell 35 : FDPriorPINN delegates to the real analytic solver and freezes the
            analytic backbone (the RK45 solver is non-differentiable, so the
            analytic baseline is pre-computed once per drive and stored as a
            non-trainable buffer; the PINN learns only the sparse correction).
- Cell 36 : training loop pre-computes the analytic baseline on the FD library
            drives once, then trains only the correction MLP.  ODE residual and
            sparsity terms behave identically to before.

Run once after editing:
    python codes/_patch_real_analytic_FD.py
"""
import json
from pathlib import Path

NB_PATH = (Path(__file__).resolve().parents[1]
            / 'Descriptor-aligned DT-SPM framework.ipynb')


def _set(nb, idx, source_text):
    nb['cells'][idx]['source'] = source_text.splitlines(keepends=True)
    nb['cells'][idx]['outputs'] = []
    nb['cells'][idx]['execution_count'] = None


CELL_4 = '''@dataclass
class UserInputs:
    """Inputs the user supplies (separately measured); the framework treats these as constants.

    PATCH: defaults are now aligned with the cantilever used to acquire the cali_fd
    FD library and the calibration-grating scan archive.  The previous defaults
    (k = 25 N/m, f0 = 300 kHz, Q = 250) corresponded to a Tap300 cantilever; the
    cali_fd dataset was acquired with a softer probe (k = 3 N/m, f0 = 75 kHz,
    Q_air = 200) and the FD calibration results in
    `output/fd_calibration_cali_fd_results.joblib` were fit against those.
    Override the defaults at instantiation time to use a different probe.
    """
    # Cantilever / probe
    k_NperM:        float = 3.0     # cantilever stiffness, Sader / thermal calibration
    f0_Hz:          float = 75_000  # free-air resonance frequency (thermal spectrum)
    Q_air:          float = 200.0   # free-air Q factor (thermal spectrum)
    tip_radius_nm:  float = 10.0    # nominal tip radius (SEM or vendor)
    tip_half_angle_deg: float = 18.0
    # Detector / piezo calibration
    InvOLS_nm_per_V: float = 50.0   # optical-lever inverse sensitivity
    drive_V_to_nm:   float = 1.0    # piezo drive calibration
    # Sample priors (optional)
    sample_E_GPa:   Optional[float] = None     # substrate Young's modulus
    # Provenance
    cantilever_id:  str = 'cali_fd_probe'
    sample_id:      str = 'calibration_grating'

    def __post_init__(self):
        assert 0.1 <= self.k_NperM <= 1000.0
        assert 1e4 <= self.f0_Hz <= 5e6
        assert 5.0  <= self.Q_air <= 5_000.0
        assert 0.5  <= self.tip_radius_nm <= 200.0
        assert 0.1  <= self.InvOLS_nm_per_V <= 500.0

USER = UserInputs()
print(json.dumps(asdict(USER), indent=2))
'''


CELL_10 = '''# Stage-1 analytic prior: the real RK45 driven-cantilever solver from
# `codes/spm_fd_rk45_extended_calibration.py`, driven by the fitted parameters
# persisted in `output/fd_calibration_cali_fd_results.joblib` (the output of
# `FD_calibration_cali_fd_v2.ipynb`).
#
# PATCH NOTES
# -----------
# Earlier versions of this cell defined `analytic_FD_TierA` as a tanh ramp.
# That placeholder was useful for wiring the descriptor extraction, the PINN
# loss, the correction-surface plot, etc., but it could not converge against
# the experimental FD descriptors — the PINN training history showed the
# descriptor loss stuck at ~1e7 and the correction surface saturated uniformly
# across (d, V).  The placeholder is now replaced by a thin wrapper around the
# real RK45 solver.  The cantilever physics parameters (Q_contact, C1, C2, a0,
# C3 per curve, drive/phase offsets) are loaded once from the persisted FD fit;
# the analytic baseline is therefore *fixed* during PINN training (the RK45
# solver is non-differentiable in PyTorch) and the PINN learns only the
# residual ΔA(d, V), Δφ(d, V) needed to absorb sample-specific physics that
# the analytic model does not contain.

from joblib import load as _jload
from codes.spm_fd_rk45_extended_calibration import (
    simulate_curve_rk45_extended_python,
    transform_phase_deg,
    estimate_phase_offset_far_field,
)

_FD_FIT_PATH = PROJECT_ROOT / 'output' / 'fd_calibration_cali_fd_results.joblib'

def load_FD_fit_results(path=_FD_FIT_PATH):
    """Load the persisted FD calibration fit (output of FD_calibration_cali_fd_v2)."""
    d = _jload(str(path))
    return dict(
        p_glob       = d.get('p_glob_D') or d.get('p_glob_C') or d.get('p_glob'),
        conv_L       = float(d['conv_L']),
        curves_train = d['curves_train'],
        sel_train    = d['sel_train'],          # indices of training curves in curves_app_sub
        curves_app_sub = d['curves_app_sub'],   # all 15 preprocessed curves
        rk45_plot    = d['rk45_plot_options'],
        phase_mode   = d.get('PHASE_MODE', 'raw'),
    )

FD_FIT = load_FD_fit_results()
print('FD calibration fit loaded:')
print(f'  conv_L          = {FD_FIT["conv_L"]:.5g}')
print(f'  shared params   : C1={FD_FIT["p_glob"]["C1"]:.3g}, C2={FD_FIT["p_glob"]["C2"]:.3g}, a0={FD_FIT["p_glob"]["a0"]:.3g}, Q={FD_FIT["p_glob"]["Q"]:.1f}')
print(f'  fitted on       : {len(FD_FIT["sel_train"])} training curves, indices {list(FD_FIT["sel_train"])}')

_OMEGA_BASE = 1.0 + float(FD_FIT['p_glob']['domega'])


def _nearest_train_curve_idx(V_nm: float) -> int:
    """Return the index into FD_FIT['p_glob']['C3'] / d_off / p_off whose training
    curve drive is nearest to the requested drive V_nm.  These per-curve nuisance
    arrays are length len(sel_train); we interpolate on the training drives.
    """
    train_drives = np.array(
        [FD_FIT['curves_app_sub'][k]['drive_nm'] for k in FD_FIT['sel_train']],
        float)
    return int(np.argmin(np.abs(train_drives - V_nm)))


def analytic_FD_real(d_grid_nm, V_nm, *, user: UserInputs,
                       params: Stage1FittingParameters = None):
    """Real Tier-A analytic prior: RK45 driven-cantilever simulator driven by the
    fitted parameters from `output/fd_calibration_cali_fd_results.joblib`.

    Parameters
    ----------
    d_grid_nm : 1-D array
        Tip-sample distance grid in nm at which (A, phi) are evaluated.
    V_nm : float
        Drive amplitude in nm (free-air amplitude).
    user : UserInputs
        Provides k, f0, Q_air for diagnostic reporting (the fitted parameters
        already encode the cantilever physics; user inputs are sanity checks).
    params : Stage1FittingParameters, optional
        Currently unused — the RK45 fit is the source of truth.  Reserved for
        future swapping between Tier B (two-mode) and Tier C (noise channel)
        analytic priors.

    Returns
    -------
    A_nm : array of same shape as d_grid_nm — steady-state amplitude in nm
    phi_deg : array of same shape — steady-state phase in degrees
    """
    pg = FD_FIT['p_glob']; conv_L = FD_FIT['conv_L']
    # convert nm -> hat
    d_hat = np.asarray(d_grid_nm, float).ravel() * conv_L
    k = _nearest_train_curve_idx(float(V_nm))
    A_sim_hat, phi_sim_deg, *_ = simulate_curve_rk45_extended_python(
        d_hat,
        C1=pg['C1'], C2=pg['C2'], a0=pg['a0'], Q=pg['Q'],
        C3=pg['C3'][k],
        omega_drive_hat=_OMEGA_BASE, omega_ref_hat=_OMEGA_BASE,
        d_offset_hat=pg['d_off'][k],
        w_contact=pg['w_contact'], gamma_lr=pg['gamma_lr'],
        lambda_lr=pg['lambda_lr'], gamma_contact=pg['gamma_contact'],
        **FD_FIT['rk45_plot'],
    )
    phi_use = transform_phase_deg(phi_sim_deg, mode=FD_FIT['phase_mode'])
    # Reference curve for phase alignment: use the nearest training curve's
    # measured phase so the absolute reference matches what `extract_stage1`
    # expects on the experimental data.
    curve = FD_FIT['curves_app_sub'][FD_FIT['sel_train'][k]]
    phi_auto = estimate_phase_offset_far_field(
        phi_use, curve['phi_deg'], curve['d_hat'], frac=0.15, period_deg=360.0)
    phi_use = phi_use + phi_auto + pg['p_off'][k]
    # Convert hat -> nm for amplitude
    A_nm = A_sim_hat / conv_L
    return A_nm, phi_use


# Backward-compatible alias so the rest of the notebook (and any external scripts)
# keep working without code changes.
def analytic_FD_TierA(d_grid, V, *, user: UserInputs, params: Stage1FittingParameters):
    """Backward-compatible alias for analytic_FD_real (signature preserved)."""
    return analytic_FD_real(d_grid, V, user=user, params=params)


# Initialize Stage-1 parameters from the loaded FD fit.  These are now mostly
# diagnostic — they no longer drive the analytic model; the analytic model is
# the persisted fitted simulator.
pg = FD_FIT['p_glob']
init_params = Stage1FittingParameters(
    omega0_offset=float(pg['domega']),
    Q_contact=float(pg['Q']),
    C1=float(pg['C1']), C2=float(pg['C2']),
    C3_global=float(np.nanmean(pg['C3'])),
    Estar_GPa=50.0,
    d0_nm=float(np.nanmedian([d.d_contact for d in fd_desc_exp if np.isfinite(d.d_contact)])),
)
print('Initial Stage-1 fitting parameters (from persisted FD fit):')
print(init_params)

# Re-evaluate the analytic prior on every FD library drive — sim descriptors now
# come from the real RK45 simulator.
fd_desc_sim_init = []
for i, V in enumerate(fd_drive_nm):
    A_sim, phi_sim = analytic_FD_real(fd_height[i], V, user=USER)
    fd_desc_sim_init.append(extract_stage1(fd_height[i], A_sim, phi_sim))
fd_desc_df_sim = pd.DataFrame([asdict(d) for d in fd_desc_sim_init])
fd_desc_df_sim['drive_nm'] = fd_drive_nm
print('\\nReal-analytic-prior sim descriptors:')
fd_desc_df_sim.round(2)
'''


CELL_35 = '''# Optional: PyTorch required.  Comment out the cell if you only want the descriptor analysis above.
try:
    import torch, torch.nn as nn
    TORCH_OK = True
except Exception as e:
    print('PyTorch not available — PINN section skipped'); TORCH_OK = False

if TORCH_OK:
    class FDPriorPINN(nn.Module):
        """Analytic prior (frozen) + sparse NN correction.

        PATCH: the analytic baseline is now produced by the real RK45 solver in
        `analytic_FD_real` rather than by the previous tanh placeholder.  Because
        the RK45 solver is not differentiable in PyTorch, the analytic output is
        evaluated *outside* the autograd graph and stored as a non-trainable
        buffer; the PINN learns only the residual ΔA(d, V), Δφ(d, V) on top of
        the frozen analytic baseline.  This is the standard PINN-as-overlay
        pattern: the physical interpretability of the analytic parameters is
        preserved (no gradient updates on Q, C1, C2 …), and the network is
        forced to be sparse so it only fires where the analytic prior is wrong.
        """
        def __init__(self, user: UserInputs, hidden=64, depth=3):
            super().__init__()
            # Bookkeeping only — the analytic baseline is precomputed in the
            # training cell and registered as a buffer.
            self._user = user
            # Correction MLP
            layers, in_dim = [], 2
            for _ in range(depth):
                layers += [nn.Linear(in_dim, hidden), nn.Tanh()]; in_dim = hidden
            layers += [nn.Linear(in_dim, 2)]
            self.correction = nn.Sequential(*layers)
            for m in self.correction:
                if isinstance(m, nn.Linear):
                    nn.init.normal_(m.weight, std=1e-3); nn.init.zeros_(m.bias)

        def forward(self, d, V, *, A_analytic_buffer, phi_analytic_buffer):
            """Add a learned correction on top of the precomputed analytic baseline.

            A_analytic_buffer, phi_analytic_buffer : torch tensors of shape (N_curve, N_pt)
                Evaluated once outside the autograd graph in the training cell.
            """
            delta = self.correction(torch.stack([d, V], dim=-1))
            return A_analytic_buffer + delta[..., 0], phi_analytic_buffer + delta[..., 1]

    def soft_argmin(values, beta=20.0):
        w = torch.softmax(-beta * values.abs(), dim=-1)
        idx_grid = torch.arange(values.shape[-1], device=values.device, dtype=values.dtype)
        return (w * idx_grid).sum(dim=-1)

    def differentiable_stage1(A, phi, d, contact_frac=0.2):
        A0   = A[..., -10:].mean(dim=-1)
        idx  = soft_argmin(phi - 90.0)
        gather = lambda t, i: (t * torch.softmax(-20.0 * (
            torch.arange(t.shape[-1], device=t.device, dtype=t.dtype) - i.unsqueeze(-1)).abs(),
            dim=-1)).sum(dim=-1)
        d_AR = gather(d, idx); A_AR = gather(A, idx)
        target = contact_frac * A0
        idx_c = soft_argmin(A - target.unsqueeze(-1))
        d_c  = gather(d, idx_c)
        i4 = (idx_c + 4).clamp(max=A.shape[-1] - 1.0)
        slope_c = -(gather(A, i4) - gather(A, idx_c)) / 4.0
        return A0, d_AR, A_AR, d_c, slope_c

    def descriptor_loss(A, phi, d, target):
        sim = torch.stack(differentiable_stage1(A, phi, d)[:4], dim=-1)
        scale_t = target.std(dim=0, unbiased=False).clamp(min=1e-3)
        return ((sim - target[:, :4]) / scale_t[None, :4]).pow(2).mean()

    def ODE_residual(A, phi, d, V, model):
        """Finite-difference proxy for the cantilever EOM residual on the corrected
        (A, phi).  The analytic baseline already satisfies the EOM by construction;
        this term keeps the PINN correction from blowing up curvature.
        """
        dAdd = (A[..., 2:] - A[..., :-2]) / (d[..., 2:] - d[..., :-2] + 1e-9)
        dphi_dd = (phi[..., 2:] - phi[..., :-2]) / (d[..., 2:] - d[..., :-2] + 1e-9)
        return (dAdd ** 2 + 0.01 * dphi_dd ** 2).mean()

    print('FDPriorPINN now uses the frozen real analytic prior + correction overlay.')
'''


CELL_36 = '''if TORCH_OK:
    import time as _time

    # Prepare training tensors -------------------------------------------------
    n_curve = fd_amp.shape[0]
    d_T   = torch.tensor(fd_height, dtype=torch.float32)
    A_T   = torch.tensor(fd_amp,    dtype=torch.float32)
    phi_T = torch.tensor(fd_phase,  dtype=torch.float32)
    V_T   = torch.tensor(fd_drive_nm, dtype=torch.float32).unsqueeze(-1).expand_as(d_T)

    target = torch.tensor(
        np.stack([fd_desc_df_exp['A0'].to_numpy(float),
                   fd_desc_df_exp['d_AR'].to_numpy(float),
                   fd_desc_df_exp['A_AR'].to_numpy(float),
                   fd_desc_df_exp['d_contact'].to_numpy(float)], axis=-1),
        dtype=torch.float32,
    )
    target = torch.nan_to_num(target, nan=0.0)

    # PATCH: pre-compute the analytic baseline on every FD library drive using
    # the real RK45 solver, OUTSIDE the autograd graph.  Stored as buffers; the
    # PINN learns only the residual on top.
    print('Pre-computing analytic baseline on FD library drives ...')
    t0 = _time.time()
    A_baseline = np.zeros_like(fd_amp, dtype=float)
    phi_baseline = np.zeros_like(fd_phase, dtype=float)
    for i, V in enumerate(fd_drive_nm):
        A_b, phi_b = analytic_FD_real(fd_height[i], float(V), user=USER)
        A_baseline[i]  = A_b
        phi_baseline[i] = phi_b
    A_base_T   = torch.tensor(A_baseline, dtype=torch.float32)
    phi_base_T = torch.tensor(phi_baseline, dtype=torch.float32)
    print(f'  done in {_time.time()-t0:.1f}s')

    model = FDPriorPINN(USER)
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    LAMBDA_R, LAMBDA_S = 1e-3, 1e-4

    history = []
    N_EPOCH_DEMO = 500    # raise to 5000+ for production runs
    for epoch in range(N_EPOCH_DEMO):
        A_sim, phi_sim = model(d_T, V_T,
                                 A_analytic_buffer=A_base_T,
                                 phi_analytic_buffer=phi_base_T)
        L_d = descriptor_loss(A_sim, phi_sim, d_T, target)
        L_R = ODE_residual(A_sim, phi_sim, d_T, V_T, model)
        L_s = sum(p.abs().sum() for p in model.correction.parameters())
        loss = L_d + LAMBDA_R * L_R + LAMBDA_S * L_s
        opt.zero_grad(); loss.backward(); opt.step()
        history.append((float(loss), float(L_d), float(L_R), float(L_s)))
    history = np.array(history)
    print(f'After {N_EPOCH_DEMO} epochs:  L_total={history[-1,0]:.4f}  L_desc={history[-1,1]:.4f}  L_sparse={history[-1,3]:.2f}')

    fig, ax = plt.subplots(figsize=(7.0, 3.0), constrained_layout=True)
    ax.semilogy(history[:,0], color='k',  label='total')
    ax.semilogy(history[:,1], color=PALETTE['PI'], label='descriptor')
    ax.semilogy(history[:,2], color=PALETTE['hybrid'], label='ODE residual')
    ax.semilogy(history[:,3], color=PALETTE['data-driven'], label='sparsity')
    ax.set_xlabel('epoch'); ax.set_ylabel('loss')
    ax.set_title(f'PINN training history (real analytic prior, {N_EPOCH_DEMO} epochs)')
    ax.legend(frameon=False, fontsize=8)
    fig.savefig(FIG_DIR / 'pinn_training_history.png')
'''


CELL_37 = '''if TORCH_OK:
    # Visualise the learned PINN correction surface on a dense (d, V) grid.
    # PATCH: the correction is now the residual on top of the *real* analytic
    # baseline.  If the baseline already captures the physics, the correction
    # should be small (sparsity-penalised) and concentrated at the (d, V)
    # coordinates where the analytic model is structurally inadequate.
    with torch.no_grad():
        d_grid = torch.linspace(0, float(fd_height.max()), 80)
        V_grid = torch.linspace(float(fd_drive_nm.min()), float(fd_drive_nm.max()), 50)
        D, V = torch.meshgrid(d_grid, V_grid, indexing='ij')
        delta = model.correction(torch.stack([D.flatten(), V.flatten()], dim=-1))
        dA  = delta[..., 0].reshape(D.shape).numpy()
        dphi= delta[..., 1].reshape(D.shape).numpy()
    fig, axes = plt.subplots(1, 2, figsize=(10.0, 3.6), constrained_layout=True)
    for ax, surf, label in [(axes[0], dA, 'ΔA (nm)'), (axes[1], dphi, 'Δφ (deg)')]:
        vmax = float(np.nanmax(np.abs(surf))) if np.isfinite(np.nanmax(np.abs(surf))) else 1.0
        if vmax < 1e-6: vmax = 1e-6
        im = ax.pcolormesh(V_grid.numpy(), d_grid.numpy(), surf, shading='auto', cmap='RdBu_r',
                            vmin=-vmax, vmax=vmax)
        fig.colorbar(im, ax=ax, label=label)
        ax.set_xlabel('drive (nm)'); ax.set_ylabel('distance (nm)')
        ax.set_title(f'PINN correction surface — {label}')
    fig.suptitle('Section 9 — PINN correction on top of the real analytic prior',
                  fontsize=11, fontweight='bold')
    fig.savefig(FIG_DIR / 'pinn_correction_surface.png')
'''


def main():
    nb = json.load(open(NB_PATH))
    _set(nb, 4,  CELL_4)
    _set(nb, 10, CELL_10)
    _set(nb, 35, CELL_35)
    _set(nb, 36, CELL_36)
    _set(nb, 37, CELL_37)
    json.dump(nb, open(NB_PATH, 'w'), indent=1)
    print('Patched cells 4, 10, 35, 36, 37.')


if __name__ == '__main__':
    main()
