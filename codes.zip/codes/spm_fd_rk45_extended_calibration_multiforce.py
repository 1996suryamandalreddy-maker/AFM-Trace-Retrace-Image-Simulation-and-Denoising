"""
spm_fd_rk45_extended_calibration.py

Full RK45-based calibration utilities for SPM approach/FD curves.

Main workflow
-------------
1. Fit individual FD curves with the RK45 steady-state solver:
       individual_fits = fit_individual_fd_curves_rk45(...)

2. Fit all curves jointly with shared physics and smooth drive-dependent C3:
       global_fit = fit_global_drive_dependent_C3_extended_rk45(...)

Physics included
----------------
- Smoothed DMT-like conservative tip-sample force
- Distance-dependent long-range and contact damping
- Adaptive Dormand-Prince RK45 integration
- Windowed lock-in demodulation
- Global drive-frequency detuning
- Smooth C3(drive) calibration
- Per-curve distance offsets
- Automatic far-field phase alignment
- Optional per-curve residual phase offsets
- Optional amplitude-dependent phase weighting
- Optional measurement-chain low-pass filtering along approach direction

Expected curve format
---------------------
Each curve is a dict:
    {
        "drive_nm": float,
        "d_hat": np.ndarray,      # normalized height/gap coordinate
        "A_hat": np.ndarray,      # normalized amplitude
        "phi_deg": np.ndarray,    # measured phase in degrees
        "A0_hat": float,          # normalized far-field amplitude
        "omega_drive_hat": float, # optional, default 1.0
        "omega_ref_hat": float,   # optional, default omega_drive_hat
    }

If your input arrays are in nm, use build_measured_fd_curves(..., conv_L=...).
If you are already in normalized units, set conv_L=1.0.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple
import numpy as np
import matplotlib.pyplot as plt

from numba import njit
from scipy.optimize import least_squares
from scipy.sparse import lil_matrix


# =============================================================================
# 0. Phase and filtering utilities
# =============================================================================

def angle_diff_period_deg(a, b, period_deg: float = 360.0):
    """
    Circular difference a - b in degrees.

    period_deg=360 for normal phase.
    period_deg=180 if your lock-in phase is folded into [0, 180].
    """
    p = float(period_deg)
    return (np.asarray(a) - np.asarray(b) + 0.5 * p) % p - 0.5 * p


def circular_mean_period_deg(phi_deg, period_deg: float = 360.0):
    """
    Circular mean for an angle with arbitrary period.
    """
    p = float(period_deg)
    theta = 2.0 * np.pi * np.asarray(phi_deg, dtype=float) / p
    s = np.nanmean(np.sin(theta))
    c = np.nanmean(np.cos(theta))
    mean_theta = np.arctan2(s, c)
    return (p * mean_theta / (2.0 * np.pi)) % p


def far_field_indices(d_hat, frac: float = 0.15):
    """
    Indices corresponding to the largest-distance part of the approach curve.
    """
    d_hat = np.asarray(d_hat, dtype=float)
    n_far = max(3, int(frac * len(d_hat)))
    return np.argsort(d_hat)[::-1][:n_far]


def estimate_phase_offset_far_field(
    phi_sim,
    phi_exp,
    d_hat,
    frac: float = 0.15,
    period_deg: float = 360.0,
):
    """
    Offset to add to phi_sim so its far-field phase matches experiment.
    """
    idx = far_field_indices(d_hat, frac=frac)
    diff = angle_diff_period_deg(phi_exp[idx], phi_sim[idx], period_deg=period_deg)
    return circular_mean_period_deg(diff, period_deg=period_deg)


def transform_phase_deg(phi_deg, mode: str = "raw"):
    """
    Try different lock-in phase conventions.

    Common options:
        raw
        neg
        plus180
        minus_from_180
        minus_from_360
    """
    phi_deg = np.asarray(phi_deg, dtype=float)

    if mode == "raw":
        return phi_deg
    if mode == "neg":
        return -phi_deg
    if mode == "plus180":
        return phi_deg + 180.0
    if mode == "minus_from_180":
        return 180.0 - phi_deg
    if mode == "minus_from_360":
        return 360.0 - phi_deg

    raise ValueError(f"Unknown phase mode: {mode}")


def lowpass_real_by_d(y, d_hat, alpha: Optional[float]):
    """
    First-order low-pass filtering along approach direction, from far to near.

    alpha=1 or None means no filtering.
    Smaller alpha gives stronger lag/smoothing.
    """
    y = np.asarray(y, dtype=float)
    if alpha is None or alpha >= 1.0:
        return y.copy()

    alpha = float(np.clip(alpha, 1e-8, 1.0))
    order = np.argsort(np.asarray(d_hat, dtype=float))[::-1]

    y_sorted = y[order]
    out_sorted = np.empty_like(y_sorted)
    out_sorted[0] = y_sorted[0]

    for i in range(1, len(y_sorted)):
        out_sorted[i] = out_sorted[i - 1] + alpha * (y_sorted[i] - out_sorted[i - 1])

    out = np.empty_like(y)
    out[order] = out_sorted
    return out


def lowpass_phase_by_d(phi_deg, d_hat, alpha: Optional[float], period_deg: float = 360.0):
    """
    Circular first-order low-pass filtering along approach direction.
    """
    phi_deg = np.asarray(phi_deg, dtype=float)
    if alpha is None or alpha >= 1.0:
        return phi_deg.copy()

    alpha = float(np.clip(alpha, 1e-8, 1.0))
    period_deg = float(period_deg)
    order = np.argsort(np.asarray(d_hat, dtype=float))[::-1]

    phi_sorted = phi_deg[order]
    out_sorted = np.empty_like(phi_sorted)
    out_sorted[0] = phi_sorted[0]

    for i in range(1, len(phi_sorted)):
        dphi = angle_diff_period_deg(phi_sorted[i], out_sorted[i - 1], period_deg=period_deg)
        out_sorted[i] = out_sorted[i - 1] + alpha * dphi

    out = np.empty_like(phi_deg)
    out[order] = out_sorted
    return out


def phase_convention_score(
    phi_sim,
    phi_exp,
    d_hat,
    modes=("raw", "neg", "plus180", "minus_from_180", "minus_from_360"),
    far_field_frac: float = 0.15,
    period_deg: float = 360.0,
):
    """
    Diagnostic: compare possible lock-in phase conventions after far-field alignment.
    """
    scores = {}
    for mode in modes:
        phi_try = transform_phase_deg(phi_sim, mode=mode)
        offset = estimate_phase_offset_far_field(
            phi_try, phi_exp, d_hat, frac=far_field_frac, period_deg=period_deg
        )
        phi_aligned = phi_try + offset
        err = angle_diff_period_deg(phi_aligned, phi_exp, period_deg=period_deg)
        scores[mode] = {
            "rmse_deg": float(np.sqrt(np.nanmean(err**2))),
            "offset_deg": float(offset),
        }
    return scores


# =============================================================================
# 1. Input data preparation
# =============================================================================

def build_measured_fd_curves(
    drives_nm,
    height_nm,
    amplitude_nm,
    phase_deg,
    conv_L: float = 1.0,
    A0_method: str = "far_field_median",
    far_field_frac: float = 0.10,
    omega_drive_hat: float = 1.0,
    omega_ref_hat: Optional[float] = None,
):
    """
    Build measured curve dictionaries from arrays.

    Parameters
    ----------
    drives_nm : shape (n_drive,)
    height_nm : shape (n_drive, n_point) or (n_point,)
    amplitude_nm : shape (n_drive, n_point)
    phase_deg : shape (n_drive, n_point)
    conv_L : conversion from nm to normalized length.
             Use scanner.conversion["A"] if you have it.
             Use 1.0 if arrays are already normalized.
    A0_method : "far_field_median" or "drive"
    """
    drives_nm = np.asarray(drives_nm, dtype=float).ravel()
    amplitude_nm = np.asarray(amplitude_nm, dtype=float)
    phase_deg = np.asarray(phase_deg, dtype=float)

    n_drive = len(drives_nm)

    height_nm = np.asarray(height_nm, dtype=float)
    if height_nm.ndim == 1:
        height_nm = np.tile(height_nm[None, :], (n_drive, 1))

    if amplitude_nm.shape != height_nm.shape:
        raise ValueError(
            f"amplitude_nm shape {amplitude_nm.shape} does not match "
            f"height_nm shape {height_nm.shape}"
        )

    if phase_deg.shape != height_nm.shape:
        raise ValueError(
            f"phase_deg shape {phase_deg.shape} does not match "
            f"height_nm shape {height_nm.shape}"
        )

    if omega_ref_hat is None:
        omega_ref_hat = omega_drive_hat

    curves = []

    for j, drive in enumerate(drives_nm):
        d_nm = height_nm[j].astype(float).ravel()
        A_nm = amplitude_nm[j].astype(float).ravel()
        phi = phase_deg[j].astype(float).ravel()

        mask = np.isfinite(d_nm) & np.isfinite(A_nm) & np.isfinite(phi)
        d_nm = d_nm[mask]
        A_nm = A_nm[mask]
        phi = phi[mask]

        if d_nm.size < 8:
            raise ValueError(f"Drive {drive}: too few finite points.")

        if A0_method == "far_field_median":
            n_far = max(2, int(far_field_frac * d_nm.size))
            far_idx = np.argsort(d_nm)[::-1][:n_far]
            A0_nm = float(np.median(A_nm[far_idx]))
        elif A0_method == "drive":
            A0_nm = float(drive)
        else:
            raise ValueError("A0_method must be 'far_field_median' or 'drive'.")

        curves.append(
            {
                "drive_nm": float(drive),
                "d_hat": d_nm * conv_L,
                "A_hat": A_nm * conv_L,
                "phi_deg": phi,
                "A0_hat": A0_nm * conv_L,
                "omega_drive_hat": float(omega_drive_hat),
                "omega_ref_hat": float(omega_ref_hat),
            }
        )

    return curves


def build_measured_fd_curves_from_dict(
    measured_fd: Dict[float, Dict[str, np.ndarray]],
    conv_L: float = 1.0,
    A0_method: str = "far_field_median",
    far_field_frac: float = 0.10,
    omega_drive_hat: float = 1.0,
    omega_ref_hat: Optional[float] = None,
):
    """
    Input format:
        measured_fd = {
            20.0: {"d": h20, "A": A20, "phi": phi20},
            30.0: {"d": h30, "A": A30, "phi": phi30},
            ...
        }
    """
    drives = sorted([float(k) for k in measured_fd.keys()])

    height = []
    amp = []
    phase = []

    for d0 in drives:
        c = measured_fd[d0]
        height.append(np.asarray(c["d"], dtype=float))
        amp.append(np.asarray(c["A"], dtype=float))
        phase.append(np.asarray(c["phi"], dtype=float))

    return build_measured_fd_curves(
        np.asarray(drives),
        np.asarray(height),
        np.asarray(amp),
        np.asarray(phase),
        conv_L=conv_L,
        A0_method=A0_method,
        far_field_frac=far_field_frac,
        omega_drive_hat=omega_drive_hat,
        omega_ref_hat=omega_ref_hat,
    )


# =============================================================================
# 2. Numba RK45 solver: smoothed DMT + distance-dependent damping
# =============================================================================

@njit(cache=True)
def angle_diff_period_deg_numba(a, b, period_deg):
    return (a - b + 0.5 * period_deg) % period_deg - 0.5 * period_deg


@njit(cache=True)
def smooth_relu_numba(x, w):
    """
    Smooth approximation to max(x, 0).
    """
    return 0.5 * (x + np.sqrt(x * x + w * w))


@njit(cache=True)
def F_DMT_smooth_hat(delta_hat, C1, C2, a0, w_contact):
    """
    Smoothed DMT-like force.

    Convention:
        delta_hat > 0 : non-contact gap
        delta_hat < 0 : indentation/contact

    Force:
        attraction = -C1 / (gap + a0)^2
        repulsion  =  C2 * indentation^1.5
    """
    gap = smooth_relu_numba(delta_hat, w_contact)
    indentation = smooth_relu_numba(-delta_hat, w_contact)

    F_attr = -C1 / (gap + a0) ** 2
    F_rep = C2 * indentation ** 1.5

    return F_attr + F_rep


@njit(cache=True)
def gamma_ts_hat(delta_hat, gamma_lr, lambda_lr, gamma_contact, w_contact):
    """
    Distance-dependent extra damping.

    gamma_lr:
        long-range damping that decays with positive gap.

    gamma_contact:
        additional damping in contact/intermittent-contact regime.
    """
    gap = smooth_relu_numba(delta_hat, w_contact)
    indentation = smooth_relu_numba(-delta_hat, w_contact)

    gamma_long = gamma_lr * np.exp(-gap / lambda_lr)

    contact_gate = indentation / (indentation + w_contact + 1e-12)
    gamma_cont = gamma_contact * contact_gate

    return gamma_long + gamma_cont


@njit(cache=True)
def rhs_hat_extended(
    t_hat,
    z_hat,
    v_hat,
    d_hat,
    Q,
    C1,
    C2,
    C3,
    a0,
    omega_drive_hat,
    w_contact,
    gamma_lr,
    lambda_lr,
    gamma_contact,
):
    """
    Extended normalized oscillator RHS.

    dz/dt = v
    dv/dt = F_cons + F_drive - [1/Q + gamma_ts(delta)] v - z
    """
    delta_hat = z_hat + d_hat

    F_contact = F_DMT_smooth_hat(
        delta_hat, C1, C2, a0, w_contact
    )

    F_drive = -C3 * np.cos(omega_drive_hat * t_hat)

    damping = 1.0 / Q + gamma_ts_hat(
        delta_hat, gamma_lr, lambda_lr, gamma_contact, w_contact
    )

    dz = v_hat
    dv = F_contact + F_drive - damping * v_hat - z_hat

    return dz, dv


@njit(cache=True)
def rk45_step_dopri_extended(
    t,
    z,
    v,
    dt,
    d_hat,
    Q,
    C1,
    C2,
    C3,
    a0,
    omega_drive_hat,
    w_contact,
    gamma_lr,
    lambda_lr,
    gamma_contact,
    rtol,
    atol,
):
    """
    One adaptive Dormand-Prince RK45 step with scalar error estimate.

    This is the RK45 version of the extended RHS.
    """
    c2 = 1.0 / 5.0
    c3 = 3.0 / 10.0
    c4 = 4.0 / 5.0
    c5 = 8.0 / 9.0
    c6 = 1.0

    a21 = 1.0 / 5.0

    a31 = 3.0 / 40.0
    a32 = 9.0 / 40.0

    a41 = 44.0 / 45.0
    a42 = -56.0 / 15.0
    a43 = 32.0 / 9.0

    a51 = 19372.0 / 6561.0
    a52 = -25360.0 / 2187.0
    a53 = 64448.0 / 6561.0
    a54 = -212.0 / 729.0

    a61 = 9017.0 / 3168.0
    a62 = -355.0 / 33.0
    a63 = 46732.0 / 5247.0
    a64 = 49.0 / 176.0
    a65 = -5103.0 / 18656.0

    b1 = 35.0 / 384.0
    b3 = 500.0 / 1113.0
    b4 = 125.0 / 192.0
    b5 = -2187.0 / 6784.0
    b6 = 11.0 / 84.0

    b1s = 5179.0 / 57600.0
    b3s = 7571.0 / 16695.0
    b4s = 393.0 / 640.0
    b5s = -92097.0 / 339200.0
    b6s = 187.0 / 2100.0
    b7s = 1.0 / 40.0

    dz1, dv1 = rhs_hat_extended(
        t, z, v, d_hat, Q, C1, C2, C3, a0, omega_drive_hat,
        w_contact, gamma_lr, lambda_lr, gamma_contact
    )

    z2 = z + dt * a21 * dz1
    v2 = v + dt * a21 * dv1
    dz2, dv2 = rhs_hat_extended(
        t + c2 * dt, z2, v2, d_hat, Q, C1, C2, C3, a0, omega_drive_hat,
        w_contact, gamma_lr, lambda_lr, gamma_contact
    )

    z3 = z + dt * (a31 * dz1 + a32 * dz2)
    v3 = v + dt * (a31 * dv1 + a32 * dv2)
    dz3, dv3 = rhs_hat_extended(
        t + c3 * dt, z3, v3, d_hat, Q, C1, C2, C3, a0, omega_drive_hat,
        w_contact, gamma_lr, lambda_lr, gamma_contact
    )

    z4 = z + dt * (a41 * dz1 + a42 * dz2 + a43 * dz3)
    v4 = v + dt * (a41 * dv1 + a42 * dv2 + a43 * dv3)
    dz4, dv4 = rhs_hat_extended(
        t + c4 * dt, z4, v4, d_hat, Q, C1, C2, C3, a0, omega_drive_hat,
        w_contact, gamma_lr, lambda_lr, gamma_contact
    )

    z5i = z + dt * (a51 * dz1 + a52 * dz2 + a53 * dz3 + a54 * dz4)
    v5i = v + dt * (a51 * dv1 + a52 * dv2 + a53 * dv3 + a54 * dv4)
    dz5, dv5 = rhs_hat_extended(
        t + c5 * dt, z5i, v5i, d_hat, Q, C1, C2, C3, a0, omega_drive_hat,
        w_contact, gamma_lr, lambda_lr, gamma_contact
    )

    z6 = z + dt * (a61 * dz1 + a62 * dz2 + a63 * dz3 + a64 * dz4 + a65 * dz5)
    v6 = v + dt * (a61 * dv1 + a62 * dv2 + a63 * dv3 + a64 * dv4 + a65 * dv5)
    dz6, dv6 = rhs_hat_extended(
        t + c6 * dt, z6, v6, d_hat, Q, C1, C2, C3, a0, omega_drive_hat,
        w_contact, gamma_lr, lambda_lr, gamma_contact
    )

    z5 = z + dt * (b1 * dz1 + b3 * dz3 + b4 * dz4 + b5 * dz5 + b6 * dz6)
    v5 = v + dt * (b1 * dv1 + b3 * dv3 + b4 * dv4 + b5 * dv5 + b6 * dv6)

    dz7, dv7 = rhs_hat_extended(
        t + dt, z5, v5, d_hat, Q, C1, C2, C3, a0, omega_drive_hat,
        w_contact, gamma_lr, lambda_lr, gamma_contact
    )

    z4s = z + dt * (b1s * dz1 + b3s * dz3 + b4s * dz4 + b5s * dz5 + b6s * dz6 + b7s * dz7)
    v4s = v + dt * (b1s * dv1 + b3s * dv3 + b4s * dv4 + b5s * dv5 + b6s * dv6 + b7s * dv7)

    ez = z5 - z4s
    ev = v5 - v4s

    sz = atol + rtol * max(abs(z), abs(z5))
    sv = atol + rtol * max(abs(v), abs(v5))
    err = np.sqrt(0.5 * ((ez / sz) ** 2 + (ev / sv) ** 2))

    return z5, v5, err


@njit(cache=True)
def demod_add_segment(X, Y, z0, z1, t0, t1, omega_ref_hat):
    """
    Trapezoidal accumulation of lock-in X/Y components over one segment.
    """
    c0 = np.cos(omega_ref_hat * t0)
    s0 = np.sin(omega_ref_hat * t0)
    c1 = np.cos(omega_ref_hat * t1)
    s1 = np.sin(omega_ref_hat * t1)

    X += 0.5 * (z0 * c0 + z1 * c1) * (t1 - t0)
    Y += 0.5 * (z0 * s0 + z1 * s1) * (t1 - t0)
    return X, Y


@njit(cache=True)
def run_one_window_rk45_extended(
    t_start,
    z_start,
    v_start,
    d_hat,
    Q,
    C1,
    C2,
    C3,
    a0,
    omega_drive_hat,
    omega_ref_hat,
    w_contact,
    gamma_lr,
    lambda_lr,
    gamma_contact,
    T_win,
    demod_dt_hat,
    rtol,
    atol,
    dt0,
    dt_min,
    dt_max,
    max_steps,
):
    """
    Integrate one demodulation window using adaptive RK45.
    """
    t = t_start
    z = z_start
    v = v_start
    t_end = t_start + T_win

    X = 0.0
    Y = 0.0

    if demod_dt_hat <= 0.0:
        demod_dt_hat = T_win

    t_s = t_start
    z_s = z_start
    next_s = t_s + demod_dt_hat

    F0 = F_DMT_smooth_hat(z + d_hat, C1, C2, a0, w_contact)
    F_int = 0.0
    F_min = F0
    F_max = F0

    safety = 0.9
    fac_min = 0.2
    fac_max = 5.0
    p_order = 5.0

    dt = dt0
    steps = 0

    while t < t_end and steps < max_steps:
        if dt < dt_min:
            dt = dt_min
        if dt > dt_max:
            dt = dt_max
        if t + dt > t_end:
            dt = t_end - t

        t_prev = t
        z_prev = z
        F_prev = F_DMT_smooth_hat(z_prev + d_hat, C1, C2, a0, w_contact)

        z_new, v_new, err = rk45_step_dopri_extended(
            t, z, v, dt, d_hat, Q, C1, C2, C3, a0, omega_drive_hat,
            w_contact, gamma_lr, lambda_lr, gamma_contact,
            rtol, atol
        )

        accept = (err <= 1.0) or (dt <= dt_min * 1.0001)
        if accept:
            t = t + dt
            z = z_new
            v = v_new

            F_cur = F_DMT_smooth_hat(z + d_hat, C1, C2, a0, w_contact)
            F_int += 0.5 * (F_prev + F_cur) * (t - t_prev)

            if F_cur < F_min:
                F_min = F_cur
            if F_cur > F_max:
                F_max = F_cur

            while next_s <= t:
                denom = t - t_prev
                if denom <= 0.0:
                    z_b = z
                else:
                    frac = (next_s - t_prev) / denom
                    if frac < 0.0:
                        frac = 0.0
                    elif frac > 1.0:
                        frac = 1.0
                    z_b = z_prev + frac * (z - z_prev)

                X, Y = demod_add_segment(X, Y, z_s, z_b, t_s, next_s, omega_ref_hat)
                t_s = next_s
                z_s = z_b
                next_s = next_s + demod_dt_hat

            steps += 1

        if err == 0.0:
            fac = fac_max
        else:
            fac = safety * (1.0 / err) ** (1.0 / p_order)
            if fac < fac_min:
                fac = fac_min
            elif fac > fac_max:
                fac = fac_max

        dt = dt * fac

    if t_end > t_s:
        X, Y = demod_add_segment(X, Y, z_s, z, t_s, t_end, omega_ref_hat)

    F_mean = F_int / T_win
    return X, Y, F_mean, F_min, F_max, steps, z, v


@njit(cache=True)
def wrap_phase_numba(phi_deg, phase_wrap_mode):
    """
    phase_wrap_mode:
        180 -> fold phase into [0, 180]
        360 -> wrap phase into [0, 360]
    """
    if phase_wrap_mode == 180:
        while phi_deg < 0.0:
            phi_deg += 180.0
        while phi_deg >= 180.0:
            phi_deg -= 180.0
        return phi_deg
    else:
        while phi_deg < 0.0:
            phi_deg += 360.0
        while phi_deg >= 360.0:
            phi_deg -= 360.0
        return phi_deg


@njit(cache=True)
def simulate_steady_state_rk45_extended(
    z0_hat,
    v0_hat,
    d_hat,
    Q,
    C1,
    C2,
    C3,
    a0,
    omega_drive_hat,
    omega_ref_hat,
    w_contact,
    gamma_lr,
    lambda_lr,
    gamma_contact,
    N_cycles,
    max_windows,
    settle_windows,
    tol_A,
    tol_phi_deg,
    consecutive,
    demod_per_ref_cycle,
    rtol,
    atol,
    dt0,
    dt_min,
    dt_max,
    max_steps_per_window,
    phase_wrap_mode,
):
    """
    Run repeated demodulation windows until amplitude/phase convergence.
    """
    T_ref = 2.0 * np.pi / omega_ref_hat
    T_win = N_cycles * T_ref

    if demod_per_ref_cycle < 5:
        demod_per_ref_cycle = 5
    demod_dt_hat = T_ref / demod_per_ref_cycle

    if phase_wrap_mode == 180:
        phase_period = 180.0
    else:
        phase_period = 360.0

    t = 0.0
    z = z0_hat
    v = v0_hat

    last_A = 1e30
    last_phi = 1e30
    stable = 0

    A_last = 0.0
    phi_last = 0.0
    F_mean_last = 0.0
    F_min_last = 0.0
    F_max_last = 0.0

    for widx in range(max_windows):
        X, Y, F_mean, F_min, F_max, _, z, v = run_one_window_rk45_extended(
            t, z, v,
            d_hat, Q, C1, C2, C3, a0,
            omega_drive_hat, omega_ref_hat,
            w_contact, gamma_lr, lambda_lr, gamma_contact,
            T_win, demod_dt_hat,
            rtol, atol, dt0, dt_min, dt_max, max_steps_per_window,
        )
        t = t + T_win

        A = (2.0 / T_win) * np.sqrt(X * X + Y * Y)
        phi = np.degrees(np.arctan2(Y, X))
        phi = wrap_phase_numba(phi, phase_wrap_mode)

        A_last = A
        phi_last = phi
        F_mean_last = F_mean
        F_min_last = F_min
        F_max_last = F_max

        if widx >= settle_windows:
            dA = abs(A - last_A)
            dphi = abs(angle_diff_period_deg_numba(phi, last_phi, phase_period))
            if dA < tol_A and dphi < tol_phi_deg:
                stable += 1
            else:
                stable = 0

            if stable >= consecutive:
                return A, phi, F_mean, F_min, F_max, (widx + 1), z, v

        last_A = A
        last_phi = phi

    return A_last, phi_last, F_mean_last, F_min_last, F_max_last, max_windows, z, v


@njit(cache=True)
def simulate_curve_rk45_extended_numba(
    d_hat_input,
    Q,
    C1,
    C2,
    C3,
    a0,
    omega_drive_hat,
    omega_ref_hat,
    d_offset_hat,
    w_contact,
    gamma_lr,
    lambda_lr,
    gamma_contact,
    N_cycles,
    max_windows,
    settle_windows,
    tol_A,
    tol_phi_deg,
    consecutive,
    demod_per_ref_cycle,
    rtol,
    atol,
    dt0,
    dt_min,
    dt_max,
    max_steps_per_window,
    phase_wrap_mode,
    use_warm_start,
):
    """
    Simulate a full approach curve using the RK45 steady-state solver.

    The returned arrays preserve input order. Internally, the solver goes
    from far to near for stable warm-starting.
    """
    n = d_hat_input.size

    A_out = np.empty(n)
    phi_out = np.empty(n)
    F_mean_out = np.empty(n)
    F_min_out = np.empty(n)
    F_max_out = np.empty(n)
    nwin_out = np.empty(n)

    order = np.argsort(d_hat_input)[::-1]

    z_cur = 0.0
    v_cur = 0.0

    for kk in range(n):
        idx = order[kk]
        d_eff = d_hat_input[idx] + d_offset_hat

        if use_warm_start == 0:
            z0 = 0.0
            v0 = 0.0
        else:
            z0 = z_cur
            v0 = v_cur

        A, phi, F_mean, F_min, F_max, nwin, z_cur, v_cur = simulate_steady_state_rk45_extended(
            z0,
            v0,
            d_eff,
            Q,
            C1,
            C2,
            C3,
            a0,
            omega_drive_hat,
            omega_ref_hat,
            w_contact,
            gamma_lr,
            lambda_lr,
            gamma_contact,
            N_cycles,
            max_windows,
            settle_windows,
            tol_A,
            tol_phi_deg,
            consecutive,
            demod_per_ref_cycle,
            rtol,
            atol,
            dt0,
            dt_min,
            dt_max,
            max_steps_per_window,
            phase_wrap_mode,
        )

        A_out[idx] = A
        phi_out[idx] = phi
        F_mean_out[idx] = F_mean
        F_min_out[idx] = F_min
        F_max_out[idx] = F_max
        nwin_out[idx] = nwin

    return A_out, phi_out, F_mean_out, F_min_out, F_max_out, nwin_out


def simulate_curve_rk45_extended_python(
    d_hat,
    C1,
    C2,
    a0,
    Q,
    C3,
    omega_drive_hat: float = 1.0,
    omega_ref_hat: Optional[float] = None,
    d_offset_hat: float = 0.0,
    w_contact: float = 0.1,
    gamma_lr: float = 1e-4,
    lambda_lr: float = 5.0,
    gamma_contact: float = 1e-3,
    N_cycles: int = 4,
    max_windows: int = 40,
    settle_windows: int = 3,
    tol_A: float = 1e-5,
    tol_phi_deg: float = 0.02,
    consecutive: int = 2,
    demod_per_ref_cycle: int = 48,
    rtol: float = 1e-6,
    atol: float = 1e-8,
    dt0: float = 0.02,
    dt_min: float = 1e-5,
    dt_max: float = 0.15,
    max_steps_per_window: int = 200000,
    phase_wrap_mode: int = 180,
    use_warm_start: bool = True,
    alpha_A: Optional[float] = None,
    alpha_phi: Optional[float] = None,
):
    """
    Python wrapper around the Numba RK45 curve simulator.
    """
    d_hat = np.asarray(d_hat, dtype=float).ravel()

    if omega_ref_hat is None:
        omega_ref_hat = omega_drive_hat

    A_sim, phi_sim, F_mean, F_min, F_max, nwin = simulate_curve_rk45_extended_numba(
        d_hat,
        float(Q),
        float(C1),
        float(C2),
        float(C3),
        float(a0),
        float(omega_drive_hat),
        float(omega_ref_hat),
        float(d_offset_hat),
        float(w_contact),
        float(gamma_lr),
        float(lambda_lr),
        float(gamma_contact),
        int(N_cycles),
        int(max_windows),
        int(settle_windows),
        float(tol_A),
        float(tol_phi_deg),
        int(consecutive),
        int(demod_per_ref_cycle),
        float(rtol),
        float(atol),
        float(dt0),
        float(dt_min),
        float(dt_max),
        int(max_steps_per_window),
        int(phase_wrap_mode),
        int(1 if use_warm_start else 0),
    )

    phase_period = 180.0 if int(phase_wrap_mode) == 180 else 360.0

    if alpha_A is not None:
        A_sim = lowpass_real_by_d(A_sim, d_hat, alpha_A)

    if alpha_phi is not None:
        phi_sim = lowpass_phase_by_d(phi_sim, d_hat, alpha_phi, period_deg=phase_period)

    return A_sim, phi_sim, F_mean, F_min, F_max, nwin


# =============================================================================
# 3. Individual FD curve fitting with RK45
# =============================================================================

def make_single_x0(
    C1: float,
    C2: float,
    a0: float,
    Q: float,
    C3: float,
    d_offset_hat: float = 0.0,
    phi_offset_deg: float = 0.0,
):
    return np.array(
        [
            np.log(C1),
            np.log(C2),
            np.log(a0),
            np.log(Q),
            np.log(C3),
            d_offset_hat,
            phi_offset_deg,
        ],
        dtype=float,
    )


def unpack_single_x(x):
    C1 = np.exp(x[0])
    C2 = np.exp(x[1])
    a0 = np.exp(x[2])
    Q = np.exp(x[3])
    C3 = np.exp(x[4])
    d_offset_hat = x[5]
    phi_offset_deg = x[6]
    return C1, C2, a0, Q, C3, d_offset_hat, phi_offset_deg


def make_single_bounds(
    x0,
    log_decades: float = 3.0,
    max_abs_d_offset_hat: float = np.inf,
    max_abs_phi_offset_deg: float = 180.0,
):
    lower = np.asarray(x0, dtype=float).copy()
    upper = np.asarray(x0, dtype=float).copy()

    lower[:5] -= log_decades * np.log(10.0)
    upper[:5] += log_decades * np.log(10.0)

    lower[5] = -max_abs_d_offset_hat
    upper[5] = +max_abs_d_offset_hat

    lower[6] = -max_abs_phi_offset_deg
    upper[6] = +max_abs_phi_offset_deg

    return lower, upper


def residual_single_curve_rk45(
    x,
    curve,
    fixed_extra=None,
    w_amp: float = 1.0,
    w_phi: float = 0.02,
    phase_mode: str = "raw",
    far_field_phase_align: bool = True,
    far_field_frac: float = 0.15,
    phase_period_deg: float = 180.0,
    use_amp_weighted_phase: bool = True,
    sigma_phi0_deg: float = 8.0,
    A_floor_frac: float = 0.15,
    d_offset_prior_hat: Optional[float] = None,
    phi_offset_prior_deg: Optional[float] = 90.0,
    rk45_options: Optional[Dict] = None,
):
    fixed_extra = dict(fixed_extra or {})
    rk45_options = dict(rk45_options or {})

    C1, C2, a0, Q, C3, d_offset_hat, phi_offset_deg = unpack_single_x(x)

    omega_drive = curve.get("omega_drive_hat", 1.0) * fixed_extra.get("omega_scale", 1.0)
    omega_ref = curve.get("omega_ref_hat", omega_drive)

    A_sim, phi_sim, *_ = simulate_curve_rk45_extended_python(
        curve["d_hat"],
        C1=C1,
        C2=C2,
        a0=a0,
        Q=Q,
        C3=C3,
        omega_drive_hat=omega_drive,
        omega_ref_hat=omega_ref,
        d_offset_hat=d_offset_hat,
        w_contact=fixed_extra.get("w_contact", 0.1),
        gamma_lr=fixed_extra.get("gamma_lr", 1e-4),
        lambda_lr=fixed_extra.get("lambda_lr", 5.0),
        gamma_contact=fixed_extra.get("gamma_contact", 1e-3),
        **rk45_options,
    )

    A_exp = curve["A_hat"]
    phi_exp = curve["phi_deg"]
    A0 = float(curve["A0_hat"])

    res_A = w_amp * (A_sim - A_exp) / A0

    phi_use = transform_phase_deg(phi_sim, mode=phase_mode)

    if far_field_phase_align:
        phi_auto = estimate_phase_offset_far_field(
            phi_use, phi_exp, curve["d_hat"], frac=far_field_frac, period_deg=phase_period_deg
        )
    else:
        phi_auto = 0.0

    phi_use = phi_use + phi_auto + phi_offset_deg
    dphi = angle_diff_period_deg(phi_use, phi_exp, period_deg=phase_period_deg)

    if use_amp_weighted_phase:
        A_floor = A_floor_frac * A0
        sigma_phi = sigma_phi0_deg * A0 / np.maximum(np.abs(A_exp), A_floor)
        res_phi = w_phi * dphi / sigma_phi
    else:
        res_phi = w_phi * dphi / phase_period_deg

    residuals = [res_A.ravel(), res_phi.ravel()]

    if d_offset_prior_hat is not None and np.isfinite(d_offset_prior_hat):
        residuals.append(np.array([d_offset_hat / d_offset_prior_hat]))

    if phi_offset_prior_deg is not None and np.isfinite(phi_offset_prior_deg):
        residuals.append(np.array([phi_offset_deg / phi_offset_prior_deg]))

    return np.concatenate(residuals)


def fit_one_fd_curve_rk45(
    curve,
    x0,
    bounds=None,
    fixed_extra=None,
    w_amp: float = 1.0,
    w_phi: float = 0.02,
    phase_mode: str = "raw",
    far_field_phase_align: bool = True,
    far_field_frac: float = 0.15,
    phase_period_deg: float = 180.0,
    use_amp_weighted_phase: bool = True,
    sigma_phi0_deg: float = 8.0,
    A_floor_frac: float = 0.15,
    d_offset_prior_hat: Optional[float] = None,
    phi_offset_prior_deg: Optional[float] = 90.0,
    rk45_options: Optional[Dict] = None,
    max_nfev: int = 150,
    verbose: int = 0,
):
    if bounds is None:
        bounds = make_single_bounds(x0)

    result = least_squares(
        residual_single_curve_rk45,
        x0,
        bounds=bounds,
        args=(curve,),
        kwargs=dict(
            fixed_extra=fixed_extra,
            w_amp=w_amp,
            w_phi=w_phi,
            phase_mode=phase_mode,
            far_field_phase_align=far_field_phase_align,
            far_field_frac=far_field_frac,
            phase_period_deg=phase_period_deg,
            use_amp_weighted_phase=use_amp_weighted_phase,
            sigma_phi0_deg=sigma_phi0_deg,
            A_floor_frac=A_floor_frac,
            d_offset_prior_hat=d_offset_prior_hat,
            phi_offset_prior_deg=phi_offset_prior_deg,
            rk45_options=rk45_options,
        ),
        loss="soft_l1",
        f_scale=1.0,
        max_nfev=max_nfev,
        verbose=verbose,
    )

    C1, C2, a0, Q, C3, d_offset_hat, phi_offset_deg = unpack_single_x(result.x)

    return {
        "drive_nm": curve["drive_nm"],
        "success": result.success,
        "cost": result.cost,
        "x": result.x,
        "result": result,
        "C1": C1,
        "C2": C2,
        "a0": a0,
        "Q": Q,
        "C3": C3,
        "d_offset_hat": d_offset_hat,
        "phi_offset_deg": phi_offset_deg,
    }


def fit_individual_fd_curves_rk45(
    curves: List[Dict],
    C1_init: float,
    C2_init: float,
    a0_init: float,
    Q_init: float,
    C3_init_mode: str = "from_A0_over_Q",
    C3_init_value: Optional[float] = None,
    conv_L: float = 1.0,
    fixed_extra: Optional[Dict] = None,
    log_decades: float = 3.0,
    max_abs_d_offset_nm: float = 5.0,
    max_abs_phi_offset_deg: float = 180.0,
    w_amp: float = 1.0,
    w_phi: float = 0.02,
    phase_mode: str = "raw",
    far_field_phase_align: bool = True,
    far_field_frac: float = 0.15,
    phase_period_deg: float = 180.0,
    use_amp_weighted_phase: bool = True,
    sigma_phi0_deg: float = 8.0,
    A_floor_frac: float = 0.15,
    rk45_options: Optional[Dict] = None,
    max_nfev: int = 150,
    verbose: bool = True,
):
    """
    Fit each drive independently using the RK45 extended solver.

    This is mainly diagnostic. For physical interpretation, prefer the global
    fit with shared C1, C2, a0, Q and smooth C3(drive).
    """
    fits = []

    for j, curve in enumerate(curves):
        if C3_init_value is not None:
            C3_init = C3_init_value
        elif C3_init_mode == "from_A0_over_Q":
            C3_init = max(curve["A0_hat"] / Q_init, 1e-15)
        elif C3_init_mode == "from_drive_over_Q":
            C3_init = max(curve["drive_nm"] * conv_L / Q_init, 1e-15)
        else:
            raise ValueError("Unknown C3_init_mode.")

        x0 = make_single_x0(
            C1=C1_init,
            C2=C2_init,
            a0=a0_init,
            Q=Q_init,
            C3=C3_init,
        )

        bounds = make_single_bounds(
            x0,
            log_decades=log_decades,
            max_abs_d_offset_hat=max_abs_d_offset_nm * conv_L,
            max_abs_phi_offset_deg=max_abs_phi_offset_deg,
        )

        fit = fit_one_fd_curve_rk45(
            curve,
            x0,
            bounds=bounds,
            fixed_extra=fixed_extra,
            w_amp=w_amp,
            w_phi=w_phi,
            phase_mode=phase_mode,
            far_field_phase_align=far_field_phase_align,
            far_field_frac=far_field_frac,
            phase_period_deg=phase_period_deg,
            use_amp_weighted_phase=use_amp_weighted_phase,
            sigma_phi0_deg=sigma_phi0_deg,
            A_floor_frac=A_floor_frac,
            d_offset_prior_hat=2.0 * conv_L,
            phi_offset_prior_deg=90.0,
            rk45_options=rk45_options,
            max_nfev=max_nfev,
            verbose=0,
        )

        fits.append(fit)

        if verbose:
            print(
                f"[{j+1:02d}/{len(curves):02d}] "
                f"drive={fit['drive_nm']:.4g}, "
                f"cost={fit['cost']:.4g}, "
                f"C1={fit['C1']:.3e}, C2={fit['C2']:.3e}, "
                f"a0={fit['a0']:.3e}, Q={fit['Q']:.3e}, "
                f"C3={fit['C3']:.3e}"
            )

    return fits


# =============================================================================
# 4. Global shared-physics fit with smooth C3(drive)
# =============================================================================

def normalized_log_drive(drives):
    drives = np.asarray(drives, dtype=float)
    u = np.log(np.maximum(drives, 1e-300))
    s = np.std(u)
    if s == 0:
        return np.zeros_like(u)
    return (u - np.mean(u)) / s


def initialize_extended_global_x_from_individual_fits(
    curves,
    individual_fits,
    conv_L: float = 1.0,
    w_contact_init_nm: float = 0.2,
    gamma_lr_init: float = 1e-4,
    lambda_lr_init_nm: float = 5.0,
    gamma_contact_init: float = 1e-3,
    domega_init: float = 0.0,
):
    """
    x =
        log_C1, log_C2, log_a0, log_Q,
        log_gamma_C3, b1, b2,
        log_w_contact, log_gamma_lr, log_lambda_lr, log_gamma_contact,
        domega,
        d_offset_0 ... d_offset_n-1,
        phi_offset_0 ... phi_offset_n-1
    """
    n = len(curves)

    log_C1_0 = np.median(np.log([f["C1"] for f in individual_fits]))
    log_C2_0 = np.median(np.log([f["C2"] for f in individual_fits]))
    log_a0_0 = np.median(np.log([f["a0"] for f in individual_fits]))
    log_Q_0 = np.median(np.log([f["Q"] for f in individual_fits]))

    drives_nm = np.array([c["drive_nm"] for c in curves], dtype=float)
    drive_scale = np.array(
        [c.get("A0_hat", c["drive_nm"] * conv_L) for c in curves],
        dtype=float,
    )
    u = normalized_log_drive(drives_nm)

    C3_ind = np.array([f["C3"] for f in individual_fits], dtype=float)

    y = np.log(np.maximum(C3_ind, 1e-300)) - np.log(np.maximum(drive_scale, 1e-300))
    X = np.column_stack([np.ones_like(u), u, u**2])
    coef, *_ = np.linalg.lstsq(X, y, rcond=None)

    log_gamma_0, b1_0, b2_0 = coef

    w_contact_init = max(w_contact_init_nm * conv_L, 1e-12)
    lambda_lr_init = max(lambda_lr_init_nm * conv_L, 1e-12)

    d_offsets_0 = np.array([f.get("d_offset_hat", 0.0) for f in individual_fits], dtype=float)

    # We use automatic far-field phase alignment, so keep extra phase offsets small initially.
    phi_offsets_0 = np.zeros(n, dtype=float)

    x0 = np.concatenate(
        [
            np.array(
                [
                    log_C1_0,
                    log_C2_0,
                    log_a0_0,
                    log_Q_0,
                    log_gamma_0,
                    b1_0,
                    b2_0,
                    np.log(w_contact_init),
                    np.log(gamma_lr_init),
                    np.log(lambda_lr_init),
                    np.log(gamma_contact_init),
                    domega_init,
                ],
                dtype=float,
            ),
            d_offsets_0,
            phi_offsets_0,
        ]
    )

    return x0


def unpack_extended_global_x(x, curves, conv_L: float = 1.0):
    n = len(curves)

    log_C1, log_C2, log_a0, log_Q = x[:4]
    log_gamma, b1, b2 = x[4:7]

    log_w_contact = x[7]
    log_gamma_lr = x[8]
    log_lambda_lr = x[9]
    log_gamma_contact = x[10]
    domega = x[11]

    d0 = 12
    d1 = d0 + n
    p0 = d1
    p1 = p0 + n

    d_offsets = x[d0:d1]
    phi_offsets = x[p0:p1]

    drives_nm = np.array([c["drive_nm"] for c in curves], dtype=float)
    drive_scale = np.array(
        [c.get("A0_hat", c["drive_nm"] * conv_L) for c in curves],
        dtype=float,
    )
    u = normalized_log_drive(drives_nm)

    C1 = np.exp(log_C1)
    C2 = np.exp(log_C2)
    a0 = np.exp(log_a0)
    Q = np.exp(log_Q)

    C3_all = np.exp(log_gamma) * drive_scale * np.exp(b1 * u + b2 * u**2)

    w_contact = np.exp(log_w_contact)
    gamma_lr = np.exp(log_gamma_lr)
    lambda_lr = np.exp(log_lambda_lr)
    gamma_contact = np.exp(log_gamma_contact)

    return {
        "C1": C1,
        "C2": C2,
        "a0": a0,
        "Q": Q,
        "C3_all": C3_all,
        "w_contact": w_contact,
        "gamma_lr": gamma_lr,
        "lambda_lr": lambda_lr,
        "gamma_contact": gamma_contact,
        "domega": domega,
        "d_offsets_hat": d_offsets,
        "phi_offsets_deg": phi_offsets,
        "drives_nm": drives_nm,
    }


def make_extended_global_bounds(
    x0,
    n_curves: int,
    conv_L: float = 1.0,
    log_decades_physics: float = 2.0,
    log_decades_C3: float = 3.0,
    log_decades_damping: float = 4.0,
    max_abs_beta: float = 4.0,
    max_abs_d_offset_nm: float = 5.0,
    max_abs_phi_offset_deg: float = 180.0,
    domega_bounds: Tuple[float, float] = (-0.03, 0.03),
):
    lower = np.asarray(x0, dtype=float).copy()
    upper = np.asarray(x0, dtype=float).copy()

    # shared log C1, C2, a0, Q
    lower[:4] -= log_decades_physics * np.log(10.0)
    upper[:4] += log_decades_physics * np.log(10.0)

    # log_gamma_C3
    lower[4] -= log_decades_C3 * np.log(10.0)
    upper[4] += log_decades_C3 * np.log(10.0)

    # b1, b2 for smooth C3(drive)
    lower[5] = -max_abs_beta
    upper[5] = +max_abs_beta
    lower[6] = -max_abs_beta
    upper[6] = +max_abs_beta

    # w_contact, gamma_lr, lambda_lr, gamma_contact
    lower[7:11] -= log_decades_damping * np.log(10.0)
    upper[7:11] += log_decades_damping * np.log(10.0)

    # global frequency detuning
    lower[11] = domega_bounds[0]
    upper[11] = domega_bounds[1]

    # per-curve distance offsets
    d0 = 12
    d1 = d0 + n_curves
    lower[d0:d1] = -max_abs_d_offset_nm * conv_L
    upper[d0:d1] = +max_abs_d_offset_nm * conv_L

    # per-curve phase offsets
    p0 = d1
    p1 = p0 + n_curves
    lower[p0:p1] = -max_abs_phi_offset_deg
    upper[p0:p1] = +max_abs_phi_offset_deg

    return lower, upper


def residual_extended_global_C3_rk45(
    x,
    curves,
    conv_L: float = 1.0,
    w_amp: float = 1.0,
    w_phi: float = 0.02,
    phase_mode: str = "raw",
    far_field_phase_align: bool = True,
    far_field_frac: float = 0.15,
    phase_period_deg: float = 180.0,
    use_amp_weighted_phase: bool = True,
    sigma_phi0_deg: float = 8.0,
    A_floor_frac: float = 0.15,
    rk45_options: Optional[Dict] = None,
    d_offset_prior_nm: Optional[float] = 2.0,
    phi_offset_prior_deg: Optional[float] = 90.0,
    beta_prior: Optional[float] = 2.0,
    damping_log_prior: Optional[float] = 3.0,
):
    p = unpack_extended_global_x(x, curves, conv_L=conv_L)
    rk45_options = dict(rk45_options or {})

    residuals = []

    omega_base = 1.0 + p["domega"]
    if omega_base <= 0:
        return np.ones(100) * 1e6

    for j, curve in enumerate(curves):
        omega_drive = omega_base * curve.get("omega_drive_hat", 1.0)
        omega_ref = curve.get("omega_ref_hat", omega_drive)

        A_sim, phi_sim, *_ = simulate_curve_rk45_extended_python(
            curve["d_hat"],
            C1=p["C1"],
            C2=p["C2"],
            a0=p["a0"],
            Q=p["Q"],
            C3=p["C3_all"][j],
            omega_drive_hat=omega_drive,
            omega_ref_hat=omega_ref,
            d_offset_hat=p["d_offsets_hat"][j],
            w_contact=p["w_contact"],
            gamma_lr=p["gamma_lr"],
            lambda_lr=p["lambda_lr"],
            gamma_contact=p["gamma_contact"],
            **rk45_options,
        )

        A_exp = curve["A_hat"]
        phi_exp = curve["phi_deg"]
        A0 = float(curve["A0_hat"])

        # Amplitude residual
        residuals.append(w_amp * (A_sim - A_exp) / A0)

        # Phase convention transform
        phi_use = transform_phase_deg(phi_sim, mode=phase_mode)

        # Automatic far-field phase alignment
        if far_field_phase_align:
            phi_auto = estimate_phase_offset_far_field(
                phi_use,
                phi_exp,
                curve["d_hat"],
                frac=far_field_frac,
                period_deg=phase_period_deg,
            )
        else:
            phi_auto = 0.0

        # Extra optimized per-curve offset
        phi_use = phi_use + phi_auto + p["phi_offsets_deg"][j]
        dphi = angle_diff_period_deg(phi_use, phi_exp, period_deg=phase_period_deg)

        if use_amp_weighted_phase:
            A_floor = A_floor_frac * A0
            sigma_phi = sigma_phi0_deg * A0 / np.maximum(np.abs(A_exp), A_floor)
            residuals.append(w_phi * dphi / sigma_phi)
        else:
            residuals.append(w_phi * dphi / phase_period_deg)

    # Regularization
    if d_offset_prior_nm is not None:
        residuals.append(p["d_offsets_hat"] / (d_offset_prior_nm * conv_L))

    if phi_offset_prior_deg is not None:
        residuals.append(p["phi_offsets_deg"] / phi_offset_prior_deg)

    if beta_prior is not None:
        # Avoid unnecessary curvature in C3(drive)
        residuals.append(np.array([x[5] / beta_prior, x[6] / beta_prior]))

    if damping_log_prior is not None:
        # Weakly discourage huge damping unless phase requires it.
        residuals.append(
            np.array(
                [
                    x[8] / damping_log_prior,   # log_gamma_lr
                    x[10] / damping_log_prior,  # log_gamma_contact
                ]
            )
        )

    return np.concatenate([np.ravel(r) for r in residuals])


def compute_auto_phase_offsets_at_solution_rk45(
    global_fit,
    curves,
    phase_mode: str = "raw",
    far_field_frac: float = 0.15,
    phase_period_deg: float = 180.0,
    rk45_options: Optional[Dict] = None,
):
    rk45_options = dict(rk45_options or {})
    auto_offsets = []

    omega_base = 1.0 + global_fit["domega"]

    for j, curve in enumerate(curves):
        omega_drive = omega_base * curve.get("omega_drive_hat", 1.0)
        omega_ref = curve.get("omega_ref_hat", omega_drive)

        A_sim, phi_sim, *_ = simulate_curve_rk45_extended_python(
            curve["d_hat"],
            C1=global_fit["C1"],
            C2=global_fit["C2"],
            a0=global_fit["a0"],
            Q=global_fit["Q"],
            C3=global_fit["C3_all"][j],
            omega_drive_hat=omega_drive,
            omega_ref_hat=omega_ref,
            d_offset_hat=global_fit["d_offsets_hat"][j],
            w_contact=global_fit["w_contact"],
            gamma_lr=global_fit["gamma_lr"],
            lambda_lr=global_fit["lambda_lr"],
            gamma_contact=global_fit["gamma_contact"],
            **rk45_options,
        )

        phi_use = transform_phase_deg(phi_sim, mode=phase_mode)
        phi_auto = estimate_phase_offset_far_field(
            phi_use,
            curve["phi_deg"],
            curve["d_hat"],
            frac=far_field_frac,
            period_deg=phase_period_deg,
        )
        auto_offsets.append(phi_auto)

    return np.asarray(auto_offsets, dtype=float)


def fit_global_drive_dependent_C3_extended_rk45(
    curves,
    individual_fits,
    conv_L: float = 1.0,
    w_amp: float = 1.0,
    w_phi: float = 0.02,
    phase_mode: str = "raw",
    far_field_phase_align: bool = True,
    far_field_frac: float = 0.15,
    phase_period_deg: float = 180.0,
    use_amp_weighted_phase: bool = True,
    sigma_phi0_deg: float = 8.0,
    A_floor_frac: float = 0.15,
    rk45_options: Optional[Dict] = None,
    max_nfev: int = 300,
    verbose: int = 2,
    log_decades_physics: float = 2.0,
    log_decades_C3: float = 3.0,
    log_decades_damping: float = 4.0,
    max_abs_d_offset_nm: float = 5.0,
    max_abs_phi_offset_deg: float = 180.0,
    domega_bounds: Tuple[float, float] = (-0.03, 0.03),
):
    """
    Global fit using:
        shared: C1, C2, a0, Q, w_contact, gamma_lr, lambda_lr, gamma_contact, domega
        drive-dependent: smooth C3(drive)
        per curve: d_offset_j, phi_offset_j
    """
    x0 = initialize_extended_global_x_from_individual_fits(
        curves,
        individual_fits,
        conv_L=conv_L,
    )

    bounds = make_extended_global_bounds(
        x0,
        n_curves=len(curves),
        conv_L=conv_L,
        log_decades_physics=log_decades_physics,
        log_decades_C3=log_decades_C3,
        log_decades_damping=log_decades_damping,
        max_abs_d_offset_nm=max_abs_d_offset_nm,
        max_abs_phi_offset_deg=max_abs_phi_offset_deg,
        domega_bounds=domega_bounds,
    )

    result = least_squares(
        residual_extended_global_C3_rk45,
        x0,
        bounds=bounds,
        args=(curves,),
        kwargs=dict(
            conv_L=conv_L,
            w_amp=w_amp,
            w_phi=w_phi,
            phase_mode=phase_mode,
            far_field_phase_align=far_field_phase_align,
            far_field_frac=far_field_frac,
            phase_period_deg=phase_period_deg,
            use_amp_weighted_phase=use_amp_weighted_phase,
            sigma_phi0_deg=sigma_phi0_deg,
            A_floor_frac=A_floor_frac,
            rk45_options=rk45_options,
        ),
        loss="soft_l1",
        f_scale=1.0,
        max_nfev=max_nfev,
        verbose=verbose,
    )

    p = unpack_extended_global_x(result.x, curves, conv_L=conv_L)
    p["success"] = result.success
    p["cost"] = result.cost
    p["x"] = result.x
    p["result"] = result
    p["phase_mode"] = phase_mode
    p["phase_period_deg"] = phase_period_deg

    p["phase_auto_offsets_deg"] = compute_auto_phase_offsets_at_solution_rk45(
        p,
        curves,
        phase_mode=phase_mode,
        far_field_frac=far_field_frac,
        phase_period_deg=phase_period_deg,
        rk45_options=rk45_options,
    )

    return p


# =============================================================================
# 5. Plotting
# =============================================================================

def plot_individual_parameter_trends(individual_fits):
    drives = np.array([f["drive_nm"] for f in individual_fits])
    keys = ["C1", "C2", "a0", "Q", "C3"]

    fig, ax = plt.subplots(1, len(keys), figsize=(3.2 * len(keys), 3.0))

    for k, key in enumerate(keys):
        y = np.array([f[key] for f in individual_fits])
        ax[k].plot(drives, y, "o-")
        ax[k].set_xlabel("Drive amplitude")
        ax[k].set_title(key)
        ax[k].set_yscale("log")

    plt.tight_layout()
    return fig, ax


def plot_one_fit_overlay_rk45(
    curve,
    fit,
    conv_L: float = 1.0,
    fixed_extra: Optional[Dict] = None,
    phase_mode: str = "raw",
    far_field_phase_align: bool = True,
    far_field_frac: float = 0.15,
    phase_period_deg: float = 180.0,
    rk45_options: Optional[Dict] = None,
):
    fixed_extra = dict(fixed_extra or {})
    rk45_options = dict(rk45_options or {})

    omega_drive = curve.get("omega_drive_hat", 1.0) * fixed_extra.get("omega_scale", 1.0)
    omega_ref = curve.get("omega_ref_hat", omega_drive)

    A_sim, phi_sim, *_ = simulate_curve_rk45_extended_python(
        curve["d_hat"],
        C1=fit["C1"],
        C2=fit["C2"],
        a0=fit["a0"],
        Q=fit["Q"],
        C3=fit["C3"],
        omega_drive_hat=omega_drive,
        omega_ref_hat=omega_ref,
        d_offset_hat=fit.get("d_offset_hat", 0.0),
        w_contact=fixed_extra.get("w_contact", 0.1),
        gamma_lr=fixed_extra.get("gamma_lr", 1e-4),
        lambda_lr=fixed_extra.get("lambda_lr", 5.0),
        gamma_contact=fixed_extra.get("gamma_contact", 1e-3),
        **rk45_options,
    )

    phi_use = transform_phase_deg(phi_sim, mode=phase_mode)
    if far_field_phase_align:
        phi_auto = estimate_phase_offset_far_field(
            phi_use, curve["phi_deg"], curve["d_hat"], frac=far_field_frac,
            period_deg=phase_period_deg
        )
    else:
        phi_auto = 0.0

    phi_use = phi_use + phi_auto + fit.get("phi_offset_deg", 0.0)

    d_nm = curve["d_hat"] / conv_L

    fig, ax = plt.subplots(1, 2, figsize=(8.5, 3.4))

    ax[0].plot(d_nm, curve["A_hat"] / conv_L, "o", ms=4, label="exp")
    ax[0].plot(d_nm, A_sim / conv_L, "-", lw=2, label="fit")
    ax[0].set_xlabel("Height (nm)")
    ax[0].set_ylabel("Amplitude (nm)")
    ax[0].set_title(f"Drive = {curve['drive_nm']:.4g}")
    ax[0].legend()

    ax[1].plot(d_nm, curve["phi_deg"], "o", ms=4, label="exp")
    ax[1].plot(d_nm, phi_use, "-", lw=2, label="fit + phase offset")
    ax[1].set_xlabel("Height (nm)")
    ax[1].set_ylabel("Phase (deg)")
    ax[1].legend()

    plt.tight_layout()
    print(f"auto phase offset = {phi_auto:.3f} deg")
    return fig, ax


def plot_global_fit_overlays_rk45(
    curves,
    global_fit,
    conv_L: float = 1.0,
    phase_mode: Optional[str] = None,
    far_field_phase_align: bool = True,
    far_field_frac: float = 0.15,
    phase_period_deg: Optional[float] = None,
    rk45_options: Optional[Dict] = None,
):
    rk45_options = dict(rk45_options or {})

    if phase_mode is None:
        phase_mode = global_fit.get("phase_mode", "raw")

    if phase_period_deg is None:
        phase_period_deg = global_fit.get("phase_period_deg", 180.0)

    omega_base = 1.0 + global_fit["domega"]

    fig, ax = plt.subplots(1, 2, figsize=(10.5, 4.0))

    for j, curve in enumerate(curves):
        omega_drive = omega_base * curve.get("omega_drive_hat", 1.0)
        omega_ref = curve.get("omega_ref_hat", omega_drive)

        A_sim, phi_sim, *_ = simulate_curve_rk45_extended_python(
            curve["d_hat"],
            C1=global_fit["C1"],
            C2=global_fit["C2"],
            a0=global_fit["a0"],
            Q=global_fit["Q"],
            C3=global_fit["C3_all"][j],
            omega_drive_hat=omega_drive,
            omega_ref_hat=omega_ref,
            d_offset_hat=global_fit["d_offsets_hat"][j],
            w_contact=global_fit["w_contact"],
            gamma_lr=global_fit["gamma_lr"],
            lambda_lr=global_fit["lambda_lr"],
            gamma_contact=global_fit["gamma_contact"],
            **rk45_options,
        )

        d_nm = curve["d_hat"] / conv_L
        phi_use = transform_phase_deg(phi_sim, mode=phase_mode)

        if far_field_phase_align:
            if "phase_auto_offsets_deg" in global_fit:
                phi_auto = global_fit["phase_auto_offsets_deg"][j]
            else:
                phi_auto = estimate_phase_offset_far_field(
                    phi_use, curve["phi_deg"], curve["d_hat"],
                    frac=far_field_frac, period_deg=phase_period_deg
                )
        else:
            phi_auto = 0.0

        phi_use = phi_use + phi_auto + global_fit["phi_offsets_deg"][j]

        ax[0].plot(d_nm, curve["A_hat"] / conv_L, "o", ms=3, alpha=0.45)
        ax[0].plot(d_nm, A_sim / conv_L, "-", lw=1.5)

        ax[1].plot(d_nm, curve["phi_deg"], "o", ms=3, alpha=0.45)
        ax[1].plot(d_nm, phi_use, "-", lw=1.5)

    ax[0].set_xlabel("Height (nm)")
    ax[0].set_ylabel("Amplitude (nm)")
    ax[0].set_title("RK45 extended global fit: amplitude")

    ax[1].set_xlabel("Height (nm)")
    ax[1].set_ylabel("Phase (deg)")
    ax[1].set_title("RK45 extended global fit: phase + offset correction")

    plt.tight_layout()
    return fig, ax


def plot_C3_drive_dependence(global_fit, individual_fits=None):
    drives = global_fit["drives_nm"]
    C3 = global_fit["C3_all"]

    fig, ax = plt.subplots(figsize=(4.8, 3.5))

    if individual_fits is not None:
        drives_ind = np.array([f["drive_nm"] for f in individual_fits])
        C3_ind = np.array([f["C3"] for f in individual_fits])
        ax.plot(drives_ind, C3_ind, "o", label="individual C3")

    ax.plot(drives, C3, "s-", label="global smooth C3(drive)")
    ax.set_xlabel("Drive amplitude")
    ax.set_ylabel("C3")
    ax.set_yscale("log")
    ax.legend()
    plt.tight_layout()

    return fig, ax


def plot_phase_offsets(global_fit):
    drives = global_fit["drives_nm"]

    auto = global_fit.get("phase_auto_offsets_deg", np.zeros_like(drives))
    extra = global_fit["phi_offsets_deg"]
    total = auto + extra

    fig, ax = plt.subplots(figsize=(5.2, 3.4))
    ax.plot(drives, auto, "o-", label="far-field auto offset")
    ax.plot(drives, extra, "s-", label="fitted extra offset")
    ax.plot(drives, total, "^-", label="total offset")
    ax.axhline(0, color="k", lw=0.8, alpha=0.4)
    ax.set_xlabel("Drive amplitude")
    ax.set_ylabel("Phase offset (deg)")
    ax.legend()
    plt.tight_layout()

    return fig, ax


# =============================================================================
# 6. Recommended usage
# =============================================================================

if __name__ == "__main__":
    print(
        "This file defines RK45-based SPM FD calibration functions.\n"
        "Import it into your notebook/script and run the example below with your data.\n"
    )

    example = r"""
# -------------------------------------------------------------------------
# Example usage
# -------------------------------------------------------------------------

from spm_fd_rk45_extended_calibration import *

# Build curves from arrays:
# curves = build_measured_fd_curves(
#     drives_nm=drive,
#     height_nm=height,
#     amplitude_nm=amp,
#     phase_deg=phase,
#     conv_L=conv_L,
#     A0_method="far_field_median",
#     far_field_frac=0.10,
#     omega_drive_hat=1.0,
#     omega_ref_hat=1.0,
# )

# Or from a measured_fd dictionary:
# curves = build_measured_fd_curves_from_dict(
#     measured_fd,
#     conv_L=conv_L,
#     A0_method="far_field_median",
#     far_field_frac=0.10,
#     omega_drive_hat=1.0,
#     omega_ref_hat=1.0,
# )

# RK45 options. Start coarse for fitting, then use stricter settings for plotting.
rk45_fit_options = dict(
    N_cycles=3,
    max_windows=30,
    settle_windows=3,
    tol_A=1e-4,
    tol_phi_deg=0.05,
    consecutive=2,
    demod_per_ref_cycle=32,
    rtol=1e-5,
    atol=1e-7,
    dt0=0.03,
    dt_min=1e-5,
    dt_max=0.20,
    max_steps_per_window=150000,
    phase_wrap_mode=180,      # matches the uploaded RK45 style
    use_warm_start=True,
    alpha_A=None,
    alpha_phi=None,
)

rk45_plot_options = dict(
    N_cycles=4,
    max_windows=50,
    settle_windows=4,
    tol_A=3e-5,
    tol_phi_deg=0.02,
    consecutive=2,
    demod_per_ref_cycle=48,
    rtol=3e-6,
    atol=1e-8,
    dt0=0.02,
    dt_min=1e-5,
    dt_max=0.15,
    max_steps_per_window=250000,
    phase_wrap_mode=180,
    use_warm_start=True,
    alpha_A=None,
    alpha_phi=None,
)

# Initial guesses. Adjust these to your normalized units.
C1_init = 1e-3
C2_init = 1e-2
a0_init = 0.1
Q_init  = 80.0

# Fixed extra physics for individual diagnostic fits.
# The global fit will refine these shared damping parameters.
fixed_extra = dict(
    w_contact=0.2 * conv_L,
    gamma_lr=1e-4,
    lambda_lr=5.0 * conv_L,
    gamma_contact=1e-3,
    omega_scale=1.0,
)

# -------------------------------------------------------------------------
# Step 1: individual RK45 FD fits
# -------------------------------------------------------------------------
individual_fits = fit_individual_fd_curves_rk45(
    curves,
    C1_init=C1_init,
    C2_init=C2_init,
    a0_init=a0_init,
    Q_init=Q_init,
    C3_init_mode="from_A0_over_Q",
    conv_L=conv_L,
    fixed_extra=fixed_extra,
    log_decades=3.0,
    max_abs_d_offset_nm=5.0,
    max_abs_phi_offset_deg=180.0,
    w_amp=1.0,
    w_phi=0.01,                  # keep small until phase convention is stable
    phase_mode="raw",
    far_field_phase_align=True,
    far_field_frac=0.15,
    phase_period_deg=180.0,      # use 360.0 if your phase is not folded
    use_amp_weighted_phase=True,
    sigma_phi0_deg=8.0,
    A_floor_frac=0.15,
    rk45_options=rk45_fit_options,
    max_nfev=100,
    verbose=True,
)

plot_individual_parameter_trends(individual_fits)

# Inspect one curve
# plot_one_fit_overlay_rk45(
#     curves[0],
#     individual_fits[0],
#     conv_L=conv_L,
#     fixed_extra=fixed_extra,
#     phase_mode="raw",
#     far_field_phase_align=True,
#     phase_period_deg=180.0,
#     rk45_options=rk45_plot_options,
# )

# -------------------------------------------------------------------------
# Step 2: global shared-physics fit with smooth C3(drive)
# -------------------------------------------------------------------------
global_fit = fit_global_drive_dependent_C3_extended_rk45(
    curves,
    individual_fits,
    conv_L=conv_L,

    w_amp=1.0,
    w_phi=0.02,

    phase_mode="raw",            # try "minus_from_180" or "minus_from_360" if needed
    far_field_phase_align=True,
    far_field_frac=0.15,
    phase_period_deg=180.0,
    use_amp_weighted_phase=True,
    sigma_phi0_deg=8.0,
    A_floor_frac=0.15,

    rk45_options=rk45_fit_options,
    max_nfev=300,
    verbose=2,

    log_decades_physics=2.0,
    log_decades_C3=3.0,
    log_decades_damping=4.0,
    max_abs_d_offset_nm=5.0,
    max_abs_phi_offset_deg=180.0,
    domega_bounds=(-0.03, 0.03),
)

print("RK45 extended global shared parameters:")
print("C1             =", global_fit["C1"])
print("C2             =", global_fit["C2"])
print("a0             =", global_fit["a0"])
print("Q              =", global_fit["Q"])
print("w_contact      =", global_fit["w_contact"])
print("gamma_lr       =", global_fit["gamma_lr"])
print("lambda_lr      =", global_fit["lambda_lr"])
print("gamma_contact  =", global_fit["gamma_contact"])
print("domega         =", global_fit["domega"])

plot_global_fit_overlays_rk45(
    curves,
    global_fit,
    conv_L=conv_L,
    rk45_options=rk45_plot_options,
)

plot_C3_drive_dependence(global_fit, individual_fits)
plot_phase_offsets(global_fit)
"""
    print(example)



# =============================================================================
# 7. Multi-force-model, branch-aware FD fitting extension
# =============================================================================
#
# This section is intentionally written as a lightweight wrapper around the
# companion force-model module `spm_force_models_branches.py`.  It keeps the
# original DMT-only RK45 code above intact, but adds:
#   * automatic force-model selection using approach + optional retract FD data;
#   * individual fitting of each approach curve with the selected force model;
#   * global fitting with shared force parameters and smooth drive-dependent C3;
#   * optional all-stable-branches output for each fitted curve.
#
# Expected additional module:
#     spm_force_models_branches.py
# Place it in the same folder as this file, or import both as modules inside
# your `codes/` folder.

from dataclasses import dataclass, field
from typing import Sequence, Any
import importlib
import copy


def _load_force_model_module():
    """Import the companion multi-force-model module robustly."""
    tried = []
    for name in (
        "spm_force_models_branches",
        "codes.spm_force_models_branches",
    ):
        try:
            return importlib.import_module(name)
        except Exception as exc:  # pragma: no cover
            tried.append((name, repr(exc)))
    try:
        from . import spm_force_models_branches as fmb  # type: ignore
        return fmb
    except Exception as exc:  # pragma: no cover
        tried.append(("relative .spm_force_models_branches", repr(exc)))
    msg = "Could not import spm_force_models_branches.py. Tried:\n"
    msg += "\n".join([f"  {n}: {e}" for n, e in tried])
    msg += "\nPut spm_force_models_branches.py in the same folder or in your codes/ folder."
    raise ImportError(msg)


@dataclass
class MultiForceFitConfig:
    """Configuration for multi-force FD fitting."""
    candidates: Tuple[str, ...] = ("dmt", "hertz", "lj", "morse", "jkr", "capillary")
    selected_model: Optional[str] = None
    n_fit_points: int = 64
    log_decades_force: float = 3.0
    log_decades_Q: float = 2.0
    log_decades_C3: float = 3.0
    log_decades_damping: float = 4.0
    max_abs_d_offset_hat: float = 5.0
    max_abs_phi_offset_deg: float = 180.0
    w_amp: float = 1.0
    w_phi: float = 0.02
    phase_mode: str = "raw"
    far_field_phase_align: bool = True
    far_field_frac: float = 0.15
    phase_period_deg: float = 180.0
    use_amp_weighted_phase: bool = True
    sigma_phi0_deg: float = 8.0
    A_floor_frac: float = 0.15
    d_offset_prior_hat: Optional[float] = 2.0
    phi_offset_prior_deg: Optional[float] = 90.0
    max_nfev_select: int = 80
    max_nfev_individual: int = 120
    max_nfev_global: int = 300
    use_global_jac_sparsity: bool = False
    selector_w_amp: float = 1.0
    selector_w_phi: float = 0.01
    use_retract_for_selection: bool = True
    add_branch_score_to_selection: bool = True
    branch_score_weight: float = 1.0
    output_branches: bool = False
    branch_n_points: int = 80
    branch_n_starts: int = 7
    branch_tol_A: float = 1e-3
    branch_tol_phi_deg: float = 1.0
    verbose: bool = True


def make_default_multiforce_sim_options(
    Q: float = 80.0,
    C3: float = 0.05,
    omega_drive_hat: float = 1.0,
    omega_ref_hat: Optional[float] = None,
    d_offset_hat: float = 0.0,
    w_contact: float = 0.1,
    gamma_lr: float = 1e-4,
    lambda_lr: float = 5.0,
    gamma_contact: float = 1e-3,
    N_cycles: int = 3,
    max_windows: int = 35,
    settle_windows: int = 3,
    tol_A: float = 1e-5,
    tol_phi_deg: float = 0.03,
    consecutive: int = 2,
    demod_per_ref_cycle: int = 40,
    rtol: float = 1e-5,
    atol: float = 1e-7,
    dt0: float = 0.03,
    dt_min: float = 1e-5,
    dt_max: float = 0.18,
    max_steps_per_window: int = 100000,
    phase_wrap_mode: int = 180,
    use_warm_start: bool = True,
):
    """Return a SimOptions instance from spm_force_models_branches."""
    fmb = _load_force_model_module()
    return fmb.SimOptions(
        Q=Q,
        C3=C3,
        omega_drive_hat=omega_drive_hat,
        omega_ref_hat=omega_ref_hat,
        d_offset_hat=d_offset_hat,
        w_contact=w_contact,
        gamma_lr=gamma_lr,
        lambda_lr=lambda_lr,
        gamma_contact=gamma_contact,
        N_cycles=N_cycles,
        max_windows=max_windows,
        settle_windows=settle_windows,
        tol_A=tol_A,
        tol_phi_deg=tol_phi_deg,
        consecutive=consecutive,
        demod_per_ref_cycle=demod_per_ref_cycle,
        rtol=rtol,
        atol=atol,
        dt0=dt0,
        dt_min=dt_min,
        dt_max=dt_max,
        max_steps_per_window=max_steps_per_window,
        phase_wrap_mode=phase_wrap_mode,
        use_warm_start=use_warm_start,
    )


def _copy_sim_options(opts):
    return copy.copy(opts)


def _curve_subsample_indices_by_d(d_hat, n_points: Optional[int]):
    d_hat = np.asarray(d_hat, dtype=float).ravel()
    n = d_hat.size
    if n_points is None or n_points <= 0 or n <= n_points:
        return np.arange(n, dtype=int)
    order = np.argsort(d_hat)
    pos = np.linspace(0, n - 1, int(n_points))
    idx = order[np.unique(np.round(pos).astype(int))]
    return np.sort(idx)


def subsample_fd_curve(curve: Dict, n_points: Optional[int] = 64):
    """Return a shallow copy of a curve using a distance-stratified subset."""
    idx = _curve_subsample_indices_by_d(curve["d_hat"], n_points)
    out = dict(curve)
    out["d_hat"] = np.asarray(curve["d_hat"], dtype=float)[idx]
    out["A_hat"] = np.asarray(curve["A_hat"], dtype=float)[idx]
    out["phi_deg"] = np.asarray(curve["phi_deg"], dtype=float)[idx]
    out["_subsample_indices"] = idx
    return out


def _force_values_from_param_vector(model: str, force_params: np.ndarray) -> Dict[str, float]:
    fmb = _load_force_model_module()
    schema = fmb.FORCE_PARAM_SCHEMA[model]
    p = np.asarray(force_params, dtype=float).ravel()
    values = {}
    for i, name in enumerate(schema):
        if name != "_":
            values[name] = float(p[i])
    return values


def _force_vector_from_values(model: str, values: Optional[Dict[str, float]] = None):
    fmb = _load_force_model_module()
    values = dict(values or {})
    return fmb.make_force_params(model, **values)


def _simulate_multiforce_curve_for_fit(
    curve,
    model: str,
    force_params: np.ndarray,
    Q: float,
    C3: float,
    d_offset_hat: float,
    sim_opts,
    omega_scale: float = 1.0,
):
    fmb = _load_force_model_module()
    opts = _copy_sim_options(sim_opts)
    opts.Q = float(Q)
    opts.C3 = float(C3)
    opts.d_offset_hat = float(d_offset_hat)
    opts.omega_drive_hat = float(curve.get("omega_drive_hat", 1.0)) * float(omega_scale)
    opts.omega_ref_hat = float(curve.get("omega_ref_hat", opts.omega_drive_hat))
    out = fmb.simulate_curve(np.asarray(curve["d_hat"], dtype=float), model, force_params, opts)
    return out["A"], out["phi"], out


def _phase_residual_for_fit(
    phi_sim,
    phi_exp,
    d_hat,
    A_exp,
    A0,
    cfg: MultiForceFitConfig,
    phi_offset_deg: float = 0.0,
):
    phi_use = transform_phase_deg(phi_sim, mode=cfg.phase_mode)
    if cfg.far_field_phase_align:
        phi_auto = estimate_phase_offset_far_field(
            phi_use, phi_exp, d_hat, frac=cfg.far_field_frac,
            period_deg=cfg.phase_period_deg,
        )
    else:
        phi_auto = 0.0
    phi_use = phi_use + phi_auto + float(phi_offset_deg)
    dphi = angle_diff_period_deg(phi_use, phi_exp, period_deg=cfg.phase_period_deg)
    if cfg.use_amp_weighted_phase:
        A_floor = cfg.A_floor_frac * A0
        sigma_phi = cfg.sigma_phi0_deg * A0 / np.maximum(np.abs(A_exp), A_floor)
        res_phi = cfg.w_phi * dphi / sigma_phi
    else:
        res_phi = cfg.w_phi * dphi / cfg.phase_period_deg
    return np.asarray(res_phi, dtype=float), float(phi_auto)


def _model_fit_params(model: str):
    fmb = _load_force_model_module()
    return list(fmb.FORCE_FIT_PARAMS[model])


def make_multiforce_single_x0(
    model: str,
    force_params: Optional[np.ndarray] = None,
    force_values: Optional[Dict[str, float]] = None,
    Q_init: float = 80.0,
    C3_init: float = 0.05,
    d_offset_hat: float = 0.0,
    phi_offset_deg: float = 0.0,
):
    """Parameter vector for one curve: log(force params), log(Q), log(C3), d_offset, phi_offset."""
    fmb = _load_force_model_module()
    names = _model_fit_params(model)
    if force_params is not None:
        values = _force_values_from_param_vector(model, force_params)
    else:
        values = dict(fmb.FORCE_DEFAULTS[model])
        if force_values is not None:
            values.update(force_values)
    logs = [np.log(max(float(values[name]), 1e-300)) for name in names]
    return np.asarray(logs + [np.log(Q_init), np.log(C3_init), d_offset_hat, phi_offset_deg], dtype=float)


def unpack_multiforce_single_x(model: str, x):
    fmb = _load_force_model_module()
    x = np.asarray(x, dtype=float)
    names = _model_fit_params(model)
    nfp = len(names)
    values = {name: float(np.exp(x[i])) for i, name in enumerate(names)}
    force_params = fmb.make_force_params(model, **values)
    Q = float(np.exp(x[nfp]))
    C3 = float(np.exp(x[nfp + 1]))
    d_offset_hat = float(x[nfp + 2])
    phi_offset_deg = float(x[nfp + 3])
    return force_params, values, Q, C3, d_offset_hat, phi_offset_deg


def make_multiforce_single_bounds(model: str, x0, cfg: MultiForceFitConfig):
    names = _model_fit_params(model)
    nfp = len(names)
    lower = np.asarray(x0, dtype=float).copy()
    upper = np.asarray(x0, dtype=float).copy()
    lower[:nfp] -= cfg.log_decades_force * np.log(10.0)
    upper[:nfp] += cfg.log_decades_force * np.log(10.0)
    lower[nfp] -= cfg.log_decades_Q * np.log(10.0)
    upper[nfp] += cfg.log_decades_Q * np.log(10.0)
    lower[nfp + 1] -= cfg.log_decades_C3 * np.log(10.0)
    upper[nfp + 1] += cfg.log_decades_C3 * np.log(10.0)
    lower[nfp + 2] = -cfg.max_abs_d_offset_hat
    upper[nfp + 2] = +cfg.max_abs_d_offset_hat
    lower[nfp + 3] = -cfg.max_abs_phi_offset_deg
    upper[nfp + 3] = +cfg.max_abs_phi_offset_deg
    return lower, upper


def residual_single_curve_multiforce_branchaware(x, curve, model: str, sim_opts, cfg: MultiForceFitConfig):
    force_params, values, Q, C3, d_offset_hat, phi_offset_deg = unpack_multiforce_single_x(model, x)
    try:
        A_sim, phi_sim, _ = _simulate_multiforce_curve_for_fit(
            curve, model, force_params, Q, C3, d_offset_hat, sim_opts
        )
    except Exception:
        return np.ones(2 * len(curve["d_hat"]) + 4) * 1e6
    A_exp = np.asarray(curve["A_hat"], dtype=float)
    phi_exp = np.asarray(curve["phi_deg"], dtype=float)
    d_hat = np.asarray(curve["d_hat"], dtype=float)
    A0 = float(curve["A0_hat"])
    res_A = cfg.w_amp * (A_sim - A_exp) / max(A0, 1e-12)
    res_phi, _ = _phase_residual_for_fit(phi_sim, phi_exp, d_hat, A_exp, A0, cfg, phi_offset_deg)
    residuals = [res_A.ravel(), res_phi.ravel()]
    if cfg.d_offset_prior_hat is not None and np.isfinite(cfg.d_offset_prior_hat):
        residuals.append(np.asarray([d_offset_hat / cfg.d_offset_prior_hat]))
    if cfg.phi_offset_prior_deg is not None and np.isfinite(cfg.phi_offset_prior_deg):
        residuals.append(np.asarray([phi_offset_deg / cfg.phi_offset_prior_deg]))
    return np.concatenate(residuals)


def select_force_model_for_fd_curve(
    approach_curve: Dict,
    retract_curve: Optional[Dict] = None,
    sim_opts=None,
    cfg: Optional[MultiForceFitConfig] = None,
):
    """Automatically rank force models using approach and optional retract FD curves."""
    fmb = _load_force_model_module()
    cfg = cfg or MultiForceFitConfig()
    if sim_opts is None:
        sim_opts = make_default_multiforce_sim_options()
    app = subsample_fd_curve(approach_curve, cfg.n_fit_points)
    ret = subsample_fd_curve(retract_curve, cfg.n_fit_points) if retract_curve is not None else None
    if cfg.verbose:
        print(f"[selector] drive={approach_curve.get('drive_nm', np.nan):.4g}")
    sel = fmb.auto_select_force_model(
        np.asarray(app["d_hat"], dtype=float),
        np.asarray(app["A_hat"], dtype=float),
        np.asarray(app["phi_deg"], dtype=float),
        d_ret_hat=None if (ret is None or not cfg.use_retract_for_selection) else np.asarray(ret["d_hat"], dtype=float),
        A_ret=None if (ret is None or not cfg.use_retract_for_selection) else np.asarray(ret["A_hat"], dtype=float),
        phi_ret=None if (ret is None or not cfg.use_retract_for_selection) else np.asarray(ret["phi_deg"], dtype=float),
        A0=float(app["A0_hat"]),
        sim_opts=sim_opts,
        candidates=cfg.candidates,
        w_amp=cfg.selector_w_amp,
        w_phi=cfg.selector_w_phi,
        max_nfev_per_model=cfg.max_nfev_select,
        verbose=cfg.verbose,
    )
    # Optional branch-score refinement: models that can reproduce both approach and retract
    # via stable branches receive a lower adjusted score.
    if cfg.add_branch_score_to_selection and ret is not None:
        new_details = []
        for detail in sel["details"]:
            detail = dict(detail)
            model = detail["model"]
            try:
                d_all = np.unique(np.r_[app["d_hat"], ret["d_hat"]])
                if d_all.size > cfg.branch_n_points:
                    d_all = d_all[_curve_subsample_indices_by_d(d_all, cfg.branch_n_points)]
                br = fmb.simulate_curve_all_branches(
                    d_all, model, detail["force_params"], sim_opts,
                    n_starts=cfg.branch_n_starts,
                    tol_A=cfg.branch_tol_A,
                    tol_phi_deg=cfg.branch_tol_phi_deg,
                    verbose=False,
                )
                score = _score_branch_result_against_approach_retract(br, app, ret, cfg)
            except Exception:
                score = 1e3
            detail["branch_score"] = float(score)
            detail["aicc_adjusted_with_branch"] = float(detail.get("aicc_adjusted", detail["aicc"]) + cfg.branch_score_weight * score)
            new_details.append(detail)
        new_details.sort(key=lambda r: r["aicc_adjusted_with_branch"])
        sel["details"] = new_details
        sel["ranking"] = [r["model"] for r in new_details]
        sel["best"] = new_details[0]["model"]
    return sel


def _interp_branch_track(track, d_query, key="A"):
    d = np.asarray(track["d"], dtype=float)
    y = np.asarray(track[key], dtype=float)
    order = np.argsort(d)
    if d.size < 2:
        return np.full_like(np.asarray(d_query, dtype=float), np.nan, dtype=float)
    return np.interp(np.asarray(d_query, dtype=float), d[order], y[order], left=np.nan, right=np.nan)


def _score_one_curve_to_branch_tracks(branch_result, curve, cfg: MultiForceFitConfig):
    d = np.asarray(curve["d_hat"], dtype=float)
    A_exp = np.asarray(curve["A_hat"], dtype=float)
    phi_exp = np.asarray(curve["phi_deg"], dtype=float)
    A0 = float(curve["A0_hat"])
    if len(branch_result.get("tracks", [])) == 0:
        return 1e3
    best = np.inf
    for tr in branch_result["tracks"]:
        A_pred = _interp_branch_track(tr, d, key="A")
        phi_pred = _interp_branch_track(tr, d, key="phi")
        mask = np.isfinite(A_pred) & np.isfinite(phi_pred)
        if np.sum(mask) < max(5, int(0.3 * len(d))):
            continue
        rA = (A_pred[mask] - A_exp[mask]) / max(A0, 1e-12)
        dphi = angle_diff_period_deg(phi_pred[mask], phi_exp[mask], period_deg=cfg.phase_period_deg)
        score = np.nanmean(rA ** 2) + (cfg.selector_w_phi ** 2) * np.nanmean((dphi / cfg.phase_period_deg) ** 2)
        best = min(best, float(score))
    return best if np.isfinite(best) else 1e3


def _score_branch_result_against_approach_retract(branch_result, approach_curve, retract_curve, cfg: MultiForceFitConfig):
    score_app = _score_one_curve_to_branch_tracks(branch_result, approach_curve, cfg)
    score_ret = _score_one_curve_to_branch_tracks(branch_result, retract_curve, cfg)
    return 100.0 * (score_app + score_ret)


def fit_one_fd_curve_multiforce_branchaware(
    curve: Dict,
    retract_curve: Optional[Dict] = None,
    model: Optional[str] = None,
    sim_opts=None,
    cfg: Optional[MultiForceFitConfig] = None,
    x0: Optional[np.ndarray] = None,
    bounds=None,
    output_branches: Optional[bool] = None,
):
    """Fit one approach FD curve using an automatically selected or user-specified force model."""
    fmb = _load_force_model_module()
    cfg = cfg or MultiForceFitConfig()
    if sim_opts is None:
        sim_opts = make_default_multiforce_sim_options()
    curve_fit = subsample_fd_curve(curve, cfg.n_fit_points)
    selection = None
    if model is None:
        model = cfg.selected_model
    if model is None:
        selection = select_force_model_for_fd_curve(curve, retract_curve, sim_opts=sim_opts, cfg=cfg)
        model = selection["best"]
        best_detail = next(d for d in selection["details"] if d["model"] == model)
        force_init = np.asarray(best_detail["force_params"], dtype=float)
    else:
        force_init = fmb.make_force_params(model)
    if x0 is None:
        C3_init = max(float(curve_fit["A0_hat"]) / max(float(sim_opts.Q), 1e-12), 1e-15)
        x0 = make_multiforce_single_x0(
            model,
            force_params=force_init,
            Q_init=float(sim_opts.Q),
            C3_init=C3_init,
            d_offset_hat=0.0,
            phi_offset_deg=0.0,
        )
    if bounds is None:
        bounds = make_multiforce_single_bounds(model, x0, cfg)
    result = least_squares(
        residual_single_curve_multiforce_branchaware,
        x0,
        bounds=bounds,
        args=(curve_fit, model, sim_opts, cfg),
        loss="soft_l1",
        f_scale=1.0,
        max_nfev=cfg.max_nfev_individual,
        verbose=0,
    )
    force_params, force_values, Q, C3, d_offset_hat, phi_offset_deg = unpack_multiforce_single_x(model, result.x)
    fit = {
        "drive_nm": float(curve.get("drive_nm", np.nan)),
        "model": model,
        "success": bool(result.success),
        "cost": float(result.cost),
        "x": result.x,
        "result": result,
        "force_params": force_params,
        "force_values": force_values,
        "Q": Q,
        "C3": C3,
        "d_offset_hat": d_offset_hat,
        "phi_offset_deg": phi_offset_deg,
        "selection": selection,
        "cfg": cfg,
        "sim_opts": sim_opts,
    }
    do_branches = cfg.output_branches if output_branches is None else bool(output_branches)
    if do_branches:
        fit["branches"] = compute_all_stable_branches_for_multiforce_fit(
            curve, fit, sim_opts=sim_opts, cfg=cfg, n_points=cfg.branch_n_points
        )
    return fit


def fit_individual_fd_curves_multiforce_branchaware(
    curves: List[Dict],
    retract_curves: Optional[List[Dict]] = None,
    model: Optional[str] = None,
    sim_opts=None,
    cfg: Optional[MultiForceFitConfig] = None,
):
    """Fit all approach FD curves independently, with optional automatic model selection."""
    cfg = cfg or MultiForceFitConfig()
    if sim_opts is None:
        sim_opts = make_default_multiforce_sim_options()
    fits = []
    for j, curve in enumerate(curves):
        ret = None if retract_curves is None else retract_curves[j]
        if cfg.verbose:
            print(f"\n[individual multiforce] {j+1}/{len(curves)} drive={curve.get('drive_nm', np.nan):.4g}")
        fit = fit_one_fd_curve_multiforce_branchaware(
            curve, retract_curve=ret, model=model, sim_opts=sim_opts, cfg=cfg
        )
        fits.append(fit)
        if cfg.verbose:
            print(
                f"  model={fit['model']}, cost={fit['cost']:.4g}, "
                f"Q={fit['Q']:.4g}, C3={fit['C3']:.4g}, "
                f"d_offset={fit['d_offset_hat']:.4g}, phi_offset={fit['phi_offset_deg']:.3g}"
            )
            print(f"  force={fit['force_values']}")
    return fits


def choose_global_force_model_from_individual_fits(individual_fits, method: str = "aicc_or_majority"):
    """Choose one shared force model for global fitting."""
    models = [f.get("model") for f in individual_fits if f.get("model") is not None]
    if not models:
        return "dmt"
    unique = sorted(set(models))
    if method == "majority":
        counts = {m: models.count(m) for m in unique}
        return max(counts, key=counts.get)
    # Prefer total adjusted AICc if selections are available; fall back to majority.
    scores = {m: 0.0 for m in unique}
    counts = {m: 0 for m in unique}
    for f in individual_fits:
        sel = f.get("selection")
        if sel is None:
            continue
        for d in sel.get("details", []):
            m = d["model"]
            if m not in scores:
                scores[m] = 0.0
                counts[m] = 0
            key = "aicc_adjusted_with_branch" if "aicc_adjusted_with_branch" in d else "aicc_adjusted"
            scores[m] += float(d.get(key, d.get("aicc", 1e6)))
            counts[m] += 1
    valid = {m: scores[m] for m in scores if counts[m] > 0}
    if valid:
        return min(valid, key=valid.get)
    counts = {m: models.count(m) for m in unique}
    return max(counts, key=counts.get)


def _global_force_init_from_individual_fits(model: str, individual_fits):
    fmb = _load_force_model_module()
    names = _model_fit_params(model)
    vals = []
    for fit in individual_fits:
        if fit.get("model") == model:
            fv = fit.get("force_values", {})
            if all(n in fv for n in names):
                vals.append([float(fv[n]) for n in names])
    if vals:
        arr = np.asarray(vals, dtype=float)
        med = np.exp(np.nanmedian(np.log(np.maximum(arr, 1e-300)), axis=0))
        return {n: float(v) for n, v in zip(names, med)}
    return dict(fmb.FORCE_DEFAULTS[model])


def make_multiforce_global_x0(curves, individual_fits, model: str, conv_L: float = 1.0, sim_opts=None):
    if sim_opts is None:
        sim_opts = make_default_multiforce_sim_options()
    names = _model_fit_params(model)
    force_init = _global_force_init_from_individual_fits(model, individual_fits)
    force_logs = [np.log(max(float(force_init[n]), 1e-300)) for n in names]
    Q_vals = [f["Q"] for f in individual_fits if np.isfinite(f.get("Q", np.nan))]
    Q0 = float(np.exp(np.nanmedian(np.log(np.maximum(Q_vals, 1e-300))))) if Q_vals else float(sim_opts.Q)
    drives_nm = np.array([c["drive_nm"] for c in curves], dtype=float)
    drive_scale = np.array([c.get("A0_hat", c["drive_nm"] * conv_L) for c in curves], dtype=float)
    u = normalized_log_drive(drives_nm)
    C3_ind = np.array([f.get("C3", np.nan) for f in individual_fits], dtype=float)
    if np.sum(np.isfinite(C3_ind) & (C3_ind > 0)) >= 3:
        y = np.log(np.maximum(C3_ind, 1e-300)) - np.log(np.maximum(drive_scale, 1e-300))
        X = np.column_stack([np.ones_like(u), u, u ** 2])
        coef, *_ = np.linalg.lstsq(X[np.isfinite(y)], y[np.isfinite(y)], rcond=None)
        log_gamma, b1, b2 = coef
    else:
        log_gamma, b1, b2 = np.log(max(float(sim_opts.C3) / max(np.nanmedian(drive_scale), 1e-12), 1e-300)), 0.0, 0.0
    d_offsets = np.array([f.get("d_offset_hat", 0.0) for f in individual_fits], dtype=float)
    phi_offsets = np.zeros(len(curves), dtype=float)
    return np.concatenate([
        np.asarray(force_logs + [np.log(Q0), log_gamma, b1, b2,
                                 np.log(max(sim_opts.w_contact, 1e-300)),
                                 np.log(max(sim_opts.gamma_lr, 1e-300)),
                                 np.log(max(sim_opts.lambda_lr, 1e-300)),
                                 np.log(max(sim_opts.gamma_contact, 1e-300)),
                                 0.0], dtype=float),
        d_offsets,
        phi_offsets,
    ])


def unpack_multiforce_global_x(x, curves, model: str, conv_L: float = 1.0):
    fmb = _load_force_model_module()
    names = _model_fit_params(model)
    nfp = len(names)
    x = np.asarray(x, dtype=float)
    force_values = {name: float(np.exp(x[i])) for i, name in enumerate(names)}
    force_params = fmb.make_force_params(model, **force_values)
    Q = float(np.exp(x[nfp]))
    log_gamma, b1, b2 = x[nfp + 1:nfp + 4]
    w_contact = float(np.exp(x[nfp + 4]))
    gamma_lr = float(np.exp(x[nfp + 5]))
    lambda_lr = float(np.exp(x[nfp + 6]))
    gamma_contact = float(np.exp(x[nfp + 7]))
    domega = float(x[nfp + 8])
    n = len(curves)
    d0 = nfp + 9
    d1 = d0 + n
    p0 = d1
    p1 = p0 + n
    d_offsets = x[d0:d1]
    phi_offsets = x[p0:p1]
    drives_nm = np.array([c["drive_nm"] for c in curves], dtype=float)
    drive_scale = np.array([c.get("A0_hat", c["drive_nm"] * conv_L) for c in curves], dtype=float)
    u = normalized_log_drive(drives_nm)
    C3_all = np.exp(log_gamma) * drive_scale * np.exp(b1 * u + b2 * u ** 2)
    return {
        "model": model,
        "force_values": force_values,
        "force_params": force_params,
        "Q": Q,
        "C3_all": C3_all,
        "log_gamma_C3": float(log_gamma),
        "b1_C3": float(b1),
        "b2_C3": float(b2),
        "w_contact": w_contact,
        "gamma_lr": gamma_lr,
        "lambda_lr": lambda_lr,
        "gamma_contact": gamma_contact,
        "domega": domega,
        "d_offsets_hat": d_offsets,
        "phi_offsets_deg": phi_offsets,
        "drives_nm": drives_nm,
    }


def make_multiforce_global_bounds(x0, curves, model: str, cfg: MultiForceFitConfig):
    names = _model_fit_params(model)
    nfp = len(names)
    n = len(curves)
    lower = np.asarray(x0, dtype=float).copy()
    upper = np.asarray(x0, dtype=float).copy()
    lower[:nfp] -= cfg.log_decades_force * np.log(10.0)
    upper[:nfp] += cfg.log_decades_force * np.log(10.0)
    lower[nfp] -= cfg.log_decades_Q * np.log(10.0)
    upper[nfp] += cfg.log_decades_Q * np.log(10.0)
    lower[nfp + 1] -= cfg.log_decades_C3 * np.log(10.0)
    upper[nfp + 1] += cfg.log_decades_C3 * np.log(10.0)
    lower[nfp + 2] = -4.0
    upper[nfp + 2] = +4.0
    lower[nfp + 3] = -4.0
    upper[nfp + 3] = +4.0
    lower[nfp + 4:nfp + 8] -= cfg.log_decades_damping * np.log(10.0)
    upper[nfp + 4:nfp + 8] += cfg.log_decades_damping * np.log(10.0)
    lower[nfp + 8] = -0.03
    upper[nfp + 8] = +0.03
    d0 = nfp + 9
    d1 = d0 + n
    p0 = d1
    p1 = p0 + n
    lower[d0:d1] = -cfg.max_abs_d_offset_hat
    upper[d0:d1] = +cfg.max_abs_d_offset_hat
    lower[p0:p1] = -cfg.max_abs_phi_offset_deg
    upper[p0:p1] = +cfg.max_abs_phi_offset_deg
    return lower, upper


def residual_global_multiforce_branchaware(x, curves_fit, model: str, conv_L: float, base_sim_opts, cfg: MultiForceFitConfig):
    p = unpack_multiforce_global_x(x, curves_fit, model=model, conv_L=conv_L)
    residuals = []
    omega_base = 1.0 + p["domega"]
    if omega_base <= 0:
        return np.ones(100) * 1e6
    for j, curve in enumerate(curves_fit):
        opts = _copy_sim_options(base_sim_opts)
        opts.w_contact = p["w_contact"]
        opts.gamma_lr = p["gamma_lr"]
        opts.lambda_lr = p["lambda_lr"]
        opts.gamma_contact = p["gamma_contact"]
        try:
            A_sim, phi_sim, _ = _simulate_multiforce_curve_for_fit(
                curve, model, p["force_params"], p["Q"], p["C3_all"][j],
                p["d_offsets_hat"][j], opts, omega_scale=omega_base,
            )
        except Exception:
            return np.ones(sum(2 * len(c["d_hat"]) for c in curves_fit) + 10) * 1e6
        A_exp = np.asarray(curve["A_hat"], dtype=float)
        phi_exp = np.asarray(curve["phi_deg"], dtype=float)
        d_hat = np.asarray(curve["d_hat"], dtype=float)
        A0 = float(curve["A0_hat"])
        residuals.append(cfg.w_amp * (A_sim - A_exp) / max(A0, 1e-12))
        res_phi, _ = _phase_residual_for_fit(phi_sim, phi_exp, d_hat, A_exp, A0, cfg, p["phi_offsets_deg"][j])
        residuals.append(res_phi)
    if cfg.d_offset_prior_hat is not None:
        residuals.append(p["d_offsets_hat"] / cfg.d_offset_prior_hat)
    if cfg.phi_offset_prior_deg is not None:
        residuals.append(p["phi_offsets_deg"] / cfg.phi_offset_prior_deg)
    residuals.append(np.asarray([p["b1_C3"] / 2.0, p["b2_C3"] / 2.0]))
    return np.concatenate([np.ravel(r) for r in residuals])


def make_multiforce_global_jac_sparsity(x0, curves_fit, model: str, cfg: MultiForceFitConfig):
    """
    Sparsity pattern for the global finite-difference Jacobian.

    Each curve residual depends on all shared parameters but only that curve's
    distance and phase offsets. Without this hint, least_squares perturbs every
    per-curve offset independently for every Jacobian evaluation, which is very
    expensive for RK45 simulations.
    """
    names = _model_fit_params(model)
    nfp = len(names)
    n_curves = len(curves_fit)
    n_shared = nfp + 9
    d0 = n_shared
    p0 = d0 + n_curves
    n_params = len(x0)

    n_rows = 0
    for curve in curves_fit:
        n_rows += 2 * len(curve["d_hat"])
    if cfg.d_offset_prior_hat is not None:
        n_rows += n_curves
    if cfg.phi_offset_prior_deg is not None:
        n_rows += n_curves
    n_rows += 2  # b1/b2 smoothness prior

    S = lil_matrix((n_rows, n_params), dtype=int)
    row = 0
    shared_cols = np.arange(n_shared)

    for j, curve in enumerate(curves_fit):
        m = len(curve["d_hat"])
        rows = slice(row, row + 2 * m)
        S[rows, shared_cols] = 1
        S[rows, d0 + j] = 1
        S[rows, p0 + j] = 1
        row += 2 * m

    if cfg.d_offset_prior_hat is not None:
        for j in range(n_curves):
            S[row + j, d0 + j] = 1
        row += n_curves

    if cfg.phi_offset_prior_deg is not None:
        for j in range(n_curves):
            S[row + j, p0 + j] = 1
        row += n_curves

    S[row, nfp + 2] = 1
    S[row + 1, nfp + 3] = 1
    return S.tocsr()


def fit_global_fd_curves_multiforce_branchaware(
    curves: List[Dict],
    individual_fits: List[Dict],
    model: Optional[str] = None,
    conv_L: float = 1.0,
    sim_opts=None,
    cfg: Optional[MultiForceFitConfig] = None,
):
    """Global shared-physics fit after individual multi-force fits."""
    cfg = cfg or MultiForceFitConfig()
    if sim_opts is None:
        sim_opts = make_default_multiforce_sim_options()
    if model is None:
        model = cfg.selected_model or choose_global_force_model_from_individual_fits(individual_fits)
    if cfg.verbose:
        print(f"\n[global multiforce] using shared force model: {model}")
    curves_fit = [subsample_fd_curve(c, cfg.n_fit_points) for c in curves]
    x0 = make_multiforce_global_x0(curves_fit, individual_fits, model, conv_L=conv_L, sim_opts=sim_opts)
    bounds = make_multiforce_global_bounds(x0, curves_fit, model, cfg)
    jac_sparsity = None
    if cfg.use_global_jac_sparsity:
        jac_sparsity = make_multiforce_global_jac_sparsity(x0, curves_fit, model, cfg)
    result = least_squares(
        residual_global_multiforce_branchaware,
        x0,
        bounds=bounds,
        args=(curves_fit, model, conv_L, sim_opts, cfg),
        loss="soft_l1",
        f_scale=1.0,
        max_nfev=cfg.max_nfev_global,
        verbose=2 if cfg.verbose else 0,
        jac_sparsity=jac_sparsity,
    )
    p = unpack_multiforce_global_x(result.x, curves_fit, model=model, conv_L=conv_L)
    p["success"] = bool(result.success)
    p["cost"] = float(result.cost)
    p["x"] = result.x
    p["result"] = result
    p["cfg"] = cfg
    p["sim_opts"] = sim_opts
    if cfg.output_branches:
        p["branches"] = []
        for j, curve in enumerate(curves):
            fit_j = {
                "model": model,
                "force_params": p["force_params"],
                "Q": p["Q"],
                "C3": p["C3_all"][j],
                "d_offset_hat": p["d_offsets_hat"][j],
                "phi_offset_deg": p["phi_offsets_deg"][j],
                "w_contact": p["w_contact"],
                "gamma_lr": p["gamma_lr"],
                "lambda_lr": p["lambda_lr"],
                "gamma_contact": p["gamma_contact"],
            }
            p["branches"].append(compute_all_stable_branches_for_multiforce_fit(
                curve, fit_j, sim_opts=sim_opts, cfg=cfg, n_points=cfg.branch_n_points
            ))
    return p


def compute_all_stable_branches_for_multiforce_fit(
    curve: Dict,
    fit: Dict,
    sim_opts=None,
    cfg: Optional[MultiForceFitConfig] = None,
    n_points: Optional[int] = None,
):
    """Compute all stable branches for a fitted curve using multistart steady states."""
    fmb = _load_force_model_module()
    cfg = cfg or fit.get("cfg", MultiForceFitConfig())
    if sim_opts is None:
        sim_opts = fit.get("sim_opts", make_default_multiforce_sim_options())
    opts = _copy_sim_options(sim_opts)
    opts.Q = float(fit["Q"])
    opts.C3 = float(fit["C3"])
    opts.d_offset_hat = float(fit.get("d_offset_hat", 0.0))
    opts.omega_drive_hat = float(curve.get("omega_drive_hat", 1.0))
    opts.omega_ref_hat = float(curve.get("omega_ref_hat", opts.omega_drive_hat))
    for key in ("w_contact", "gamma_lr", "lambda_lr", "gamma_contact"):
        if key in fit:
            setattr(opts, key, float(fit[key]))
    idx = _curve_subsample_indices_by_d(curve["d_hat"], n_points or cfg.branch_n_points)
    d_grid = np.asarray(curve["d_hat"], dtype=float)[idx]
    return fmb.simulate_curve_all_branches(
        d_grid,
        fit["model"],
        np.asarray(fit["force_params"], dtype=float),
        opts,
        n_starts=cfg.branch_n_starts,
        tol_A=cfg.branch_tol_A,
        tol_phi_deg=cfg.branch_tol_phi_deg,
        verbose=False,
    )


def predict_curve_multiforce_fit(curve: Dict, fit: Dict, sim_opts=None, cfg: Optional[MultiForceFitConfig] = None):
    """Predict A/phase for one fitted curve on the full input distance grid."""
    cfg = cfg or fit.get("cfg", MultiForceFitConfig())
    if sim_opts is None:
        sim_opts = fit.get("sim_opts", make_default_multiforce_sim_options())
    opts = _copy_sim_options(sim_opts)
    for key in ("w_contact", "gamma_lr", "lambda_lr", "gamma_contact"):
        if key in fit:
            setattr(opts, key, float(fit[key]))
    A_sim, phi_sim, raw = _simulate_multiforce_curve_for_fit(
        curve,
        fit["model"],
        np.asarray(fit["force_params"], dtype=float),
        float(fit["Q"]),
        float(fit.get("C3", fit.get("C3_all", [np.nan])[0])),
        float(fit.get("d_offset_hat", 0.0)),
        opts,
    )
    A_exp = np.asarray(curve["A_hat"], dtype=float)
    phi_exp = np.asarray(curve["phi_deg"], dtype=float)
    res_phi, phi_auto = _phase_residual_for_fit(
        phi_sim, phi_exp, curve["d_hat"], A_exp, float(curve["A0_hat"]),
        cfg, float(fit.get("phi_offset_deg", 0.0)),
    )
    phi_plot = transform_phase_deg(phi_sim, mode=cfg.phase_mode) + phi_auto + float(fit.get("phi_offset_deg", 0.0))
    return {"A": A_sim, "phi_raw": phi_sim, "phi": phi_plot, "raw": raw, "phi_auto_offset_deg": phi_auto}


def predict_curve_multiforce_global_fit(curve: Dict, global_fit: Dict, curve_index: int, sim_opts=None, cfg: Optional[MultiForceFitConfig] = None):
    """Predict one curve from a global multi-force fit."""
    cfg = cfg or global_fit.get("cfg", MultiForceFitConfig())
    if sim_opts is None:
        sim_opts = global_fit.get("sim_opts", make_default_multiforce_sim_options())
    fit_j = {
        "model": global_fit["model"],
        "force_params": global_fit["force_params"],
        "Q": global_fit["Q"],
        "C3": global_fit["C3_all"][curve_index],
        "d_offset_hat": global_fit["d_offsets_hat"][curve_index],
        "phi_offset_deg": global_fit["phi_offsets_deg"][curve_index],
        "w_contact": global_fit["w_contact"],
        "gamma_lr": global_fit["gamma_lr"],
        "lambda_lr": global_fit["lambda_lr"],
        "gamma_contact": global_fit["gamma_contact"],
        "cfg": cfg,
        "sim_opts": sim_opts,
    }
    return predict_curve_multiforce_fit(curve, fit_j, sim_opts=sim_opts, cfg=cfg)


def plot_one_multiforce_fit_overlay(curve, fit, sim_opts=None, cfg: Optional[MultiForceFitConfig] = None, show_branches: bool = True):
    """Plot measured approach FD curve, fitted prediction, and optionally stable branches."""
    cfg = cfg or fit.get("cfg", MultiForceFitConfig())
    pred = predict_curve_multiforce_fit(curve, fit, sim_opts=sim_opts, cfg=cfg)
    fig, ax = plt.subplots(1, 2, figsize=(9, 3.5))
    d = np.asarray(curve["d_hat"], dtype=float)
    order = np.argsort(d)
    ax[0].plot(d[order], np.asarray(curve["A_hat"])[order], "o", ms=3, label="exp")
    ax[0].plot(d[order], pred["A"][order], "-", lw=2, label=f"fit {fit['model']}")
    ax[1].plot(d[order], np.asarray(curve["phi_deg"])[order], "o", ms=3, label="exp")
    ax[1].plot(d[order], pred["phi"][order], "-", lw=2, label=f"fit {fit['model']}")
    if show_branches:
        br = fit.get("branches")
        if br is None:
            try:
                br = compute_all_stable_branches_for_multiforce_fit(curve, fit, sim_opts=sim_opts, cfg=cfg, n_points=cfg.branch_n_points)
            except Exception:
                br = None
        if br is not None:
            for tr in br.get("tracks", []):
                ax[0].plot(tr["d"], tr["A"], "--", lw=1, alpha=0.8, label=f"{tr['label']} branch")
                ax[1].plot(tr["d"], tr["phi"], "--", lw=1, alpha=0.8, label=f"{tr['label']} branch")
    ax[0].set_xlabel("d_hat")
    ax[0].set_ylabel("A_hat")
    ax[1].set_xlabel("d_hat")
    ax[1].set_ylabel("phase (deg)")
    ax[0].legend(fontsize=8)
    ax[1].legend(fontsize=8)
    fig.suptitle(f"drive={curve.get('drive_nm', np.nan):.4g}, model={fit['model']}, cost={fit.get('cost', np.nan):.4g}")
    plt.tight_layout()
    return fig, ax


def plot_global_multiforce_fit_overlays(curves, global_fit, sim_opts=None, cfg: Optional[MultiForceFitConfig] = None, max_cols: int = 4):
    """Plot global-fit overlays for all curves."""
    cfg = cfg or global_fit.get("cfg", MultiForceFitConfig())
    n = len(curves)
    ncols = min(max_cols, n)
    nrows = int(np.ceil(n / ncols))
    fig, ax = plt.subplots(nrows, ncols, figsize=(4.0 * ncols, 3.0 * nrows), squeeze=False)
    for j, curve in enumerate(curves):
        r, c = divmod(j, ncols)
        pred = predict_curve_multiforce_global_fit(curve, global_fit, j, sim_opts=sim_opts, cfg=cfg)
        d = np.asarray(curve["d_hat"], dtype=float)
        order = np.argsort(d)
        ax[r, c].plot(d[order], np.asarray(curve["A_hat"])[order], "o", ms=2, label="exp A")
        ax[r, c].plot(d[order], pred["A"][order], "-", lw=1.5, label="fit A")
        ax2 = ax[r, c].twinx()
        ax2.plot(d[order], np.asarray(curve["phi_deg"])[order], ".", ms=2, alpha=0.5, label="exp phi")
        ax2.plot(d[order], pred["phi"][order], "--", lw=1.2, alpha=0.8, label="fit phi")
        ax[r, c].set_title(f"drive={curve.get('drive_nm', np.nan):.3g}")
        ax[r, c].set_xlabel("d_hat")
        ax[r, c].set_ylabel("A")
        ax2.set_ylabel("phi")
    for j in range(n, nrows * ncols):
        r, c = divmod(j, ncols)
        ax[r, c].axis("off")
    fig.suptitle(f"Global multi-force fit: model={global_fit['model']}, cost={global_fit.get('cost', np.nan):.4g}")
    plt.tight_layout()
    return fig, ax


def summarize_multiforce_individual_fits(individual_fits):
    """Compact table-like summary as a list of dicts."""
    rows = []
    for f in individual_fits:
        row = {
            "drive_nm": f.get("drive_nm", np.nan),
            "model": f.get("model", ""),
            "cost": f.get("cost", np.nan),
            "Q": f.get("Q", np.nan),
            "C3": f.get("C3", np.nan),
            "d_offset_hat": f.get("d_offset_hat", np.nan),
            "phi_offset_deg": f.get("phi_offset_deg", np.nan),
        }
        row.update({f"force_{k}": v for k, v in f.get("force_values", {}).items()})
        rows.append(row)
    return rows


def run_full_multiforce_fd_workflow(
    curves: List[Dict],
    retract_curves: Optional[List[Dict]] = None,
    conv_L: float = 1.0,
    sim_opts=None,
    cfg: Optional[MultiForceFitConfig] = None,
):
    """Convenience function: individual auto-selection/fits, then global fit."""
    cfg = cfg or MultiForceFitConfig()
    if sim_opts is None:
        sim_opts = make_default_multiforce_sim_options()
    individual = fit_individual_fd_curves_multiforce_branchaware(
        curves, retract_curves=retract_curves, model=cfg.selected_model,
        sim_opts=sim_opts, cfg=cfg,
    )
    global_fit = fit_global_fd_curves_multiforce_branchaware(
        curves, individual, model=cfg.selected_model, conv_L=conv_L,
        sim_opts=sim_opts, cfg=cfg,
    )
    return {
        "individual_fits": individual,
        "individual_summary": summarize_multiforce_individual_fits(individual),
        "global_fit": global_fit,
        "cfg": cfg,
        "sim_opts": sim_opts,
    }
