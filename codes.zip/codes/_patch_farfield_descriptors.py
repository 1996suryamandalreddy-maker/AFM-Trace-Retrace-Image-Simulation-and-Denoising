"""Add far-field descriptors to the Stage-1 catalogue.

Rationale.  The cali_fd FD library samples the cantilever response far from
contact; d_AR, A_AR, d_contact, slope_contact, dphi_total are NaN on the
experimental side for most curves, so the PINN's only finite training signal is
A0 — which the real RK45 analytic prior already matches perfectly.  Adding
quantities that are well-defined far from contact gives the PINN spatial signal
to learn from across the full library.

Three new descriptors added at each soft-amplitude level c ∈ {0.5, 0.7}:

- d_c          : tip-sample distance at which A = c · A0
- slope_c      : −dA/dd at d_c (proxy for cantilever-sensitivity / Q_eff;
                  Q_eff ≈ A0 / slope_c in the linear response regime)
- phi_c        : phase at d_c (captures soft-contact dissipation signature)

Patches three cells:

- Cell 7  : extend Stage1Descriptors dataclass with the six new fields.
- Cell 9  : extend `extract_stage1` to compute them (linear interpolation, no
            contact required).
- Cell 35 : extend `differentiable_stage1` with smooth versions of d_c, slope_c,
            phi_c at c = 0.5 and 0.7; update `descriptor_loss` to accept the
            larger target tensor.
- Cell 36 : extend the PINN training target to (n_curve, 10) — A0, d_AR, A_AR,
            d_contact, d_50, slope_50, phi_50, d_70, slope_70, phi_70.

Run once after editing:
    python codes/_patch_farfield_descriptors.py
"""
import json
from pathlib import Path

NB_PATH = (Path(__file__).resolve().parents[1]
            / 'Descriptor-aligned DT-SPM framework.ipynb')


def _set(nb, idx, source_text):
    nb['cells'][idx]['source'] = source_text.splitlines(keepends=True)
    nb['cells'][idx]['outputs'] = []
    nb['cells'][idx]['execution_count'] = None


# -------------------------------------------------------------------------
CELL_7 = '''@dataclass
class Stage1Descriptors:
    """Read from one FD curve (sim or exp).

    PATCH: extended with six far-field descriptors (d_50, slope_50, phi_50 and
    d_70, slope_70, phi_70) at soft-amplitude reference levels c·A0 with c
    in {0.5, 0.7}.  These quantities are well-defined far from contact, so
    they remain finite on the cali_fd FD library where the contact-regime
    descriptors (d_AR, A_AR, d_contact, slope_contact, dphi_total) are NaN.
    The PINN training signal now has spatial structure to learn from.
    """
    # Free-air calibration
    A0: float = float('nan')
    # Contact-regime descriptors (often NaN on FD libraries that stop before contact)
    d_AR: float = float('nan'); A_AR: float = float('nan')
    d_contact: float = float('nan'); slope_contact: float = float('nan')
    dphi_total: float = float('nan'); branch: float = float('nan')
    # Far-field descriptors at A = 0.5 · A0  (new)
    d_50: float = float('nan'); slope_50: float = float('nan'); phi_50: float = float('nan')
    # Far-field descriptors at A = 0.7 · A0  (new)
    d_70: float = float('nan'); slope_70: float = float('nan'); phi_70: float = float('nan')

@dataclass
class Stage2Descriptors:
    """Operating-point summary at chosen (drive, setpoint)."""
    d_op: float = float('nan');  A_op: float = float('nan');  phi_op: float = float('nan')
    loop_gain: float = float('nan')
    PI_margin: float = float('nan')

@dataclass
class Stage3Descriptors:
    """Read from trace + retrace of one condition (sim or exp)."""
    Q_align: float = float('nan'); Q_stab: float = float('nan')
    Q_grad:  float = float('nan'); Q_safety: float = float('nan')
    Q_range: float = float('nan'); regime: str = 'unknown'

@dataclass
class Rewards:
    """Loss-side and operator-side rewards built from descriptors."""
    L_desc:        float = float('nan')   # standardised descriptor distance
    L_consistency: float = float('nan')   # chain-Jacobian penalty
    L_ODE:         float = float('nan')   # PINN ODE residual
    L_sparse:      float = float('nan')   # PINN L1 on θ_NN
    operator_Q:    float = float('nan')   # weighted single-number scan quality
    anomaly_prob:  float = float('nan')
    regime_pred:   str   = 'unknown'

print('Stage1Descriptors:', Stage1Descriptors())
print('Stage2Descriptors:', Stage2Descriptors())
print('Stage3Descriptors:', Stage3Descriptors())
print('Rewards          :', Rewards())
'''


# -------------------------------------------------------------------------
CELL_9 = '''fd = np.load(FD_PATH)
fd_drive_raw = fd['drive']
fd_height = fd['height']; fd_amp = fd['amp']; fd_phase = fd['phase']
fd_drive_nm = np.array([np.nanmean(fd_amp[i, -10:]) for i in range(fd_amp.shape[0])], float)
print(f'FD library: {fd_amp.shape[0]} curves, drives = {fd_drive_nm.round(1)} nm')

def _crossing_descriptors_at(d, A, phi, target_A):
    """Return (d_c, slope_c, phi_c) at the first d where A crosses target_A.
    `d, A, phi` must already be sorted by d ascending.
    """
    cidx = np.where(np.diff(np.sign(A - target_A)) != 0)[0]
    if cidx.size == 0:
        return float('nan'), float('nan'), float('nan')
    k = cidx[0]
    denom = (A[k+1] - A[k]) + 1e-12
    d_c = float(d[k] + (target_A - A[k]) / denom * (d[k+1] - d[k]))
    # Local slope by 4-pixel finite difference around d_c (or 2-pixel near the edge)
    if k + 4 < d.size:
        slope_c = float(- (A[k+4] - A[k]) / (d[k+4] - d[k] + 1e-12))
    else:
        slope_c = float(- (A[k+1] - A[k]) / (d[k+1] - d[k] + 1e-12))
    phi_c = float(np.interp(d_c, d, phi))
    return d_c, slope_c, phi_c


def extract_stage1(d, A, phi, *, contact_frac=0.2,
                     soft_levels=(0.5, 0.7)) -> Stage1Descriptors:
    """Read the seven operational descriptors + six far-field descriptors from
    a single FD curve.  The far-field descriptors (d_c, slope_c, phi_c at
    c·A0 for c in {0.5, 0.7}) remain finite when the curve does not reach
    contact.
    """
    d = np.asarray(d, float).ravel(); A = np.asarray(A, float).ravel()
    phi = np.asarray(phi, float).ravel()
    order = np.argsort(d); d, A, phi = d[order], A[order], phi[order]
    valid = np.isfinite(d) & np.isfinite(A) & np.isfinite(phi)
    if valid.sum() < 8: return Stage1Descriptors()
    d, A, phi = d[valid], A[valid], phi[valid]
    A0 = float(np.nanmedian(A[-max(5, int(0.1 * A.size)):]))

    # ----- Contact-regime descriptors (often NaN if FD curve does not reach contact)
    cross = np.where(np.diff(np.sign(phi - 90.0)) != 0)[0]
    if cross.size > 0:
        k = cross[-1]
        d_AR = float(d[k] + (90 - phi[k]) / (phi[k+1] - phi[k] + 1e-12) * (d[k+1] - d[k]))
        A_AR = float(np.interp(d_AR, d, A))
    else:
        d_AR = A_AR = float('nan')
    d_c, sc, phi_c = _crossing_descriptors_at(d, A, phi, contact_frac * A0)
    dphi = (float(phi_c - np.nanmedian(phi[-5:])) if np.isfinite(phi_c) else float('nan'))
    soft = (A > 0.3 * A0) & (A < 0.7 * A0)
    branch = (1.0 if soft.sum() >= 4 and np.polyfit(A[soft], phi[soft], 1)[0] > 0
                else -1.0 if soft.sum() >= 4 else float('nan'))

    # ----- Far-field descriptors at soft-amplitude reference levels
    d_50, slope_50, phi_50 = _crossing_descriptors_at(d, A, phi, soft_levels[0] * A0)
    d_70, slope_70, phi_70 = _crossing_descriptors_at(d, A, phi, soft_levels[1] * A0)

    return Stage1Descriptors(
        A0=A0,
        d_AR=d_AR, A_AR=A_AR,
        d_contact=d_c, slope_contact=sc,
        dphi_total=dphi, branch=branch,
        d_50=d_50, slope_50=slope_50, phi_50=phi_50,
        d_70=d_70, slope_70=slope_70, phi_70=phi_70,
    )

fd_desc_exp = [extract_stage1(fd_height[i], fd_amp[i], fd_phase[i])
                for i in range(fd_amp.shape[0])]
fd_desc_df_exp = pd.DataFrame([asdict(d) for d in fd_desc_exp])
fd_desc_df_exp['drive_nm'] = fd_drive_nm
print('Per-descriptor finite-count across the 15 FD library curves:')
print((fd_desc_df_exp.notna() & np.isfinite(fd_desc_df_exp.select_dtypes(include="number"))).sum().to_dict())
fd_desc_df_exp.round(2)
'''


# -------------------------------------------------------------------------
# Cell 35 — extend differentiable_stage1 with the soft-amplitude descriptors
# and update descriptor_loss to consume the new target columns.
# -------------------------------------------------------------------------
CELL_35 = '''# Optional: PyTorch required.  Comment out the cell if you only want the descriptor analysis above.
try:
    import torch, torch.nn as nn
    TORCH_OK = True
except Exception as e:
    print('PyTorch not available — PINN section skipped'); TORCH_OK = False

if TORCH_OK:
    class FDPriorPINN(nn.Module):
        """Analytic prior (frozen real RK45) + sparse NN correction overlay.

        See cell 10 for the analytic backbone.  The NN forward takes pre-computed
        analytic buffers and adds a learned residual ΔA, Δφ.
        """
        def __init__(self, user: UserInputs, hidden=64, depth=3):
            super().__init__()
            self._user = user
            layers, in_dim = [], 2
            for _ in range(depth):
                layers += [nn.Linear(in_dim, hidden), nn.Tanh()]; in_dim = hidden
            layers += [nn.Linear(in_dim, 2)]
            self.correction = nn.Sequential(*layers)
            for m in self.correction:
                if isinstance(m, nn.Linear):
                    nn.init.normal_(m.weight, std=1e-3); nn.init.zeros_(m.bias)

        def forward(self, d, V, *, A_analytic_buffer, phi_analytic_buffer):
            delta = self.correction(torch.stack([d, V], dim=-1))
            return A_analytic_buffer + delta[..., 0], phi_analytic_buffer + delta[..., 1]

    def soft_argmin(values, beta=20.0):
        w = torch.softmax(-beta * values.abs(), dim=-1)
        idx_grid = torch.arange(values.shape[-1], device=values.device, dtype=values.dtype)
        return (w * idx_grid).sum(dim=-1)

    def _soft_gather(t, i, beta=20.0):
        weights = torch.softmax(-beta * (
            torch.arange(t.shape[-1], device=t.device, dtype=t.dtype)
            - i.unsqueeze(-1)).abs(), dim=-1)
        return (t * weights).sum(dim=-1)

    def differentiable_stage1(A, phi, d, contact_frac=0.2,
                                 soft_levels=(0.5, 0.7)):
        """Smooth (differentiable) versions of the Stage-1 descriptors.

        Returns a tuple (A0, d_AR, A_AR, d_contact, slope_contact,
        d_50, slope_50, phi_50, d_70, slope_70, phi_70).
        """
        A0 = A[..., -10:].mean(dim=-1)
        # A→R transition
        idx_AR = soft_argmin(phi - 90.0)
        d_AR = _soft_gather(d, idx_AR); A_AR = _soft_gather(A, idx_AR)
        # Contact regime
        idx_c = soft_argmin(A - (contact_frac * A0).unsqueeze(-1))
        d_c   = _soft_gather(d, idx_c)
        i4    = (idx_c + 4).clamp(max=A.shape[-1] - 1.0)
        slope_c = -(_soft_gather(A, i4) - _soft_gather(A, idx_c)) / 4.0
        # Far-field crossings at c · A0
        outs = [A0, d_AR, A_AR, d_c, slope_c]
        for c in soft_levels:
            idx_s = soft_argmin(A - (c * A0).unsqueeze(-1))
            d_s = _soft_gather(d, idx_s)
            i4s = (idx_s + 4).clamp(max=A.shape[-1] - 1.0)
            slope_s = -(_soft_gather(A, i4s) - _soft_gather(A, idx_s)) / 4.0
            phi_s = _soft_gather(phi, idx_s)
            outs.extend([d_s, slope_s, phi_s])
        return tuple(outs)

    # Target columns matching extract_stage1 output:
    # [A0, d_AR, A_AR, d_contact, d_50, slope_50, phi_50, d_70, slope_70, phi_70]
    TARGET_COLS = ['A0', 'd_AR', 'A_AR', 'd_contact',
                    'd_50', 'slope_50', 'phi_50',
                    'd_70', 'slope_70', 'phi_70']

    def descriptor_loss(A, phi, d, target):
        """NaN-masked descriptor distance over the extended catalogue.

        PATCH: target is now (n_curve, 10) covering both contact-regime
        descriptors (often NaN on this dataset) and far-field descriptors
        (finite for every curve).  Masked entries contribute zero to the loss;
        per-descriptor standardisation uses only finite entries.
        """
        a0, dar, aar, dc, sc, d50, s50, p50, d70, s70, p70 = differentiable_stage1(A, phi, d)
        sim = torch.stack([a0, dar, aar, dc, d50, s50, p50, d70, s70, p70], dim=-1)
        mask = torch.isfinite(target)
        scales = []
        for k in range(target.shape[-1]):
            t = target[:, k][mask[:, k]]
            scales.append(t.std(unbiased=False).clamp(min=1e-3) if t.numel() > 1
                            else torch.tensor(1.0))
        scale_t = torch.stack(scales)
        sq = ((sim - torch.where(mask, target, sim.detach())) / scale_t).pow(2)
        sq = torch.where(mask, sq, torch.zeros_like(sq))
        n_finite = mask.float().sum().clamp(min=1.0)
        return sq.sum() / n_finite

    def ODE_residual(A, phi, d, V, model):
        dAdd = (A[..., 2:] - A[..., :-2]) / (d[..., 2:] - d[..., :-2] + 1e-9)
        dphi_dd = (phi[..., 2:] - phi[..., :-2]) / (d[..., 2:] - d[..., :-2] + 1e-9)
        return (dAdd ** 2 + 0.01 * dphi_dd ** 2).mean()

    print('FDPriorPINN + extended descriptor catalogue (A0, d_AR, A_AR, d_contact,')
    print('              d_50, slope_50, phi_50, d_70, slope_70, phi_70) ready.')
'''


# -------------------------------------------------------------------------
CELL_36 = '''if TORCH_OK:
    import time as _time

    n_curve = fd_amp.shape[0]
    d_T   = torch.tensor(fd_height, dtype=torch.float32)
    A_T   = torch.tensor(fd_amp,    dtype=torch.float32)
    phi_T = torch.tensor(fd_phase,  dtype=torch.float32)
    V_T   = torch.tensor(fd_drive_nm, dtype=torch.float32).unsqueeze(-1).expand_as(d_T)

    # PATCH: target tensor extended to 10 columns covering both contact-regime
    # descriptors and the new far-field descriptors.  NaN entries (typical for
    # contact-regime descriptors on the cali_fd library) are KEPT and masked
    # out in descriptor_loss.
    target = torch.tensor(
        np.stack([fd_desc_df_exp[c].to_numpy(float) for c in TARGET_COLS], axis=-1),
        dtype=torch.float32,
    )
    print('Target shape:', tuple(target.shape),
           ' finite per column:', [int(torch.isfinite(target[:, k]).sum()) for k in range(target.shape[1])])

    print('Pre-computing analytic baseline on FD library drives ...')
    t0 = _time.time()
    A_baseline = np.zeros_like(fd_amp, dtype=float)
    phi_baseline = np.zeros_like(fd_phase, dtype=float)
    for i, V in enumerate(fd_drive_nm):
        A_b, phi_b = analytic_FD_real(fd_height[i], float(V), user=USER)
        A_baseline[i]  = A_b
        phi_baseline[i] = phi_b
    A_base_T   = torch.tensor(A_baseline, dtype=torch.float32)
    phi_base_T = torch.tensor(phi_baseline, dtype=torch.float32)
    print(f'  done in {_time.time()-t0:.1f}s')

    model = FDPriorPINN(USER)
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    LAMBDA_R, LAMBDA_S = 1e-3, 1e-4

    history = []
    N_EPOCH_DEMO = 1000    # raise to 5000+ for production runs
    for epoch in range(N_EPOCH_DEMO):
        A_sim, phi_sim = model(d_T, V_T,
                                 A_analytic_buffer=A_base_T,
                                 phi_analytic_buffer=phi_base_T)
        L_d = descriptor_loss(A_sim, phi_sim, d_T, target)
        L_R = ODE_residual(A_sim, phi_sim, d_T, V_T, model)
        L_s = sum(p.abs().sum() for p in model.correction.parameters())
        loss = L_d + LAMBDA_R * L_R + LAMBDA_S * L_s
        opt.zero_grad(); loss.backward(); opt.step()
        history.append((float(loss), float(L_d), float(L_R), float(L_s)))
    history = np.array(history)
    print(f'After {N_EPOCH_DEMO} epochs:  L_total={history[-1,0]:.4f}  L_desc={history[-1,1]:.4f}  L_sparse={history[-1,3]:.2f}')

    fig, ax = plt.subplots(figsize=(7.0, 3.0), constrained_layout=True)
    ax.semilogy(history[:,0], color='k',  label='total')
    ax.semilogy(history[:,1], color=PALETTE['PI'], label='descriptor')
    ax.semilogy(history[:,2], color=PALETTE['hybrid'], label='ODE residual')
    ax.semilogy(history[:,3], color=PALETTE['data-driven'], label='sparsity')
    ax.set_xlabel('epoch'); ax.set_ylabel('loss')
    ax.set_title(f'PINN training (real prior + extended descriptors, {N_EPOCH_DEMO} epochs)')
    ax.legend(frameon=False, fontsize=8)
    fig.savefig(FIG_DIR / 'pinn_training_history.png')
'''


def main():
    nb = json.load(open(NB_PATH))
    _set(nb, 7,  CELL_7)
    _set(nb, 9,  CELL_9)
    _set(nb, 35, CELL_35)
    _set(nb, 36, CELL_36)
    json.dump(nb, open(NB_PATH, 'w'), indent=1)
    print('Patched cells 7, 9, 35, 36.')


if __name__ == '__main__':
    main()
