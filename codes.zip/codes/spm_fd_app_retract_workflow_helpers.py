
"""
spm_fd_app_retract_workflow_helpers.py
======================================

Helper functions for building approach/retract FD libraries and visualizing
multi-force branch-aware individual/global FD fits.

Put this file in your `codes/` folder together with:

    spm_fd_rk45_extended_calibration_multiforce.py
    spm_force_models_branches.py

Then use:

    from codes import spm_fd_app_retract_workflow_helpers as fdviz
"""

from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Tuple, Any
import numpy as np
import matplotlib.pyplot as plt


def _import_fdcal():
    try:
        from codes import spm_fd_rk45_extended_calibration_multiforce as fdcal
    except Exception:
        import spm_fd_rk45_extended_calibration_multiforce as fdcal
    return fdcal


# =============================================================================
# 1. Build approach/retract libraries from arrays
# =============================================================================

def _normalize_fd_array(arr, n_drive: int, name: str):
    """
    Convert input to shape (n_drive, n_point).

    Accepts:
        (n_drive, n_point)
        (n_point, n_drive)  -> transposed automatically
        (n_point,)          -> tiled over drives
    """
    arr = np.asarray(arr, dtype=float)

    if arr.ndim == 1:
        return np.tile(arr[None, :], (n_drive, 1))

    if arr.ndim != 2:
        raise ValueError(f"{name} must be 1D or 2D. Got shape {arr.shape}.")

    if arr.shape[0] == n_drive:
        return arr

    if arr.shape[1] == n_drive:
        return arr.T

    raise ValueError(
        f"{name} shape {arr.shape} is incompatible with n_drive={n_drive}. "
        "Expected (n_drive, n_point), (n_point, n_drive), or (n_point,)."
    )


def estimate_far_field_amplitudes(height, amp, far_field_frac: float = 0.10):
    """Estimate free-air amplitude for each FD curve from its largest distances."""
    height = np.asarray(height, dtype=float)
    amp = np.asarray(amp, dtype=float)
    if height.shape != amp.shape:
        raise ValueError(f"height shape {height.shape} does not match amp shape {amp.shape}.")
    if height.ndim != 2:
        raise ValueError("height and amp must be 2D arrays with shape (n_drive, n_point).")

    A0 = np.empty(height.shape[0], dtype=float)
    for j in range(height.shape[0]):
        h = np.asarray(height[j], dtype=float)
        a = np.asarray(amp[j], dtype=float)
        mask = np.isfinite(h) & np.isfinite(a)
        h = h[mask]
        a = a[mask]
        if h.size < 3:
            A0[j] = np.nan
            continue
        n_far = max(3, int(float(far_field_frac) * h.size))
        far_idx = np.argsort(h)[::-1][:n_far]
        A0[j] = float(np.nanmedian(a[far_idx]))
    return A0


def estimate_drive_scale_from_far_field(
    drives,
    height,
    amp,
    far_field_frac: float = 0.10,
    method: str = "median_ratio",
):
    """
    Estimate a scalar drive calibration from far-field amplitudes.

    Returns a scale factor such that calibrated_drive ~= raw_drive * scale,
    plus diagnostic arrays for inspecting per-drive A0/drive ratios.
    """
    drives = np.asarray(drives, dtype=float).ravel()
    height = _normalize_fd_array(height, len(drives), "height")
    amp = _normalize_fd_array(amp, len(drives), "amp")
    A0 = estimate_far_field_amplitudes(height, amp, far_field_frac=far_field_frac)

    valid = np.isfinite(drives) & np.isfinite(A0) & (np.abs(drives) > 0)
    if not np.any(valid):
        raise ValueError("Could not estimate drive scale: no finite nonzero drives with finite far-field amplitude.")

    ratio = np.full_like(drives, np.nan, dtype=float)
    ratio[valid] = A0[valid] / drives[valid]

    if method == "median_ratio":
        scale = float(np.nanmedian(ratio[valid]))
    elif method == "least_squares":
        d = drives[valid]
        a = A0[valid]
        scale = float(np.dot(d, a) / max(np.dot(d, d), 1e-300))
    else:
        raise ValueError("method must be 'median_ratio' or 'least_squares'.")

    return scale, {"drive": drives, "A0_far_field": A0, "A0_over_drive": ratio}


def make_measured_fd_dict(
    drives,
    height,
    amp,
    phase,
    *,
    drive_scale: float = 1.0,
    height_offset: float = 0.0,
    sort_by_drive: bool = True,
):
    """
    Build a dictionary compatible with build_measured_fd_curves_from_dict:

        measured_fd[drive] = {"d": height[i], "A": amp[i], "phi": phase[i]}

    Parameters
    ----------
    drives:
        1D drive values. These can be actual drive voltage, free amplitude A0,
        or your calibrated drive_nm.

    height, amp, phase:
        Arrays of shape (n_drive, n_point), (n_point, n_drive), or (n_point,).

    drive_scale:
        Optional scale factor. For example, if you previously used
        drives_si = drive_fd * 0.8, set drive_scale=0.8.

    height_offset:
        Optional additive distance correction applied before fitting. This is
        useful for testing a common height-zero offset; per-curve offsets can
        still be fitted by the ODE model.

    sort_by_drive:
        If True, sort dictionary entries by drive value.
    """
    drives = np.asarray(drives, dtype=float).ravel() * float(drive_scale)
    n_drive = len(drives)

    height = _normalize_fd_array(height, n_drive, "height")
    amp = _normalize_fd_array(amp, n_drive, "amp")
    phase = _normalize_fd_array(phase, n_drive, "phase")

    height_offset = np.asarray(height_offset, dtype=float)
    if height_offset.ndim == 0:
        height = height + float(height_offset)
    else:
        height_offset = height_offset.ravel()
        if height_offset.size != n_drive:
            raise ValueError("height_offset must be scalar or have one value per drive.")
        height = height + height_offset[:, None]

    order = np.argsort(drives) if sort_by_drive else np.arange(n_drive)

    measured_fd = {}
    for ii in order:
        d = np.asarray(height[ii], dtype=float).ravel()
        A = np.asarray(amp[ii], dtype=float).ravel()
        ph = np.asarray(phase[ii], dtype=float).ravel()

        mask = np.isfinite(d) & np.isfinite(A) & np.isfinite(ph)
        if np.sum(mask) < 8:
            continue

        measured_fd[float(drives[ii])] = {
            "d": d[mask],
            "A": A[mask],
            "phi": ph[mask],
        }

    if len(measured_fd) == 0:
        raise ValueError("No valid FD curves were built.")

    return measured_fd


def build_approach_retract_fd_libraries(
    drives,
    height1,
    amp1,
    phase1,
    height2,
    amp2,
    phase2,
    *,
    curve1: str = "approach",
    drive_scale: float = 1.0,
    height1_offset: float = 0.0,
    height2_offset: float = 0.0,
    conv_L: float = 1.0,
    A0_method: str = "far_field_median",
    far_field_frac: float = 0.10,
    omega_drive_hat: float = 1.0,
    omega_ref_hat: Optional[float] = None,
    sort_by_drive: bool = True,
):
    """
    Build approach and retract libraries from two measured FD datasets.

    Use this when your arrays are:

        drive, height1, amp1, phase1, height2, amp2, phase2

    By default, dataset 1 is treated as approach and dataset 2 as retract.

    If your experiment saved them in the opposite order, set:

        curve1="retract"

    drive_scale calibrates the recorded drive values before they are used as
    curve keys or, with A0_method="drive", as the free-air amplitude estimate.
    height1_offset and height2_offset are additive distance corrections in the
    same units as the corresponding height arrays.

    Returns
    -------
    pack : dict
        {
            "approach_fd": dict,
            "retract_fd": dict,
            "approach_curves": list of curve dicts,
            "retract_curves": list of curve dicts,
            "drives": sorted drive array,
        }
    """
    fdcal = _import_fdcal()

    fd1 = make_measured_fd_dict(
        drives,
        height1,
        amp1,
        phase1,
        drive_scale=drive_scale,
        height_offset=height1_offset,
        sort_by_drive=sort_by_drive,
    )

    fd2 = make_measured_fd_dict(
        drives,
        height2,
        amp2,
        phase2,
        drive_scale=drive_scale,
        height_offset=height2_offset,
        sort_by_drive=sort_by_drive,
    )

    curve1 = str(curve1).lower()
    if curve1 in ("approach", "app", "approaching", "far_to_near"):
        approach_fd, retract_fd = fd1, fd2
    elif curve1 in ("retract", "ret", "retracting", "near_to_far"):
        approach_fd, retract_fd = fd2, fd1
    else:
        raise ValueError("curve1 must be 'approach' or 'retract'.")

    # Keep only drives present in both libraries.
    common_drives = sorted(set(approach_fd.keys()).intersection(set(retract_fd.keys())))
    if len(common_drives) == 0:
        raise ValueError("No common drive keys found between approach and retract libraries.")

    approach_fd = {float(k): approach_fd[float(k)] for k in common_drives}
    retract_fd = {float(k): retract_fd[float(k)] for k in common_drives}

    approach_curves = fdcal.build_measured_fd_curves_from_dict(
        approach_fd,
        conv_L=conv_L,
        A0_method=A0_method,
        far_field_frac=far_field_frac,
        omega_drive_hat=omega_drive_hat,
        omega_ref_hat=omega_ref_hat,
    )

    retract_curves = fdcal.build_measured_fd_curves_from_dict(
        retract_fd,
        conv_L=conv_L,
        A0_method=A0_method,
        far_field_frac=far_field_frac,
        omega_drive_hat=omega_drive_hat,
        omega_ref_hat=omega_ref_hat,
    )

    return {
        "approach_fd": approach_fd,
        "retract_fd": retract_fd,
        "approach_curves": approach_curves,
        "retract_curves": retract_curves,
        "drives": np.asarray(common_drives, dtype=float),
        "conv_L": float(conv_L),
    }


# =============================================================================
# 2. Fit workflow convenience
# =============================================================================

def fit_approach_retract_individual_then_global(
    approach_curves: List[Dict],
    retract_curves: Optional[List[Dict]] = None,
    *,
    conv_L: float = 1.0,
    sim_opts=None,
    cfg=None,
    model: Optional[str] = None,
):
    """
    Fit all approach curves individually, using retract curves for model selection,
    then run one global shared-physics fit.

    Notes
    -----
    The current fitter fits the approach curve as the main objective.
    The retract curve is used during force-model selection and branch scoring.
    """
    fdcal = _import_fdcal()

    if cfg is None:
        cfg = fdcal.MultiForceFitConfig(
            selected_model=model,
            use_retract_for_selection=True,
            add_branch_score_to_selection=True,
            output_branches=False,
            verbose=True,
        )
    else:
        cfg.selected_model = model if model is not None else cfg.selected_model

    if sim_opts is None:
        sim_opts = fdcal.make_default_multiforce_sim_options()

    individual_fits = fdcal.fit_individual_fd_curves_multiforce_branchaware(
        approach_curves,
        retract_curves=retract_curves,
        model=model,
        sim_opts=sim_opts,
        cfg=cfg,
    )

    global_fit = fdcal.fit_global_fd_curves_multiforce_branchaware(
        approach_curves,
        individual_fits,
        model=model,
        conv_L=conv_L,
        sim_opts=sim_opts,
        cfg=cfg,
    )

    return {
        "individual_fits": individual_fits,
        "global_fit": global_fit,
        "cfg": cfg,
        "sim_opts": sim_opts,
    }


# =============================================================================
# 3. Branch utilities
# =============================================================================

def _union_distance_curve(approach_curve: Dict, retract_curve: Optional[Dict] = None, n_points: Optional[int] = None):
    """
    Make a curve-like dict whose distance grid is the union of approach/retract d.
    This is useful for computing stable branch tracks over both measured curves.
    """
    d = np.asarray(approach_curve["d_hat"], dtype=float).ravel()
    if retract_curve is not None:
        d = np.r_[d, np.asarray(retract_curve["d_hat"], dtype=float).ravel()]
    d = d[np.isfinite(d)]
    d = np.unique(np.sort(d))

    if n_points is not None and n_points > 0 and d.size > n_points:
        pos = np.linspace(0, d.size - 1, int(n_points))
        d = d[np.unique(np.round(pos).astype(int))]

    fake = dict(approach_curve)
    fake["d_hat"] = d
    fake["A_hat"] = np.full_like(d, np.nan, dtype=float)
    fake["phi_deg"] = np.full_like(d, np.nan, dtype=float)
    return fake


def _phase_shift_for_fit(curve, fit, sim_opts=None, cfg=None):
    """
    Get the same phase transform and far-field offset used by the predictor.
    """
    fdcal = _import_fdcal()
    pred = fdcal.predict_curve_multiforce_fit(curve, fit, sim_opts=sim_opts, cfg=cfg)
    return pred.get("phi_auto_offset_deg", 0.0) + float(fit.get("phi_offset_deg", 0.0))


def compute_fit_branches_on_approach_retract(
    approach_curve: Dict,
    retract_curve: Optional[Dict],
    fit: Dict,
    *,
    sim_opts=None,
    cfg=None,
    n_points: Optional[int] = 80,
):
    """
    Compute all stable branches on the union of approach/retract distance points.
    """
    fdcal = _import_fdcal()
    fake = _union_distance_curve(approach_curve, retract_curve, n_points=n_points)
    return fdcal.compute_all_stable_branches_for_multiforce_fit(
        fake,
        fit,
        sim_opts=sim_opts,
        cfg=cfg,
        n_points=n_points,
    )


def global_fit_to_single_curve_fit(global_fit: Dict, curve_index: int):
    """
    Convert a global fit into a single-curve fit dictionary that can be passed
    to predict_curve_multiforce_fit or branch solvers.
    """
    return {
        "model": global_fit["model"],
        "force_params": global_fit["force_params"],
        "force_values": global_fit.get("force_values", {}),
        "Q": float(global_fit["Q"]),
        "C3": float(global_fit["C3_all"][curve_index]),
        "d_offset_hat": float(global_fit["d_offsets_hat"][curve_index]),
        "phi_offset_deg": float(global_fit["phi_offsets_deg"][curve_index]),
        "w_contact": float(global_fit.get("w_contact", 0.1)),
        "gamma_lr": float(global_fit.get("gamma_lr", 0.0)),
        "lambda_lr": float(global_fit.get("lambda_lr", 1.0)),
        "gamma_contact": float(global_fit.get("gamma_contact", 0.0)),
        "cfg": global_fit.get("cfg", None),
        "sim_opts": global_fit.get("sim_opts", None),
    }


# =============================================================================
# 4. Raw library visualization
# =============================================================================

def plot_raw_approach_retract_libraries(
    approach_curves: List[Dict],
    retract_curves: List[Dict],
    *,
    indices: Optional[Sequence[int]] = None,
    max_curves: int = 6,
    sort_by_d: bool = True,
):
    """
    Quick diagnostic plot of measured approach and retract FD libraries.
    """
    if indices is None:
        indices = np.linspace(0, len(approach_curves) - 1, min(max_curves, len(approach_curves)))
        indices = np.unique(np.round(indices).astype(int))

    fig, ax = plt.subplots(1, 2, figsize=(9.5, 3.6))

    for j in indices:
        app = approach_curves[int(j)]
        ret = retract_curves[int(j)]
        drive = app.get("drive_nm", np.nan)

        d_app = np.asarray(app["d_hat"], dtype=float)
        d_ret = np.asarray(ret["d_hat"], dtype=float)

        o_app = np.argsort(d_app) if sort_by_d else np.arange(len(d_app))
        o_ret = np.argsort(d_ret) if sort_by_d else np.arange(len(d_ret))

        ax[0].plot(d_app[o_app], np.asarray(app["A_hat"])[o_app], "-", lw=1.5, label=f"app {drive:.3g}")
        ax[0].plot(d_ret[o_ret], np.asarray(ret["A_hat"])[o_ret], "--", lw=1.2, label=f"ret {drive:.3g}")

        ax[1].plot(d_app[o_app], np.asarray(app["phi_deg"])[o_app], "-", lw=1.5, label=f"app {drive:.3g}")
        ax[1].plot(d_ret[o_ret], np.asarray(ret["phi_deg"])[o_ret], "--", lw=1.2, label=f"ret {drive:.3g}")

    ax[0].set_xlabel("d_hat")
    ax[0].set_ylabel("A_hat")
    ax[1].set_xlabel("d_hat")
    ax[1].set_ylabel("phase (deg)")
    ax[0].set_title("Amplitude")
    ax[1].set_title("Phase")
    ax[0].legend(fontsize=7, ncols=2)
    ax[1].legend(fontsize=7, ncols=2)
    plt.tight_layout()
    return fig, ax


# =============================================================================
# 5. Individual/global fit visualization
# =============================================================================

def plot_one_individual_fit_approach_retract(
    approach_curve: Dict,
    retract_curve: Optional[Dict],
    fit: Dict,
    *,
    sim_opts=None,
    cfg=None,
    show_branches: bool = True,
    branch_n_points: int = 80,
    sort_by_d: bool = True,
):
    """
    Plot one individual fit with:
        approach data
        retract data
        fitted approach prediction
        optional all-stable branch tracks
    """
    fdcal = _import_fdcal()
    cfg = cfg or fit.get("cfg", fdcal.MultiForceFitConfig())
    sim_opts = sim_opts or fit.get("sim_opts", None)

    pred = fdcal.predict_curve_multiforce_fit(
        approach_curve,
        fit,
        sim_opts=sim_opts,
        cfg=cfg,
    )

    d_app = np.asarray(approach_curve["d_hat"], dtype=float)
    o_app = np.argsort(d_app) if sort_by_d else np.arange(len(d_app))

    fig, ax = plt.subplots(1, 2, figsize=(10.5, 3.8))

    ax[0].plot(d_app[o_app], np.asarray(approach_curve["A_hat"])[o_app], "o", ms=3, alpha=0.75, label="approach exp")
    ax[0].plot(d_app[o_app], pred["A"][o_app], "-", lw=2.0, label=f"approach fit: {fit['model']}")

    ax[1].plot(d_app[o_app], np.asarray(approach_curve["phi_deg"])[o_app], "o", ms=3, alpha=0.75, label="approach exp")
    ax[1].plot(d_app[o_app], pred["phi"][o_app], "-", lw=2.0, label=f"approach fit: {fit['model']}")

    if retract_curve is not None:
        d_ret = np.asarray(retract_curve["d_hat"], dtype=float)
        o_ret = np.argsort(d_ret) if sort_by_d else np.arange(len(d_ret))
        ax[0].plot(d_ret[o_ret], np.asarray(retract_curve["A_hat"])[o_ret], "s", ms=3, alpha=0.6, label="retract exp")
        ax[1].plot(d_ret[o_ret], np.asarray(retract_curve["phi_deg"])[o_ret], "s", ms=3, alpha=0.6, label="retract exp")

    if show_branches:
        try:
            br = compute_fit_branches_on_approach_retract(
                approach_curve,
                retract_curve,
                fit,
                sim_opts=sim_opts,
                cfg=cfg,
                n_points=branch_n_points,
            )
            phi_shift = _phase_shift_for_fit(approach_curve, fit, sim_opts=sim_opts, cfg=cfg)
            for tr in br.get("tracks", []):
                d_br = np.asarray(tr["d"], dtype=float)
                A_br = np.asarray(tr["A"], dtype=float)
                phi_br = fdcal.transform_phase_deg(np.asarray(tr["phi"], dtype=float), mode=cfg.phase_mode) + phi_shift

                o = np.argsort(d_br)
                label = str(tr.get("label", "branch"))
                ax[0].plot(d_br[o], A_br[o], "--", lw=1.2, alpha=0.85, label=label)
                ax[1].plot(d_br[o], phi_br[o], "--", lw=1.2, alpha=0.85, label=label)
        except Exception as exc:
            ax[0].text(0.02, 0.98, f"branch solve failed:\n{exc}", transform=ax[0].transAxes,
                       va="top", ha="left", fontsize=8)

    ax[0].set_xlabel("d_hat")
    ax[0].set_ylabel("A_hat")
    ax[1].set_xlabel("d_hat")
    ax[1].set_ylabel("phase (deg)")

    drive = approach_curve.get("drive_nm", np.nan)
    fig.suptitle(
        f"Individual fit: drive={drive:.4g}, model={fit.get('model','')}, cost={fit.get('cost', np.nan):.4g}"
    )

    ax[0].legend(fontsize=8)
    ax[1].legend(fontsize=8)
    plt.tight_layout()
    return fig, ax


def plot_individual_fits_approach_retract_grid(
    approach_curves: List[Dict],
    retract_curves: Optional[List[Dict]],
    individual_fits: List[Dict],
    *,
    indices: Optional[Sequence[int]] = None,
    max_curves: int = 8,
    sim_opts=None,
    cfg=None,
    show_branches: bool = False,
    branch_n_points: int = 60,
    ncols: int = 4,
):
    """
    Compact grid of individual fits. Each panel shows amplitude on left y-axis
    and phase on right y-axis for one drive.
    """
    fdcal = _import_fdcal()

    n_total = len(approach_curves)
    if indices is None:
        indices = np.linspace(0, n_total - 1, min(max_curves, n_total))
        indices = np.unique(np.round(indices).astype(int))

    indices = [int(i) for i in indices]
    n = len(indices)
    ncols = min(int(ncols), n)
    nrows = int(np.ceil(n / ncols))

    fig, axes = plt.subplots(nrows, ncols, figsize=(4.3 * ncols, 3.2 * nrows), squeeze=False)

    for p, j in enumerate(indices):
        r, c = divmod(p, ncols)
        ax = axes[r, c]
        ax2 = ax.twinx()

        app = approach_curves[j]
        ret = None if retract_curves is None else retract_curves[j]
        fit = individual_fits[j]
        cfg_j = cfg or fit.get("cfg", fdcal.MultiForceFitConfig())
        sim_opts_j = sim_opts or fit.get("sim_opts", None)

        pred = fdcal.predict_curve_multiforce_fit(app, fit, sim_opts=sim_opts_j, cfg=cfg_j)

        d = np.asarray(app["d_hat"], dtype=float)
        o = np.argsort(d)
        ax.plot(d[o], np.asarray(app["A_hat"])[o], "o", ms=2.3, alpha=0.65, label="app A")
        ax.plot(d[o], pred["A"][o], "-", lw=1.5, label="fit A")
        ax2.plot(d[o], np.asarray(app["phi_deg"])[o], ".", ms=2.3, alpha=0.55, label="app phi")
        ax2.plot(d[o], pred["phi"][o], "--", lw=1.2, label="fit phi")

        if ret is not None:
            d_ret = np.asarray(ret["d_hat"], dtype=float)
            o_ret = np.argsort(d_ret)
            ax.plot(d_ret[o_ret], np.asarray(ret["A_hat"])[o_ret], "s", ms=2.1, alpha=0.45, label="ret A")
            ax2.plot(d_ret[o_ret], np.asarray(ret["phi_deg"])[o_ret], "x", ms=2.1, alpha=0.45, label="ret phi")

        if show_branches:
            try:
                br = compute_fit_branches_on_approach_retract(app, ret, fit, sim_opts=sim_opts_j, cfg=cfg_j, n_points=branch_n_points)
                phi_shift = _phase_shift_for_fit(app, fit, sim_opts=sim_opts_j, cfg=cfg_j)
                for tr in br.get("tracks", []):
                    db = np.asarray(tr["d"], dtype=float)
                    ob = np.argsort(db)
                    ax.plot(db[ob], np.asarray(tr["A"])[ob], ":", lw=1.0, alpha=0.8)
                    ph = fdcal.transform_phase_deg(np.asarray(tr["phi"]), mode=cfg_j.phase_mode) + phi_shift
                    ax2.plot(db[ob], ph[ob], ":", lw=1.0, alpha=0.8)
            except Exception:
                pass

        ax.set_title(f"drive={app.get('drive_nm', np.nan):.3g}, {fit.get('model','')}")
        ax.set_xlabel("d_hat")
        ax.set_ylabel("A")
        ax2.set_ylabel("phi")

    for p in range(n, nrows * ncols):
        r, c = divmod(p, ncols)
        axes[r, c].axis("off")

    fig.suptitle("Individual multi-force FD fits")
    plt.tight_layout()
    return fig, axes


def plot_one_global_fit_approach_retract(
    approach_curve: Dict,
    retract_curve: Optional[Dict],
    global_fit: Dict,
    curve_index: int,
    *,
    sim_opts=None,
    cfg=None,
    show_branches: bool = True,
    branch_n_points: int = 80,
):
    """
    Plot one curve from the global fit against approach/retract data.
    """
    fit_j = global_fit_to_single_curve_fit(global_fit, curve_index)
    fit_j["cfg"] = cfg or global_fit.get("cfg", fit_j.get("cfg", None))
    fit_j["sim_opts"] = sim_opts or global_fit.get("sim_opts", fit_j.get("sim_opts", None))

    return plot_one_individual_fit_approach_retract(
        approach_curve,
        retract_curve,
        fit_j,
        sim_opts=sim_opts or global_fit.get("sim_opts", None),
        cfg=cfg or global_fit.get("cfg", None),
        show_branches=show_branches,
        branch_n_points=branch_n_points,
    )


def plot_global_fits_approach_retract_grid(
    approach_curves: List[Dict],
    retract_curves: Optional[List[Dict]],
    global_fit: Dict,
    *,
    indices: Optional[Sequence[int]] = None,
    max_curves: int = 8,
    sim_opts=None,
    cfg=None,
    show_branches: bool = False,
    branch_n_points: int = 60,
    ncols: int = 4,
):
    """
    Compact grid of global-fit results.
    """
    fdcal = _import_fdcal()

    n_total = len(approach_curves)
    if indices is None:
        indices = np.linspace(0, n_total - 1, min(max_curves, n_total))
        indices = np.unique(np.round(indices).astype(int))

    indices = [int(i) for i in indices]
    n = len(indices)
    ncols = min(int(ncols), n)
    nrows = int(np.ceil(n / ncols))

    fig, axes = plt.subplots(nrows, ncols, figsize=(4.3 * ncols, 3.2 * nrows), squeeze=False)

    cfg_j = cfg or global_fit.get("cfg", fdcal.MultiForceFitConfig())
    sim_opts_j = sim_opts or global_fit.get("sim_opts", None)

    for p, j in enumerate(indices):
        r, c = divmod(p, ncols)
        ax = axes[r, c]
        ax2 = ax.twinx()

        app = approach_curves[j]
        ret = None if retract_curves is None else retract_curves[j]

        pred = fdcal.predict_curve_multiforce_global_fit(
            app,
            global_fit,
            j,
            sim_opts=sim_opts_j,
            cfg=cfg_j,
        )

        d = np.asarray(app["d_hat"], dtype=float)
        o = np.argsort(d)
        ax.plot(d[o], np.asarray(app["A_hat"])[o], "o", ms=2.3, alpha=0.65, label="app A")
        ax.plot(d[o], pred["A"][o], "-", lw=1.5, label="fit A")
        ax2.plot(d[o], np.asarray(app["phi_deg"])[o], ".", ms=2.3, alpha=0.55, label="app phi")
        ax2.plot(d[o], pred["phi"][o], "--", lw=1.2, label="fit phi")

        if ret is not None:
            d_ret = np.asarray(ret["d_hat"], dtype=float)
            o_ret = np.argsort(d_ret)
            ax.plot(d_ret[o_ret], np.asarray(ret["A_hat"])[o_ret], "s", ms=2.1, alpha=0.45, label="ret A")
            ax2.plot(d_ret[o_ret], np.asarray(ret["phi_deg"])[o_ret], "x", ms=2.1, alpha=0.45, label="ret phi")

        if show_branches:
            try:
                fit_j = global_fit_to_single_curve_fit(global_fit, j)
                br = compute_fit_branches_on_approach_retract(app, ret, fit_j, sim_opts=sim_opts_j, cfg=cfg_j, n_points=branch_n_points)
                phi_shift = _phase_shift_for_fit(app, fit_j, sim_opts=sim_opts_j, cfg=cfg_j)
                for tr in br.get("tracks", []):
                    db = np.asarray(tr["d"], dtype=float)
                    ob = np.argsort(db)
                    ax.plot(db[ob], np.asarray(tr["A"])[ob], ":", lw=1.0, alpha=0.8)
                    ph = fdcal.transform_phase_deg(np.asarray(tr["phi"]), mode=cfg_j.phase_mode) + phi_shift
                    ax2.plot(db[ob], ph[ob], ":", lw=1.0, alpha=0.8)
            except Exception:
                pass

        ax.set_title(f"drive={app.get('drive_nm', np.nan):.3g}")
        ax.set_xlabel("d_hat")
        ax.set_ylabel("A")
        ax2.set_ylabel("phi")

    for p in range(n, nrows * ncols):
        r, c = divmod(p, ncols)
        axes[r, c].axis("off")

    fig.suptitle(f"Global multi-force FD fit: model={global_fit.get('model','')}, cost={global_fit.get('cost', np.nan):.4g}")
    plt.tight_layout()
    return fig, axes


def plot_individual_fit_summary(individual_fits: List[Dict]):
    """
    Summary plot for individual fits: selected model, cost, Q, C3, offsets.
    """
    drives = np.array([f.get("drive_nm", np.nan) for f in individual_fits], dtype=float)
    cost = np.array([f.get("cost", np.nan) for f in individual_fits], dtype=float)
    Q = np.array([f.get("Q", np.nan) for f in individual_fits], dtype=float)
    C3 = np.array([f.get("C3", np.nan) for f in individual_fits], dtype=float)
    doff = np.array([f.get("d_offset_hat", np.nan) for f in individual_fits], dtype=float)
    phoff = np.array([f.get("phi_offset_deg", np.nan) for f in individual_fits], dtype=float)
    models = [str(f.get("model", "")) for f in individual_fits]

    order = np.argsort(drives)
    drives = drives[order]
    cost = cost[order]
    Q = Q[order]
    C3 = C3[order]
    doff = doff[order]
    phoff = phoff[order]
    models_ordered = [models[i] for i in order]

    fig, ax = plt.subplots(2, 3, figsize=(12, 6.2))

    ax[0, 0].semilogy(drives, cost, "o-")
    ax[0, 0].set_title("individual cost")
    ax[0, 0].set_xlabel("drive")

    ax[0, 1].plot(drives, Q, "o-")
    ax[0, 1].set_title("Q")
    ax[0, 1].set_xlabel("drive")

    ax[0, 2].semilogy(drives, np.abs(C3), "o-")
    ax[0, 2].set_title("|C3|")
    ax[0, 2].set_xlabel("drive")

    ax[1, 0].plot(drives, doff, "o-")
    ax[1, 0].set_title("d_offset_hat")
    ax[1, 0].set_xlabel("drive")

    ax[1, 1].plot(drives, phoff, "o-")
    ax[1, 1].set_title("phi_offset_deg")
    ax[1, 1].set_xlabel("drive")

    unique = sorted(set(models_ordered))
    model_to_id = {m: i for i, m in enumerate(unique)}
    model_id = np.array([model_to_id[m] for m in models_ordered], dtype=float)
    ax[1, 2].plot(drives, model_id, "o")
    ax[1, 2].set_yticks(range(len(unique)))
    ax[1, 2].set_yticklabels(unique)
    ax[1, 2].set_title("selected force model")
    ax[1, 2].set_xlabel("drive")

    plt.tight_layout()
    return fig, ax


def plot_global_fit_summary(global_fit: Dict, individual_fits: Optional[List[Dict]] = None):
    """
    Summary plot for global fit: C3(drive), offsets, and optional individual C3.
    """
    drives = np.asarray(global_fit.get("drives_nm", np.arange(len(global_fit["C3_all"]))), dtype=float)
    C3 = np.asarray(global_fit["C3_all"], dtype=float)
    doff = np.asarray(global_fit["d_offsets_hat"], dtype=float)
    phoff = np.asarray(global_fit["phi_offsets_deg"], dtype=float)

    fig, ax = plt.subplots(1, 3, figsize=(12, 3.6))

    ax[0].plot(drives, C3, "s-", label="global C3")
    if individual_fits is not None:
        d_ind = np.array([f.get("drive_nm", np.nan) for f in individual_fits], dtype=float)
        c_ind = np.array([f.get("C3", np.nan) for f in individual_fits], dtype=float)
        ax[0].plot(d_ind, c_ind, "o", alpha=0.7, label="individual C3")
    ax[0].set_xlabel("drive")
    ax[0].set_ylabel("C3")
    ax[0].set_title("drive-dependent C3")
    ax[0].legend(fontsize=8)

    ax[1].plot(drives, doff, "o-")
    ax[1].set_xlabel("drive")
    ax[1].set_ylabel("d_offset_hat")
    ax[1].set_title("distance offsets")

    ax[2].plot(drives, phoff, "o-")
    ax[2].set_xlabel("drive")
    ax[2].set_ylabel("phi_offset_deg")
    ax[2].set_title("phase offsets")

    fig.suptitle(f"Global fit: model={global_fit.get('model','')}, cost={global_fit.get('cost', np.nan):.4g}")
    plt.tight_layout()
    return fig, ax


def compute_global_fit_residual_metrics(
    curves: List[Dict],
    global_fit: Dict,
    *,
    sim_opts=None,
    cfg=None,
    conv_L: float = 1.0,
):
    """
    Compute per-curve and overall residual metrics for a global multiforce fit.

    Amplitude metrics are reported both in normalized units and in the inverse
    units of conv_L. Phase metrics use the fit phase period.
    """
    fdcal = _import_fdcal()
    cfg = cfg or global_fit.get("cfg", fdcal.MultiForceFitConfig())
    sim_opts = sim_opts or global_fit.get("sim_opts", None)
    conv_L = float(conv_L)
    if conv_L == 0:
        raise ValueError("conv_L must be nonzero.")

    rows = []
    all_A = []
    all_A_norm = []
    all_phi = []

    for j, curve in enumerate(curves):
        pred = fdcal.predict_curve_multiforce_global_fit(
            curve, global_fit, j, sim_opts=sim_opts, cfg=cfg
        )
        A_exp = np.asarray(curve["A_hat"], dtype=float)
        A0 = max(float(curve["A0_hat"]), 1e-12)
        dA_hat = np.asarray(pred["A"], dtype=float) - A_exp
        dA = dA_hat / conv_L
        dA_norm = dA_hat / A0
        dphi = fdcal.angle_diff_period_deg(
            np.asarray(pred["phi"], dtype=float),
            np.asarray(curve["phi_deg"], dtype=float),
            period_deg=cfg.phase_period_deg,
        )

        row = {
            "index": int(j),
            "drive": float(curve.get("drive_nm", np.nan)),
            "A_rmse": float(np.sqrt(np.nanmean(dA ** 2))),
            "A_rmse_norm": float(np.sqrt(np.nanmean(dA_norm ** 2))),
            "phase_rmse_deg": float(np.sqrt(np.nanmean(dphi ** 2))),
            "d_offset": float(np.asarray(global_fit["d_offsets_hat"])[j] / conv_L),
            "phi_offset_deg": float(np.asarray(global_fit["phi_offsets_deg"])[j]),
        }
        rows.append(row)
        all_A.append(dA)
        all_A_norm.append(dA_norm)
        all_phi.append(dphi)

    overall = {
        "A_rmse": float(np.sqrt(np.nanmean(np.concatenate(all_A) ** 2))),
        "A_rmse_norm": float(np.sqrt(np.nanmean(np.concatenate(all_A_norm) ** 2))),
        "phase_rmse_deg": float(np.sqrt(np.nanmean(np.concatenate(all_phi) ** 2))),
        "n_curves": int(len(curves)),
    }
    return {"overall": overall, "per_curve": rows}


# =============================================================================
# 6. Example-like minimal workflow in one function
# =============================================================================

def build_and_fit_from_two_fd_sets(
    drives,
    height1,
    amp1,
    phase1,
    height2,
    amp2,
    phase2,
    *,
    curve1: str = "approach",
    drive_scale: float = 1.0,
    conv_L: float = 1.0,
    cfg=None,
    sim_opts=None,
    model: Optional[str] = None,
):
    """
    One-call workflow:

        pack = build_and_fit_from_two_fd_sets(
            drive, height1, amp1, phase1, height2, amp2, phase2
        )

    Returns library + individual/global fits.
    """
    lib = build_approach_retract_fd_libraries(
        drives,
        height1,
        amp1,
        phase1,
        height2,
        amp2,
        phase2,
        curve1=curve1,
        drive_scale=drive_scale,
        conv_L=conv_L,
    )

    fit_pack = fit_approach_retract_individual_then_global(
        lib["approach_curves"],
        lib["retract_curves"],
        conv_L=conv_L,
        sim_opts=sim_opts,
        cfg=cfg,
        model=model,
    )

    return {
        **lib,
        **fit_pack,
    }
