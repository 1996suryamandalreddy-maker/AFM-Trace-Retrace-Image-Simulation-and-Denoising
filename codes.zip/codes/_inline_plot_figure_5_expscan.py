# 11.5  plot_figure_5 — fully self-contained Figure 5 for the expscan dataset.
def plot_figure_5(bundle, save_to=None, stem='figure_5_expscan_PI_vs_hybrid_vs_DD_nature'):
    """Render Figure 5 from a bundle dict.

    Layout (2x3):
      row 1: (a) predicted vs experimental scan-quality, three methods
             (b) quality median |error| / P75 |error| bars
             (c) per-line shape RMSE boxplot (log y)
      row 2: (d, e, f) trace/retrace overlays for one held-out condition
             where the three methods disagree most (PI saturations filtered)
    """
    setup_style()
    traces_exp = bundle['traces_exp']
    test_idx = bundle['test_idx']
    dt_PI = bundle['dt_PI']; dd = bundle['dd']; hyb = bundle['hyb']
    drive = bundle['drive']; sp = bundle['setpoint']; ig = bundle['igain']
    q_exp = bundle['q_exp']; q_PI = bundle['q_PI']; q_dd = bundle['q_dd']; q_hyb = bundle['q_hyb']
    rmse_PI = bundle['rmse_PI']; rmse_dd = bundle['rmse_dd']; rmse_hyb = bundle['rmse_hyb']

    h = test_idx
    method_color = {'PI fitting':       PALETTE['blue'],
                    'PI + data-driven': PALETTE['purple'],
                    'pure data-driven': PALETTE['orange']}
    method_q    = {'PI fitting':       q_PI[h],
                   'PI + data-driven': q_hyb[h],
                   'pure data-driven': q_dd[h]}
    method_rmse = {'PI fitting':       np.nanmean(rmse_PI[h], axis=1),
                   'PI + data-driven': np.nanmean(rmse_hyb[h], axis=1),
                   'pure data-driven': np.nanmean(rmse_dd[h], axis=1)}

    fig = plt.figure(figsize=(7.2, 6.0), constrained_layout=False)
    gs = gridspec.GridSpec(2, 3, figure=fig, height_ratios=[1.1, 1.0],
                            width_ratios=[1.0, 1.0, 1.1])
    fig.subplots_adjust(left=0.08, right=0.985, bottom=0.13, top=0.83,
                        wspace=0.62, hspace=0.95)
    fig.suptitle('Predicting scan quality on unfitted conditions:\nPI fit vs hybrid vs pure data-driven',
                 x=0.06, y=0.965, ha='left', fontsize=9.7, fontweight='bold')

    # (a) predicted vs experimental quality
    ax = fig.add_subplot(gs[0, 0]); panel_label(ax, 'a')
    all_q = []
    for name, qm in method_q.items():
        all_q.extend(qm.tolist())
        finite = np.isfinite(qm) & np.isfinite(q_exp[h])
        ax.scatter(q_exp[h][finite], qm[finite], s=18,
                   color=method_color[name], edgecolor='white', lw=0.3,
                   alpha=0.85, label=name)
    qmax = float(np.nanpercentile([v for v in all_q if np.isfinite(v)] + q_exp[h].tolist(), 90))
    qmax = max(qmax, 6.0)
    ax.plot([0, qmax], [0, qmax], color=PALETTE['muted'], lw=0.6, ls='--')
    ax.set_xlim(0, qmax); ax.set_ylim(0, qmax)
    ax.set_xlabel('experimental quality (nm)')
    ax.set_ylabel('predicted quality (nm)')
    ax.set_title('Held-out scan-quality\n(trace–retrace RMSE)')
    ax.legend(frameon=False, fontsize=6.3, loc='upper left')

    # (b) Median / P75 quality error bars
    ax = fig.add_subplot(gs[0, 1]); panel_label(ax, 'b')
    names = list(method_q.keys())
    qe = q_exp[h]
    medae_q = [float(np.nanmedian(np.abs(qe - method_q[n]))) for n in names]
    p75_q   = [float(np.nanpercentile(np.abs(qe - method_q[n]), 75)) for n in names]
    x = np.arange(len(names)); w = 0.36
    ax.bar(x - w/2, medae_q, width=w, color=[method_color[n] for n in names],
           alpha=0.85, label='Median |error|')
    ax.bar(x + w/2, p75_q,   width=w, color=[method_color[n] for n in names],
           alpha=0.45, label='P75 |error|')
    ax.set_xticks(x, [n.replace(' + ', '\n+ ').replace(' ', '\n', 1) for n in names])
    ax.set_ylabel('quality error (nm)')
    ax.set_title('Held-out quality error')
    ax.legend(frameon=False, fontsize=6.3, loc='upper right')

    # (c) per-line shape RMSE box
    ax = fig.add_subplot(gs[0, 2]); panel_label(ax, 'c')
    box_data = [method_rmse[n][np.isfinite(method_rmse[n])] for n in names]
    bp = ax.boxplot(box_data, widths=0.55, patch_artist=True,
                    medianprops=dict(color='black', lw=1.0),
                    flierprops=dict(marker='.', markersize=2,
                                    markerfacecolor=PALETTE['muted']))
    for patch, n in zip(bp['boxes'], names):
        patch.set_facecolor(method_color[n]); patch.set_alpha(0.6)
        patch.set_edgecolor(method_color[n]); patch.set_linewidth(0.8)
    ax.set_xticks([1, 2, 3], [n.replace(' + ', '\n+ ').replace(' ', '\n', 1) for n in names])
    ax.set_ylabel('per-line RMSE vs experiment (nm)')
    ax.set_title('Held-out scan-line\nshape error')
    ax.set_yscale('log')

    # Row 2: overlay panels.  Pick a held-out condition where ALL THREE methods
    # give physically bounded predictions (no extrapolation blow-up from the
    # data-driven branches), centered in the experimental height range.  Among
    # those we prefer a condition near the median per-method RMSE so the
    # overlay is representative rather than a tail case.
    def _interior_range(arr_row, trim=10):
        v = arr_row[trim:-trim] if arr_row.size > 2*trim+4 else arr_row
        v = v[np.isfinite(v)]
        if v.size == 0: return np.inf
        return float(np.nanmax(v) - np.nanmin(v))
    def _bounded(i, max_abs_amp=30.0):
        # Require the centered range of every method to stay within twice the
        # experimental range (so data-driven extrapolation flares are excluded).
        exp_rng = _interior_range(_center(traces_exp[i, 0]))
        if not np.isfinite(exp_rng) or exp_rng < 0.05: return False
        cap = max(exp_rng * 2.5, 4.0)
        for arr in (dt_PI, hyb, dd):
            for d in (0, 1):
                v = _center(arr[i, d])
                v = v[np.isfinite(v)]
                if v.size == 0: return False
                if float(np.nanmax(np.abs(v))) > max(cap, max_abs_amp):
                    return False
        return True

    plausible = np.array([_bounded(int(i)) for i in h], bool)
    # Among plausible conditions, score by per-line RMSE (mean across methods)
    # so we land on a representative — neither best-case nor worst-case — point.
    mean_rmse = 0.5 * (method_rmse['PI fitting']
                       + 0.5 * (method_rmse['PI + data-driven']
                                + method_rmse['pure data-driven']))
    score = mean_rmse.copy()
    score[~np.isfinite(score) | ~plausible] = np.inf
    if np.any(np.isfinite(score)):
        order = np.argsort(score)
        # Use the median of plausible scores so the figure is representative,
        # not the best case (which would hide the data-driven contribution).
        valid = order[np.isfinite(score[order])]
        k = valid[len(valid) // 2]
        cond_overlay = int(h[k])
    else:
        # Fallback to the old behaviour if nothing passes the filter.
        disagree = np.abs(q_dd[h] - q_PI[h])
        disagree[~np.isfinite(disagree)] = -1
        cond_overlay = int(h[int(np.argmax(disagree))])

    for col, (name, arr) in enumerate([('PI fitting', dt_PI),
                                        ('PI + data-driven', hyb),
                                        ('pure data-driven', dd)]):
        ax = fig.add_subplot(gs[1, col]); panel_label(ax, 'def'[col])
        ax.plot(_center(traces_exp[cond_overlay, 0]), color=PALETTE['ink'], lw=1.0)
        ax.plot(_center(traces_exp[cond_overlay, 1]), color=PALETTE['ink'], lw=0.9, ls=':', alpha=0.85)
        ax.plot(_center(arr[cond_overlay, 0]), color=method_color[name], lw=1.0)
        ax.plot(_center(arr[cond_overlay, 1]), color=method_color[name], lw=0.9, ls=':', alpha=0.85)
        ax.set_xlabel('pixel'); ax.set_ylabel('height (nm)')
        ax.set_title(f'{name}\ncond {cond_overlay}\n'
                     f'(d={float(drive[cond_overlay]):.1f} nm, sp={float(sp[cond_overlay]):.2f})')

    leg_handles = [
        Line2D([0],[0], color=PALETTE['ink'],    lw=1.0, label='experiment (trace)'),
        Line2D([0],[0], color=PALETTE['ink'],    lw=0.9, ls=':', label='experiment (retrace)'),
        Line2D([0],[0], color=PALETTE['blue'],   lw=1.0, label='PI fitting (model)'),
        Line2D([0],[0], color=PALETTE['purple'], lw=1.0, label='PI + data-driven (model)'),
        Line2D([0],[0], color=PALETTE['orange'], lw=1.0, label='pure data-driven (model)'),
    ]
    fig.legend(handles=leg_handles, loc='lower center',
               bbox_to_anchor=(0.5, 0.005), ncol=5, frameon=False,
               fontsize=6.3, handletextpad=0.5, columnspacing=1.0)
    fig.text(0.985, 0.045,
             f'N held-out = {len(h)}.   Dashed line = perfect prediction.   RMSE box: log-scale.',
             ha='right', fontsize=6.0, color=PALETTE['muted'])

    if save_to is not None:
        paths = save_pub(fig, save_to, stem)
        print('Saved Figure 5:', paths['png'])
    return fig
