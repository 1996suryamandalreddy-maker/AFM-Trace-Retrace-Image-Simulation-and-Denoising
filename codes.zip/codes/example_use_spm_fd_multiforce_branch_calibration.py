"""
Example usage for spm_fd_rk45_extended_calibration_multiforce.py

Copy both files into your notebook's codes/ folder:
    codes/spm_fd_rk45_extended_calibration_multiforce.py
    codes/spm_force_models_branches.py

Then adapt the arrays below to your data.
"""

import importlib
import numpy as np
import matplotlib.pyplot as plt

from codes import spm_fd_rk45_extended_calibration_multiforce as fdcal
importlib.reload(fdcal)

# -----------------------------------------------------------------------------
# 1. Build measured approach curves
# -----------------------------------------------------------------------------
# Your arrays can be in nm, or already in normalized/hat units.
# Typical shapes:
#     drive_fd: shape (n_drive,)
#     height:   shape (n_drive, n_point)
#     amp:      shape (n_drive, n_point)
#     phase:    shape (n_drive, n_point)

# Example using your common data layout:
# data = np.load("output/Tap300_AlScN.npz")
# height = data["height"]
# amp = data["amp"]
# phase = data["phase"]
# drive = data["drive"][:-1]
# drive_fd = np.array([np.nanmean(amp[i, -10:]) for i in range(len(drive))])

conv_L = 1.0

curves_app = fdcal.build_measured_fd_curves(
    drives_nm=drive_fd,
    height_nm=height,
    amplitude_nm=amp,
    phase_deg=phase,
    conv_L=conv_L,
    A0_method="far_field_median",
    far_field_frac=0.10,
    omega_drive_hat=1.0,
    omega_ref_hat=1.0,
)

# Optional: if you measured retract curves separately, build them the same way.
# If not available, keep retract_curves=None.  Model selection will still work,
# but it will rely less on hysteresis/pull-off signatures.
retract_curves = None
# retract_curves = fdcal.build_measured_fd_curves(
#     drives_nm=drive_fd,
#     height_nm=height_retract,
#     amplitude_nm=amp_retract,
#     phase_deg=phase_retract,
#     conv_L=conv_L,
#     A0_method="far_field_median",
#     far_field_frac=0.10,
# )

# -----------------------------------------------------------------------------
# 2. Configure the multi-force RK45 solver
# -----------------------------------------------------------------------------
# For fast debugging, start with small n_fit_points, low max_nfev, and
# output_branches=False.  Once the fit is stable, increase these values.

sim_opts = fdcal.make_default_multiforce_sim_options(
    Q=80.0,
    C3=0.05,
    N_cycles=3,
    max_windows=35,
    settle_windows=3,
    tol_A=1e-5,
    tol_phi_deg=0.03,
    demod_per_ref_cycle=40,
    rtol=1e-5,
    atol=1e-7,
    dt0=0.03,
    dt_max=0.18,
    max_steps_per_window=100000,
    phase_wrap_mode=180,
)

cfg = fdcal.MultiForceFitConfig(
    candidates=("dmt", "hertz", "lj", "morse", "jkr", "capillary"),
    selected_model=None,       # None = automatically choose model

    n_fit_points=64,           # increase to 96-128 for final fitting
    max_nfev_select=60,
    max_nfev_individual=120,
    max_nfev_global=300,

    w_amp=1.0,
    w_phi=0.02,
    phase_mode="raw",
    far_field_phase_align=True,
    phase_period_deg=180.0,
    use_amp_weighted_phase=True,
    sigma_phi0_deg=8.0,

    use_retract_for_selection=True,
    add_branch_score_to_selection=True,

    # All-stable branch finding is expensive.  Turn it on after debugging.
    output_branches=False,
    branch_n_points=60,
    branch_n_starts=7,

    verbose=True,
)

# -----------------------------------------------------------------------------
# 3. First test on one representative drive curve
# -----------------------------------------------------------------------------
idx = 0
one_fit = fdcal.fit_one_fd_curve_multiforce_branchaware(
    curves_app[idx],
    retract_curve=None if retract_curves is None else retract_curves[idx],
    sim_opts=sim_opts,
    cfg=cfg,
    output_branches=False,
)

print("One-curve fit:")
print("  selected model:", one_fit["model"])
print("  cost:", one_fit["cost"])
print("  Q, C3:", one_fit["Q"], one_fit["C3"])
print("  force values:", one_fit["force_values"])

fig, ax = fdcal.plot_one_multiforce_fit_overlay(
    curves_app[idx],
    one_fit,
    sim_opts=sim_opts,
    cfg=cfg,
    show_branches=False,
)
plt.show()

# -----------------------------------------------------------------------------
# 4. Fit all approach curves individually
# -----------------------------------------------------------------------------
individual_fits = fdcal.fit_individual_fd_curves_multiforce_branchaware(
    curves_app,
    retract_curves=retract_curves,
    sim_opts=sim_opts,
    cfg=cfg,
)

summary = fdcal.summarize_multiforce_individual_fits(individual_fits)
print("\nIndividual fit summary:")
for row in summary:
    print(row)

# -----------------------------------------------------------------------------
# 5. Run the global shared-physics fit
# -----------------------------------------------------------------------------
# The global model is chosen automatically from the individual model selections.
# You can force one model by passing model="dmt", "jkr", etc.

global_fit = fdcal.fit_global_fd_curves_multiforce_branchaware(
    curves_app,
    individual_fits,
    model=None,
    conv_L=conv_L,
    sim_opts=sim_opts,
    cfg=cfg,
)

print("\nGlobal fit:")
print("  model:", global_fit["model"])
print("  cost:", global_fit["cost"])
print("  Q:", global_fit["Q"])
print("  force values:", global_fit["force_values"])
print("  C3_all:", global_fit["C3_all"])

fig, ax = fdcal.plot_global_multiforce_fit_overlays(
    curves_app,
    global_fit,
    sim_opts=sim_opts,
    cfg=cfg,
)
plt.show()

# -----------------------------------------------------------------------------
# 6. Optional: output all stable branches for one curve after the fit
# -----------------------------------------------------------------------------
# This is slower because it uses multistart steady-state solves at each d.

branch_cfg = cfg
branch_cfg.output_branches = True
branch_cfg.branch_n_points = 80
branch_cfg.branch_n_starts = 9

branches = fdcal.compute_all_stable_branches_for_multiforce_fit(
    curves_app[idx],
    one_fit,
    sim_opts=sim_opts,
    cfg=branch_cfg,
    n_points=80,
)

print("Stable branches per d:", branches["n_branches_at_d"])
for tr in branches["tracks"]:
    print(tr["label"], "points=", len(tr["d"]))

# Attach branch result to the fit and plot it.
one_fit["branches"] = branches
fig, ax = fdcal.plot_one_multiforce_fit_overlay(
    curves_app[idx],
    one_fit,
    sim_opts=sim_opts,
    cfg=branch_cfg,
    show_branches=True,
)
plt.show()

# -----------------------------------------------------------------------------
# 7. One-call workflow, if you prefer
# -----------------------------------------------------------------------------
# pack = fdcal.run_full_multiforce_fd_workflow(
#     curves_app,
#     retract_curves=retract_curves,
#     conv_L=conv_L,
#     sim_opts=sim_opts,
#     cfg=cfg,
# )
# individual_fits = pack["individual_fits"]
# global_fit = pack["global_fit"]
