"""Export the fitted DT-SPM models for the calibration-grating v2 pipeline.

Writes a self-contained model bundle under
`output/dt_models/calibration_grating_v2/` containing:

- `pi_ridge.joblib`           — sklearn pipeline (Imputer → Poly₂ → Scaler → RidgeCV)
                                that maps (log scan_speed, drive_nm, setpoint, log I_exp)
                                → (log10 P, log10 I).
- `dd_models.joblib`          — dict with
                                  · `poly`        PolynomialFeatures(degree=2)
                                  · `scaler`      StandardScaler
                                  · `feature_cols` list of input feature names
                                  · `dd_trace`    Ridge mapping features → centered trace (256 px)
                                  · `dd_retrace`  Ridge mapping features → centered retrace
                                  · `res_trace`   Ridge mapping features → (exp − DT_PI) trace residual
                                  · `res_retrace` Ridge mapping features → retrace residual
- `fd_prior.npz`              — copy of the FD library (drive_nm, height, amp, phase) so the
                                DT scanner can be rebuilt without external dependencies.
- `metadata.json`             — feature names, PI bounds, training sizes, code paths.

The script is **standalone** — it consumes only the persisted bundle / cache files
under the project's workspace (`output/`, `calibration_cache/`) so it works even
if `/tmp/*` has been cleared.  No DT execution is required, so `numba` is NOT a
dependency of this script.

Run with:
    python codes/cali_v2_export_models.py
"""
from __future__ import annotations

import json, sys
from pathlib import Path

import numpy as np
import pandas as pd
from joblib import dump, load
from scipy.interpolate import interp1d


PROJECT_ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = PROJECT_ROOT / 'output' / 'dt_models' / 'calibration_grating_v2'


def main():
    from sklearn.linear_model import Ridge, RidgeCV
    from sklearn.preprocessing import PolynomialFeatures, StandardScaler
    from sklearn.pipeline import make_pipeline
    from sklearn.impute import SimpleImputer

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    print(f'Writing model bundle to {OUT_DIR}')

    # ---- Load persisted artifacts (no /tmp dependency) -------------------
    fd_npz   = np.load(PROJECT_ROOT / 'output' / 'cali_fd.npz')
    cleaned  = np.load(PROJECT_ROOT / 'output' / 'cleaned_traces.npz')
    bundle   = np.load(PROJECT_ROOT / 'output' / 'calibration_grating_v2_figures'
                        / 'figure_45_data_bundle.npz')

    # FD library + scanner physical parameters (copied verbatim from the v3 notebook)
    fd_drive_raw = fd_npz['drive']
    fd_height    = fd_npz['height']
    fd_amp       = fd_npz['amp']
    fd_phase     = fd_npz['phase']
    fd_drive_nm  = np.array([np.nanmean(fd_amp[i, -10:])
                              for i in range(len(fd_drive_raw))], dtype=float)

    # Experimental controls + traces + DT-under-ridge-PI prediction
    traces_exp = bundle['traces_exp']
    dt_PI      = bundle['dt_PI']
    drive_exp  = bundle['drive_exp']
    setpoint_exp = bundle['setpoint_exp']
    igain_exp  = bundle['igain_exp']
    fit_idx    = bundle['fit_idx']
    test_idx   = bundle['test_idx']

    # The cleaned-traces file carries x_measured; the calibration dataset
    # does not vary scan speed, so scan_rate is one for every condition.
    N_COND = traces_exp.shape[0]
    scan_rate_exp = np.ones(N_COND, dtype=float)

    # Local PI fits joblib (oracle (P, I, log10_P, log10_I, loss) per condition)
    local_fits_path = (PROJECT_ROOT / 'calibration_cache' / 'calibration_grating_v2'
                        / 'local_PI_fits_multi.joblib')
    if not local_fits_path.exists():
        local_fits_path = (PROJECT_ROOT / 'calibration_cache' / 'calibration_grating_v2'
                            / 'local_PI_fits_balanced_v2iter.joblib')
    local_fits = load(str(local_fits_path))
    local_df = pd.DataFrame(local_fits)
    print(f'  using local PI cache: {local_fits_path.name}  '
           f'({len(local_fits)} fits)')

    # ---- Stage 1 ridge: controls → (log10 P, log10 I) --------------------
    FEATURES = ['log_scan_speed', 'drive_nm', 'setpoint', 'log_I_exp']
    TARGETS  = ['log10_P', 'log10_I']

    def cf(i):
        return {
            'log_scan_speed': float(np.log10(max(scan_rate_exp[int(i)], 1e-12))),
            'drive_nm':       float(drive_exp[int(i)]),
            'setpoint':       float(setpoint_exp[int(i)]),
            'log_I_exp':      float(np.log10(max(igain_exp[int(i)], 1e-12))),
        }

    bounds = dict(
        bound_lo_P=-2.5, bound_hi_P=2.0,
        bound_lo_I=-1.5, bound_hi_I=3.0,
    )
    log10P = local_df['log10_P'].to_numpy(float)
    log10I = local_df['log10_I'].to_numpy(float)
    loss   = local_df['loss'].to_numpy(float)
    hit_P  = (np.abs(log10P - bounds['bound_lo_P']) < 0.05) | (np.abs(log10P - bounds['bound_hi_P']) < 0.05)
    hit_I  = (np.abs(log10I - bounds['bound_lo_I']) < 0.05) | (np.abs(log10I - bounds['bound_hi_I']) < 0.05)
    loss_cap = np.nanpercentile(loss[np.isfinite(loss)], 80)
    clean_mask = (np.isfinite(log10P) & np.isfinite(log10I) & np.isfinite(loss)
                  & ~(hit_P | hit_I) & (loss < loss_cap))
    train_records = []
    for keep, rec in zip(clean_mask, local_fits):
        if not keep: continue
        f = cf(rec['cond']); f.update({'log10_P': rec['log10_P'], 'log10_I': rec['log10_I']})
        train_records.append(f)
    train_df = pd.DataFrame(train_records)

    pi_ridge = make_pipeline(
        SimpleImputer(strategy='median'),
        PolynomialFeatures(degree=2, include_bias=False),
        StandardScaler(),
        RidgeCV(alphas=np.logspace(-3, 3, 25), cv=min(5, max(2, len(train_df)))),
    )
    pi_ridge.fit(train_df[FEATURES].to_numpy(float),
                  train_df[TARGETS].to_numpy(float))
    pi_path = OUT_DIR / 'pi_ridge.joblib'
    dump(pi_ridge, pi_path)
    print(f'  saved {pi_path}  (ridge PI map, {len(train_df)} train rows)')

    # ---- Stage 2 data-driven + hybrid Ridge models -----------------------
    # A0(drive) — reconstructed from the FD library without instantiating the
    # full scanner.  A0 of an FD curve at a given drive is the median far-field
    # amplitude (the same definition used to build fd_drive_nm).  This is
    # effectively the identity over the calibration drives but we use a
    # monotone interpolation for robustness on held-out drives.
    A0_interp = interp1d(fd_drive_nm, fd_drive_nm,
                          kind='linear', bounds_error=False,
                          fill_value=(float(fd_drive_nm[0]), float(fd_drive_nm[-1])))

    DD_FEATURE_COLS = ['drive_nm', 'setpoint', 'I_exp', 'log_I_exp',
                        'A0', 'log_A0', 'drive_x_sp', 'drive_x_logI',
                        'sp_x_logI', 'A0_x_sp']
    def dd_features(i):
        d   = float(drive_exp[int(i)])
        sp  = float(setpoint_exp[int(i)])
        ig  = float(igain_exp[int(i)])
        A0  = float(A0_interp(d))
        log_ig = float(np.log10(max(ig, 1e-12)))
        return [d, sp, ig, log_ig, A0, np.log10(max(A0, 1e-12)),
                d * sp, d * log_ig, sp * log_ig, A0 * sp]

    all_idx = np.arange(N_COND)
    X = np.array([dd_features(i) for i in all_idx], float)

    def center(arr, trim=10):
        arr = arr.copy()
        for i in range(arr.shape[0]):
            arr[i] = arr[i] - np.nanmean(arr[i, trim:-trim])
        return arr

    Yt_c = center(traces_exp[:, 0, :])
    Yr_c = center(traces_exp[:, 1, :])
    dt_PI_c = np.zeros_like(dt_PI)
    dt_PI_c[:, 0, :] = center(dt_PI[:, 0, :])
    dt_PI_c[:, 1, :] = center(dt_PI[:, 1, :])

    poly = PolynomialFeatures(degree=2, include_bias=False)
    scaler = StandardScaler()
    Xtr = X[fit_idx]
    Xtr_poly = scaler.fit_transform(poly.fit_transform(Xtr))

    Yt_tr = Yt_c[fit_idx]; Yr_tr = Yr_c[fit_idx]
    Rt = Yt_c - dt_PI_c[:, 0, :]
    Rr = Yr_c - dt_PI_c[:, 1, :]

    dd_trace   = Ridge(alpha=10.0).fit(Xtr_poly, Yt_tr)
    dd_retrace = Ridge(alpha=10.0).fit(Xtr_poly, Yr_tr)
    res_trace   = Ridge(alpha=10.0).fit(Xtr_poly, Rt[fit_idx])
    res_retrace = Ridge(alpha=10.0).fit(Xtr_poly, Rr[fit_idx])

    dd_pack = dict(
        poly=poly, scaler=scaler,
        feature_cols=DD_FEATURE_COLS,
        dd_trace=dd_trace, dd_retrace=dd_retrace,
        res_trace=res_trace, res_retrace=res_retrace,
        trim=10,
        n_pixels=int(Yt_c.shape[-1]),
    )
    dd_path = OUT_DIR / 'dd_models.joblib'
    dump(dd_pack, dd_path)
    print(f'  saved {dd_path}  (poly2 + scaler + 4 ridges, {len(fit_idx)} train rows)')

    # ---- FD prior copy (self-contained scanner reconstruction) -----------
    scanner_params = {
        'k': 25, 'A': float(np.nanmedian(fd_amp)),
        'd0': float(np.nanmax(fd_height) * 0.8),
        'R': 10, 'H': 1e-19, 'E_star': 1e9, 'Q': 250,
    }
    fd_prior_path = OUT_DIR / 'fd_prior.npz'
    np.savez(fd_prior_path,
        fd_drive_raw=fd_drive_raw,
        fd_drive_nm=fd_drive_nm, fd_height=fd_height,
        fd_amp=fd_amp, fd_phase=fd_phase,
        scanner_params=np.array(json.dumps(scanner_params)),
    )
    print(f'  saved {fd_prior_path}  (FD library + scanner physical params)')

    # ---- Metadata --------------------------------------------------------
    meta = dict(
        feature_columns_pi=FEATURES,
        target_columns_pi=TARGETS,
        pi_bounds=bounds,
        feature_columns_dd=DD_FEATURE_COLS,
        n_train_pi=int(len(train_df)),
        n_train_dd=int(len(fit_idx)),
        n_test=int(len(test_idx)),
        n_pixels=int(Yt_c.shape[-1]),
        center_trim=10,
        local_PI_cache=str(local_fits_path.name),
        notebook='Fit DT controller parameters to calibration grating scans_v3.ipynb',
        scanner_module='codes/Scanner_fixed_extended_fd.py',
        substeps_module='codes/Scanner_numba_substeps_v3.py',
        scaffold_module='codes/dt_static_dynamic_calibration_scaffold_v3.py',
        scanner_cfg=dict(
            dx_hat=1.0, n_substeps=50, T_I=0.3,
            z_rate_limit_hat=1e6, fd_n_d=4096,
            A_meas_init_hat=1.0, phi_meas_init_deg=120.0,
            d_init_hat=0.0,
        ),
        fd_surface_kwargs=dict(
            x_mode='d_over_A0', common_range='union', n_x=1024,
            extend_to_zero_amplitude=True, extension_n_fit=5,
            extension_n_bridge=30, extension_phi_mode='linear',
            extension_F_mode='nearest',
        ),
    )
    meta_path = OUT_DIR / 'metadata.json'
    meta_path.write_text(json.dumps(meta, indent=2))
    print(f'  saved {meta_path}')

    print('\nBundle contents:')
    for f in sorted(OUT_DIR.iterdir()):
        print(f'  {f.name:24s}  {f.stat().st_size:>10d} bytes')


if __name__ == '__main__':
    main()
