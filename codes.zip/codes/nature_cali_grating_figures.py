"""Nature-style Figures 4 and 5 built from the calibration-grating v2 pipeline.

Figure 4 — PI controller fit:
  (a) Canonical grating profile h_truth versus clean experimental scan lines.
  (b) Loss surface for the local PI fit (illustrative condition) + fitted
      versus ridge-predicted (P, I) labels.
  (c, d) Experimental trace/retrace versus DT-simulated trace/retrace for an
      optimal (low trace-retrace RMSE) condition and a sub-optimal one.
  (e) Quality scatter — simulated trace/retrace RMSE versus the experimental
      value across all held-out conditions.

Figure 5 — PI fit vs data-driven + PI vs pure data-driven:
  (a) Predicted versus experimental scan quality on held-out (unfitted)
      conditions, three colour series.
  (b) Per-method per-line RMSE distribution (boxplot) for trace + retrace.
  (c) Bar chart of summary metrics (MAE on quality + RMSE on per-line).
  (d) Example trace overlay (one held-out condition) with PI, hybrid,
      and data-driven predictions versus the experiment.

The two figures share the Nature style palette in `nature_statement_figures.py`.
"""
from __future__ import annotations

import sys, json
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from joblib import load
from matplotlib import gridspec
from scipy.stats import pearsonr

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from codes.nature_statement_figures import (
    NATURE_DIRNAME, PALETTE, panel_label, save_pub, setup_style,
)
from codes.dt_gp_static_calibration_v3 import diff_shifted


# ---------------------------------------------------------------------------
def _load_pipeline():
    """Pull the basics / pipeline / prediction caches."""
    cali_basics      = np.load('/tmp/cali_v2_basics.npz')
    cali_pipeline    = np.load('/tmp/cali_v2_pipeline.npz')
    cali_predictions = np.load('/tmp/cali_v2_predictions.npz')
    return cali_basics, cali_pipeline, cali_predictions


def _align_pair(sim, exp):
    sa, ea = diff_shifted(sim, exp)
    n = min(len(sa), len(ea))
    return sa[:n], ea[:n]


def _center(arr, trim=10):
    """Center each row by its interior mean."""
    arr = np.asarray(arr, float).copy()
    if arr.ndim == 1:
        return arr - np.nanmean(arr[trim:-trim])
    for i in range(arr.shape[0]):
        arr[i] = arr[i] - np.nanmean(arr[i, trim:-trim])
    return arr


def _quality(arr, trim=10):
    """Trace-retrace RMSE per condition."""
    out = np.zeros(arr.shape[0])
    for i in range(arr.shape[0]):
        t = arr[i,0,trim:-trim] - np.nanmean(arr[i,0,trim:-trim])
        r = arr[i,1,trim:-trim] - np.nanmean(arr[i,1,trim:-trim])
        m = np.isfinite(t) & np.isfinite(r)
        out[i] = float(np.sqrt(np.nanmean((t[m]-r[m])**2))) if m.sum()>=5 else np.nan
    return out


def _line_rmse(sim_line, exp_line, trim=10):
    sa, ea = diff_shifted(sim_line, exp_line)
    n = min(len(sa), len(ea))
    if n <= 2*trim+4: lo,hi = 0,n
    else: lo,hi = trim, n-trim
    sc = sa[lo:hi]-np.nanmean(sa[lo:hi]); ec = ea[lo:hi]-np.nanmean(ea[lo:hi])
    m = np.isfinite(sc) & np.isfinite(ec)
    if m.sum() < 5: return np.nan
    return float(np.sqrt(np.nanmean((sc[m]-ec[m])**2)))


def _model_line_rmse(arr, traces_exp):
    out = np.full((arr.shape[0], 2), np.nan, float)
    for i in range(arr.shape[0]):
        out[i,0] = _line_rmse(arr[i,0], traces_exp[i,0])
        out[i,1] = _line_rmse(arr[i,1], traces_exp[i,1])
    return out


def _pick_optimal_suboptimal(test_idx, traces_exp, dt_PI):
    """Pick one optimal (best PI control of trace-retrace) and one sub-optimal."""
    q = _quality(traces_exp[test_idx])
    order = np.argsort(q)
    return int(test_idx[order[0]]), int(test_idx[order[-1]])


def _pi_loss_surface(scanner, h_truth, traces_exp, cond, scanner_cfg,
                     drive_exp, setpoint_exp, scan_rate_exp,
                     P_grid, I_grid):
    """Compute pixel-wise MSE surface in nm^2 for one condition."""
    from codes.dt_static_dynamic_calibration_scaffold_v3 import (
        run_scanner_line, get_height_from_out)
    fd_table = scanner.prepare_fd_table_for_drive(float(drive_exp[cond]),
                                                  n_d=scanner_cfg.fd_n_d)
    L = np.full((len(P_grid), len(I_grid)), np.nan)
    exp_tr, exp_rt = traces_exp[cond,0], traces_exp[cond,1]
    for ip, P in enumerate(P_grid):
        for jq, I in enumerate(I_grid):
            try:
                out = run_scanner_line(scanner, h_truth,
                    drive_nm=float(drive_exp[cond]),
                    setpoint=float(setpoint_exp[cond]),
                    scan_speed_hat=float(scan_rate_exp[cond]),
                    P=float(P), I=float(I),
                    cfg=scanner_cfg, fd_table=fd_table)
                sim_tr, sim_rt = get_height_from_out(out)
            except Exception:
                continue
            st, et = _align_pair(sim_tr, exp_tr); sr, er = _align_pair(sim_rt, exp_rt)
            trim = 10
            n = min(len(st), len(et))
            if n <= 2*trim+4: continue
            sc = st[trim:n-trim]-np.nanmean(st[trim:n-trim])
            ec = et[trim:n-trim]-np.nanmean(et[trim:n-trim])
            sd = sr[trim:n-trim]-np.nanmean(sr[trim:n-trim])
            ed = er[trim:n-trim]-np.nanmean(er[trim:n-trim])
            L[ip,jq] = float(np.nanmean((sc-ec)**2) + np.nanmean((sd-ed)**2))
    return L


# ---------------------------------------------------------------------------
def build_figure_4(out_dir: Path, scanner, scanner_cfg, P_loss_grid, I_loss_grid):
    setup_style()
    basics, pipe, preds = _load_pipeline()
    traces_exp = preds['traces_exp']
    h_truth    = preds['h_truth']
    fit_idx    = preds['fit_idx']
    test_idx   = preds['test_idx']
    dt_PI      = preds['dt_PI']
    dt_oracle  = preds['dt_oracle']
    drive_exp  = preds['drive_exp']
    setpoint_exp = preds['setpoint_exp']

    # ----- panel (a): h_truth vs clean experimental scan lines -----
    clean_scores = pipe['clean_scores']
    clean_pick   = np.argsort(clean_scores)[:8]

    # ----- pick optimal / sub-optimal -----
    cond_opt, cond_sub = _pick_optimal_suboptimal(test_idx, traces_exp, dt_PI)

    # ----- PI loss surface for optimal condition -----
    local_fits = load(PROJECT_ROOT / 'calibration_cache/calibration_grating_v2/local_PI_fits_balanced_v2iter.joblib')
    local_df = pd.DataFrame(local_fits)
    # ridge-predicted (already computed in /tmp predictions)
    P_pred_all = preds['P_all']; I_pred_all = preds['I_all']
    oracle_PI = {r['cond']: (r['P'], r['I'], r['log10_P'], r['log10_I']) for r in local_fits}

    # ----- build figure -----
    fig = plt.figure(figsize=(7.2, 8.2), constrained_layout=False)
    gs = gridspec.GridSpec(3, 3, figure=fig,
                            height_ratios=[1.0, 1.05, 1.05],
                            width_ratios=[1.05, 1.0, 1.1])
    fig.subplots_adjust(left=0.08, right=0.985, bottom=0.085, top=0.88,
                        wspace=0.55, hspace=0.80)
    fig.suptitle("Calibrating the PI loop of the digital twin against experimental scan lines",
                 x=0.06, y=0.96, ha='left', fontsize=9.7, fontweight='bold')

    # (a) h_truth vs clean exp lines
    ax = fig.add_subplot(gs[0, 0])
    panel_label(ax, 'a')
    for k, ci in enumerate(clean_pick[:6]):
        ln = _center(traces_exp[ci, 0])
        ax.plot(ln, lw=0.7, color=PALETTE['grey'], alpha=0.7,
                 label='clean experimental traces' if k == 0 else None)
    ax.plot(_center(h_truth), color=PALETTE['blue'], lw=1.7,
             label='synthetic $h_{\\mathrm{truth}}$')
    ax.set_xlabel('pixel')
    ax.set_ylabel('height (nm)')
    ax.set_title('Synthetic profile mirrors\nthe grating geometry')
    ax.legend(frameon=False, loc='lower center', fontsize=6.6)

    # (b) PI loss surface, illustrative condition (median noise)
    ax = fig.add_subplot(gs[0, 1])
    panel_label(ax, 'b')
    cond_for_surf = int(clean_pick[0])
    P_grid = np.logspace(-1.5, 1.5, 11); I_grid = np.logspace(-0.5, 2.5, 11)
    # Try to reuse a previously cached loss surface to keep figure rebuilds fast.
    _surf_cache = Path('/tmp/cali_v2_loss_surface.npz')
    if _surf_cache.exists():
        _surf = np.load(_surf_cache)
        if (int(_surf['cond']) == cond_for_surf
                and np.allclose(_surf['P_grid'], P_grid)
                and np.allclose(_surf['I_grid'], I_grid)):
            L = _surf['L']
            print(f'Loss surface reused from {_surf_cache}')
        else:
            L = None
    else:
        L = None
    if L is None:
        print(f'Loss surface for cond {cond_for_surf}...')
        L = _pi_loss_surface(scanner, h_truth, traces_exp, cond_for_surf, scanner_cfg,
                              drive_exp, setpoint_exp,
                              np.ones_like(drive_exp), P_grid, I_grid)
        np.savez(_surf_cache, cond=cond_for_surf, P_grid=P_grid, I_grid=I_grid, L=L)
    Plog = np.log10(P_grid); Ilog = np.log10(I_grid)
    im = ax.pcolormesh(Plog, Ilog, np.log10(L).T, shading='auto', cmap='magma_r')
    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.025)
    cb.set_label('')
    cb.ax.set_title(r'$\log_{10}$ loss', fontsize=5.5, pad=2)
    p_star, i_star = oracle_PI[cond_for_surf][2], oracle_PI[cond_for_surf][3]
    ax.plot(p_star, i_star, marker='*', color=PALETTE['teal'], markersize=10,
             markeredgecolor='white', markeredgewidth=0.8,
             label=f'fitted (P*,I*) = ({oracle_PI[cond_for_surf][0]:.2f},{oracle_PI[cond_for_surf][1]:.2f})')
    ax.set_xlabel(r'$\log_{10} P$'); ax.set_ylabel(r'$\log_{10} I$')
    ax.set_title(f'PI loss surface\n(cond {cond_for_surf})')
    ax.legend(frameon=False, fontsize=6.2, loc='lower right')

    # (c) Local-PI fit (P,I) vs ridge prediction
    ax = fig.add_subplot(gs[0, 2])
    panel_label(ax, 'c')
    # only show conditions where oracle is available (fit_idx)
    fit_log10P = np.array([oracle_PI[int(i)][2] for i in fit_idx])
    fit_log10I = np.array([oracle_PI[int(i)][3] for i in fit_idx])
    pred_logP  = np.log10(np.array([P_pred_all[int(i)] for i in fit_idx]))
    pred_logI  = np.log10(np.array([I_pred_all[int(i)] for i in fit_idx]))
    ax.scatter(fit_log10P, pred_logP, s=14, color=PALETTE['blue'],
                edgecolor='white', lw=0.4, label='P')
    ax.scatter(fit_log10I, pred_logI, s=14, color=PALETTE['orange'],
                marker='D', edgecolor='white', lw=0.4, label='I')
    lo = min(np.nanmin(fit_log10P), np.nanmin(fit_log10I), np.nanmin(pred_logP), np.nanmin(pred_logI))
    hi = max(np.nanmax(fit_log10P), np.nanmax(fit_log10I), np.nanmax(pred_logP), np.nanmax(pred_logI))
    ax.plot([lo, hi],[lo,hi], color=PALETTE['muted'], lw=0.6, ls='--')
    ax.set_xlabel(r'fitted $\log_{10}$ (P or I)')
    ax.set_ylabel(r'ridge-predicted')
    ax.set_title('PI map generalizes\nacross controls')
    ax.legend(frameon=False, fontsize=6.5, loc='upper left')

    # (d) Optimal condition trace overlay
    ax = fig.add_subplot(gs[1, 0])
    panel_label(ax, 'd')
    i = cond_opt
    et = _center(traces_exp[i,0]); er = _center(traces_exp[i,1])
    st = _center(dt_PI[i,0]); sr = _center(dt_PI[i,1])
    ax.plot(et, color=PALETTE['ink'], lw=1.0)
    ax.plot(er, color=PALETTE['ink'], lw=0.9, ls=':', alpha=0.85)
    ax.plot(st, color=PALETTE['blue'], lw=1.0)
    ax.plot(sr, color=PALETTE['blue'], lw=0.9, ls=':', alpha=0.85)
    ax.set_xlabel('pixel'); ax.set_ylabel('height (nm)')
    ax.set_title(f'Optimal condition\nd={drive_exp[i]:.0f} nm, sp={setpoint_exp[i]:.2f}')

    # (e) Sub-optimal condition trace overlay
    ax = fig.add_subplot(gs[1, 1])
    panel_label(ax, 'e')
    i = cond_sub
    et = _center(traces_exp[i,0]); er = _center(traces_exp[i,1])
    st = _center(dt_PI[i,0]); sr = _center(dt_PI[i,1])
    ax.plot(et, color=PALETTE['ink'], lw=1.0)
    ax.plot(er, color=PALETTE['ink'], lw=0.9, ls=':', alpha=0.85)
    ax.plot(st, color=PALETTE['red'], lw=1.0)
    ax.plot(sr, color=PALETTE['red'], lw=0.9, ls=':', alpha=0.85)
    ax.set_xlabel('pixel'); ax.set_ylabel('height (nm)')
    ax.set_title(f'Sub-optimal condition\nd={drive_exp[i]:.0f} nm, sp={setpoint_exp[i]:.2f}')

    # (f) DT-vs-experiment quality scatter
    ax = fig.add_subplot(gs[1, 2])
    panel_label(ax, 'f')
    q_exp = _quality(traces_exp)
    q_sim = _quality(dt_PI)
    ax.scatter(q_exp[fit_idx], q_sim[fit_idx], s=14, color=PALETTE['blue'],
                edgecolor='white', lw=0.4, label='fit conditions')
    ax.scatter(q_exp[test_idx], q_sim[test_idx], s=22, color=PALETTE['orange'],
                marker='D', edgecolor='white', lw=0.4, label='held-out')
    qmax = float(np.nanpercentile(np.concatenate([q_exp[fit_idx], q_sim[fit_idx],
                                                    q_exp[test_idx], q_sim[test_idx]]),
                                   95))
    qmax = max(qmax, 25.0)
    ax.plot([0, qmax],[0, qmax], color=PALETTE['muted'], lw=0.6, ls='--')
    ax.set_xlim(0, qmax); ax.set_ylim(0, qmax)
    ax.set_xlabel('experimental scan quality (nm)')
    ax.set_ylabel('DT-simulated scan quality (nm)')
    ax.set_title('Scan-quality recovery')
    ax.legend(frameon=False, fontsize=6.4, loc='upper left')

    # ---- bottom row: per-condition trace overlays for a few representative test conds ----
    # find three test conds spanning the q_exp distribution
    q_test = q_exp[test_idx]
    order = np.argsort(q_test)
    picks = [int(test_idx[order[0]]),
             int(test_idx[order[len(order)//2]]),
             int(test_idx[order[-1]])]
    titles = ['best held-out', 'median held-out', 'worst held-out']
    for col, (i, ttl) in enumerate(zip(picks, titles)):
        ax = fig.add_subplot(gs[2, col])
        panel_label(ax, 'ghi'[col])
        et = _center(traces_exp[i,0]); er = _center(traces_exp[i,1])
        st = _center(dt_PI[i,0]); sr = _center(dt_PI[i,1])
        ax.plot(et, color=PALETTE['ink'], lw=0.9)
        ax.plot(er, color=PALETTE['ink'], lw=0.9, ls=':', alpha=0.8)
        ax.plot(st, color=PALETTE['blue'], lw=0.9)
        ax.plot(sr, color=PALETTE['blue'], lw=0.9, ls=':', alpha=0.8)
        ax.set_xlabel('pixel'); ax.set_ylabel('height (nm)')
        ax.set_title(f'{ttl}\nd={drive_exp[i]:.0f} nm, sp={setpoint_exp[i]:.2f}')

    # Figure-level legend at the bottom of the page for panels d–i
    from matplotlib.lines import Line2D
    leg_handles = [
        Line2D([0],[0], color=PALETTE['ink'], lw=1.0, label='experiment (trace)'),
        Line2D([0],[0], color=PALETTE['ink'], lw=0.9, ls=':', label='experiment (retrace)'),
        Line2D([0],[0], color=PALETTE['blue'], lw=1.0, label='DT trace (PI-fit)'),
        Line2D([0],[0], color=PALETTE['blue'], lw=0.9, ls=':', label='DT retrace (PI-fit)'),
        Line2D([0],[0], color=PALETTE['red'], lw=1.0, label='DT trace (sub-optimal cond.)'),
    ]
    fig.legend(handles=leg_handles, loc='lower center',
                bbox_to_anchor=(0.5, 0.005), ncol=5, frameon=False,
                fontsize=6.4, handletextpad=0.5, columnspacing=1.2)
    out = save_pub(fig, out_dir, 'figure_4_cali_PI_fit_nature')
    print('Saved Figure 4:', out)
    return out


# ---------------------------------------------------------------------------
def build_figure_5(out_dir: Path):
    setup_style()
    basics, pipe, preds = _load_pipeline()
    traces_exp = preds['traces_exp']
    fit_idx    = preds['fit_idx']
    test_idx   = preds['test_idx']
    dt_PI      = preds['dt_PI']
    dd         = preds['dd']
    hyb        = preds['hyb']
    drive_exp  = preds['drive_exp']
    setpoint_exp = preds['setpoint_exp']

    q_exp = _quality(traces_exp)
    q_PI  = _quality(dt_PI)
    q_dd  = _quality(dd)
    q_hyb = _quality(hyb)

    rmse_PI  = _model_line_rmse(dt_PI, traces_exp)
    rmse_dd  = _model_line_rmse(dd, traces_exp)
    rmse_hyb = _model_line_rmse(hyb, traces_exp)

    # Held-out only
    h = test_idx
    method_color = {
        'PI fitting'    : PALETTE['blue'],
        'PI + data-driven': PALETTE['purple'],
        'pure data-driven': PALETTE['orange'],
    }
    method_q = {
        'PI fitting'    : q_PI[h],
        'PI + data-driven': q_hyb[h],
        'pure data-driven': q_dd[h],
    }
    method_rmse = {
        'PI fitting'    : np.nanmean(rmse_PI[h], axis=1),
        'PI + data-driven': np.nanmean(rmse_hyb[h], axis=1),
        'pure data-driven': np.nanmean(rmse_dd[h], axis=1),
    }

    fig = plt.figure(figsize=(7.2, 6.0), constrained_layout=False)
    gs = gridspec.GridSpec(2, 3, figure=fig, height_ratios=[1.1, 1.0],
                            width_ratios=[1.0, 1.0, 1.1])
    fig.subplots_adjust(left=0.08, right=0.985, bottom=0.13, top=0.83,
                        wspace=0.62, hspace=0.95)
    fig.suptitle("Predicting scan quality on unfitted conditions:\nPI fit vs hybrid vs pure data-driven",
                 x=0.06, y=0.965, ha='left', fontsize=9.7, fontweight='bold')

    # (a) Predicted q vs Experimental q — scatter for the three methods
    ax = fig.add_subplot(gs[0, 0])
    panel_label(ax, 'a')
    all_q = []
    for name, qm in method_q.items():
        all_q.extend(qm.tolist())
        finite = np.isfinite(qm) & np.isfinite(q_exp[h])
        ax.scatter(q_exp[h][finite], qm[finite], s=22,
                    color=method_color[name], edgecolor='white', lw=0.4,
                    alpha=0.9, label=name)
    qmax = float(np.nanpercentile([v for v in all_q if np.isfinite(v)] + q_exp[h].tolist(), 95))
    qmax = min(max(qmax, 25.0), 60.0)
    ax.plot([0, qmax],[0,qmax], color=PALETTE['muted'], lw=0.6, ls='--')
    ax.set_xlim(0, qmax); ax.set_ylim(0, qmax)
    ax.set_xlabel('experimental quality (nm)')
    ax.set_ylabel('predicted quality (nm)')
    ax.set_title('Held-out scan-quality\n(trace–retrace RMSE)')
    ax.legend(frameon=False, fontsize=6.3, loc='upper left')

    # (b) Quality MAE bar
    ax = fig.add_subplot(gs[0, 1])
    panel_label(ax, 'b')
    names = list(method_q.keys())
    qe = q_exp[h]
    mae_q = [float(np.nanmean(np.abs(qe-method_q[n]))) for n in names]
    medae_q = [float(np.nanmedian(np.abs(qe-method_q[n]))) for n in names]
    x = np.arange(len(names))
    w = 0.36
    ax.bar(x-w/2, mae_q, width=w, color=[method_color[n] for n in names], alpha=0.85, label='MAE')
    ax.bar(x+w/2, medae_q, width=w, color=[method_color[n] for n in names], alpha=0.45, label='Median AE')
    ax.set_xticks(x, [n.replace(' + ','\n+ ').replace(' ','\n',1) for n in names])
    ax.set_ylabel('quality error (nm)')
    ax.set_title('Held-out quality error')
    ax.legend(frameon=False, fontsize=6.3, loc='upper right')

    # (c) Per-line RMSE box plot
    ax = fig.add_subplot(gs[0, 2])
    panel_label(ax, 'c')
    box_data = [method_rmse[n][np.isfinite(method_rmse[n])] for n in names]
    bp = ax.boxplot(box_data, widths=0.55, patch_artist=True,
                     medianprops=dict(color='black', lw=1.0),
                     flierprops=dict(marker='.', markersize=2,
                                      markerfacecolor=PALETTE['muted']))
    for patch, n in zip(bp['boxes'], names):
        patch.set_facecolor(method_color[n]); patch.set_alpha(0.6)
        patch.set_edgecolor(method_color[n]); patch.set_linewidth(0.8)
    ax.set_xticks([1,2,3], [n.replace(' + ','\n+ ').replace(' ','\n',1) for n in names])
    ax.set_ylabel('per-line RMSE vs experiment (nm)')
    ax.set_title('Held-out scan-line\nshape error')
    ax.set_yscale('log')

    # (d, e, f) overlay panels — one held-out condition, three methods
    # pick a held-out condition where data-driven and DT disagree the most
    disagree = np.abs(q_dd[h] - q_PI[h])
    disagree[~np.isfinite(disagree)] = -1
    j = int(np.argmax(disagree))
    cond_overlay = int(h[j])

    titles = [('PI fitting',   dt_PI),
              ('PI + data-driven', hyb),
              ('pure data-driven', dd)]
    for col, (name, arr) in enumerate(titles):
        ax = fig.add_subplot(gs[1, col])
        panel_label(ax, 'def'[col])
        et = _center(traces_exp[cond_overlay, 0]); er = _center(traces_exp[cond_overlay, 1])
        st = _center(arr[cond_overlay, 0]); sr = _center(arr[cond_overlay, 1])
        ax.plot(et, color=PALETTE['ink'], lw=1.0)
        ax.plot(er, color=PALETTE['ink'], lw=0.9, ls=':', alpha=0.85)
        ax.plot(st, color=method_color[name], lw=1.0)
        ax.plot(sr, color=method_color[name], lw=0.9, ls=':', alpha=0.85)
        ax.set_xlabel('pixel'); ax.set_ylabel('height (nm)')
        ax.set_title(f'{name}\ncond {cond_overlay} (d={drive_exp[cond_overlay]:.0f} nm)')

    # Figure-level legend for the bottom row
    from matplotlib.lines import Line2D
    leg_handles = [
        Line2D([0],[0], color=PALETTE['ink'], lw=1.0, label='experiment (trace)'),
        Line2D([0],[0], color=PALETTE['ink'], lw=0.9, ls=':', label='experiment (retrace)'),
        Line2D([0],[0], color=PALETTE['blue'], lw=1.0, label='PI fitting (model)'),
        Line2D([0],[0], color=PALETTE['purple'], lw=1.0, label='PI + data-driven (model)'),
        Line2D([0],[0], color=PALETTE['orange'], lw=1.0, label='pure data-driven (model)'),
    ]
    fig.legend(handles=leg_handles, loc='lower center',
                bbox_to_anchor=(0.5, 0.005), ncol=5, frameon=False,
                fontsize=6.3, handletextpad=0.5, columnspacing=1.0)
    fig.text(0.985, 0.045,
             f"N held-out = {len(h)}.   Dashed line = perfect prediction.   "
             "RMSE box: log-scale.",
             ha='right', fontsize=6.0, color=PALETTE['muted'])

    out = save_pub(fig, out_dir, 'figure_5_cali_PI_vs_hybrid_vs_DD_nature')

    # Summary metrics to a JSON for the manifest
    summary = {
        name: {
            'n_test': int(np.sum(np.isfinite(method_q[name]))),
            'quality_MAE_nm':    float(np.nanmean(np.abs(qe-method_q[name]))),
            'quality_medAE_nm':  float(np.nanmedian(np.abs(qe-method_q[name]))),
            'line_rmse_median_nm': float(np.nanmedian(method_rmse[name])),
            'line_rmse_mean_nm':   float(np.nanmean(method_rmse[name])),
        }
        for name in names
    }
    (out_dir / 'figure_5_cali_summary.json').write_text(json.dumps(summary, indent=2))
    print('Saved Figure 5:', out)
    print(json.dumps(summary, indent=2))
    return out


# ---------------------------------------------------------------------------
BUNDLE_FILENAME = 'figure_45_data_bundle.npz'


def save_figure_bundle(bundle_path: Path,
                        scanner=None, scanner_cfg=None,
                        loss_P_grid=None, loss_I_grid=None,
                        recompute_loss: bool = False) -> Path:
    """Aggregate everything the two Nature-style figures consume into one .npz.

    The bundle is plot-only: NO scanner runs are required to redraw the figures
    in a fresh notebook.  Just call `load_figure_bundle(path)` and feed the
    result to `replot_figure_4` / `replot_figure_5`.

    When the predictions cache contains the three I-gain regime examples
    (produced by `codes/cali_v2_refit_with_multiobjective_loss.py`), the
    bundle also carries `demo_*` arrays and a `three_examples` JSON, used
    by `_figure_4_from_bundle` to add the small/optimal/large I row.
    """
    basics, pipe, preds = _load_pipeline()
    traces_exp = preds['traces_exp']
    h_truth    = preds['h_truth']
    fit_idx    = preds['fit_idx']
    test_idx   = preds['test_idx']
    dt_PI      = preds['dt_PI']
    dt_oracle  = preds['dt_oracle']
    dd         = preds['dd']
    hyb        = preds['hyb']
    P_all      = preds['P_all']
    I_all      = preds['I_all']
    drive_exp    = preds['drive_exp']
    setpoint_exp = preds['setpoint_exp']
    igain_exp    = preds['igain_exp']

    # PI labels (oracle local fits) keyed by condition index
    local_fits = load(PROJECT_ROOT / 'calibration_cache/calibration_grating_v2/local_PI_fits_balanced_v2iter.joblib')
    cond_arr = np.array([r['cond'] for r in local_fits], int)
    oracle_log10P = np.array([r['log10_P'] for r in local_fits], float)
    oracle_log10I = np.array([r['log10_I'] for r in local_fits], float)
    oracle_P      = 10.0 ** oracle_log10P
    oracle_I      = 10.0 ** oracle_log10I

    # PI loss surface for the illustrative condition
    clean_scores = pipe['clean_scores']
    clean_pick   = np.argsort(clean_scores)[:8]
    cond_for_surf = int(clean_pick[0])
    P_grid = loss_P_grid if loss_P_grid is not None else np.logspace(-1.5, 1.5, 11)
    I_grid = loss_I_grid if loss_I_grid is not None else np.logspace(-0.5, 2.5, 11)

    surf_cache = Path('/tmp/cali_v2_loss_surface.npz')
    L = None
    if surf_cache.exists() and not recompute_loss:
        _s = np.load(surf_cache)
        if (int(_s['cond']) == cond_for_surf
                and np.allclose(_s['P_grid'], P_grid)
                and np.allclose(_s['I_grid'], I_grid)):
            L = _s['L']
    if L is None:
        if scanner is None or scanner_cfg is None:
            raise RuntimeError("scanner is required to compute the loss surface for the bundle. "
                                "Pass scanner/scanner_cfg or precompute /tmp/cali_v2_loss_surface.npz.")
        L = _pi_loss_surface(scanner, h_truth, traces_exp, cond_for_surf, scanner_cfg,
                              drive_exp, setpoint_exp,
                              np.ones_like(drive_exp), P_grid, I_grid)
        np.savez(surf_cache, cond=cond_for_surf, P_grid=P_grid, I_grid=I_grid, L=L)

    # Derived metrics (same defs as in the plotting code)
    q_exp = _quality(traces_exp)
    q_PI  = _quality(dt_PI)
    q_dd  = _quality(dd)
    q_hyb = _quality(hyb)
    rmse_PI  = _model_line_rmse(dt_PI, traces_exp)
    rmse_dd  = _model_line_rmse(dd, traces_exp)
    rmse_hyb = _model_line_rmse(hyb, traces_exp)

    # Optional: three-example regime data from the multi-objective refit
    demo_extras = {}
    for key in ('example_cond_small_I', 'example_cond_optimal_I',
                 'example_cond_large_I', 'demo_cond_idx', 'demo_sim_tr',
                 'demo_sim_rt', 'demo_PI'):
        if key in preds:
            demo_extras[key] = preds[key]
    # Three-example JSON written by the refit script; embedded as raw bytes
    three_ex_path = Path('/tmp/cali_v2_three_examples.json')
    three_ex_bytes = three_ex_path.read_text() if three_ex_path.exists() else ''

    bundle_path.parent.mkdir(parents=True, exist_ok=True)
    np.savez(bundle_path,
        # core experimental + DT arrays
        traces_exp=traces_exp,
        h_truth=h_truth,
        dt_PI=dt_PI,
        dt_oracle=dt_oracle,
        dd=dd,
        hyb=hyb,
        # condition controls
        drive_exp=drive_exp, setpoint_exp=setpoint_exp, igain_exp=igain_exp,
        # ridge PI predictions for every condition
        P_all=P_all, I_all=I_all,
        # oracle local PI fits (indexed by cond_arr)
        oracle_cond=cond_arr,
        oracle_log10P=oracle_log10P, oracle_log10I=oracle_log10I,
        oracle_P=oracle_P, oracle_I=oracle_I,
        # index splits
        fit_idx=fit_idx, test_idx=test_idx,
        clean_scores=clean_scores, clean_pick=clean_pick,
        # PI loss surface for one condition
        loss_cond=cond_for_surf, loss_P_grid=P_grid, loss_I_grid=I_grid, loss_L=L,
        # derived metrics
        q_exp=q_exp, q_PI=q_PI, q_dd=q_dd, q_hyb=q_hyb,
        rmse_PI=rmse_PI, rmse_dd=rmse_dd, rmse_hyb=rmse_hyb,
        # three-example regime data (only present if multi-objective refit ran)
        three_examples_json=np.array(three_ex_bytes),
        **demo_extras,
    )
    print('Saved figure bundle to', bundle_path)
    return bundle_path


def load_figure_bundle(bundle_path: Path) -> dict:
    """Load the bundle written by `save_figure_bundle`."""
    z = np.load(bundle_path, allow_pickle=False)
    out = {k: z[k] for k in z.files}
    # Reconstruct oracle PI dict for convenient lookups
    oracle = {}
    for i, c in enumerate(out['oracle_cond']):
        oracle[int(c)] = {
            'P':       float(out['oracle_P'][i]),
            'I':       float(out['oracle_I'][i]),
            'log10_P': float(out['oracle_log10P'][i]),
            'log10_I': float(out['oracle_log10I'][i]),
        }
    out['oracle_PI'] = oracle
    return out


# ---------------------------------------------------------------------------
# Self-contained replot helpers — produce the same figures from the bundle.
# These intentionally do NOT touch the scanner or any joblib caches.
# ---------------------------------------------------------------------------
def _figure_4_from_bundle(bundle: dict, out_dir: Path, *,
                           save: bool = True, stem: str = 'figure_4_cali_PI_fit_nature'):
    """Publication-ready Figure 4 from the self-contained calibration bundle.

    Core claim: a PI map calibrated against experimental scan-line behaviour
    recovers scan quality on held-out controls, while the small/optimal/large
    I-gain examples reveal the behaviour terms that make the fit identifiable.
    """
    setup_style()
    mpl.rcParams.update({
        "font.size": 6.9,
        "axes.labelsize": 7.0,
        "axes.titlesize": 7.2,
        "xtick.labelsize": 6.1,
        "ytick.labelsize": 6.1,
        "legend.fontsize": 6.0,
        "axes.linewidth": 0.55,
    })

    traces_exp   = bundle['traces_exp']
    h_truth      = bundle['h_truth']
    fit_idx      = np.asarray(bundle['fit_idx'], int)
    test_idx     = np.asarray(bundle['test_idx'], int)
    dt_PI        = bundle['dt_PI']
    drive_exp    = bundle['drive_exp']
    setpoint_exp = bundle['setpoint_exp']
    igain_exp    = bundle.get('igain_exp', np.full(traces_exp.shape[0], np.nan))
    P_all = bundle['P_all']; I_all = bundle['I_all']
    clean_pick = np.asarray(bundle['clean_pick'], int)
    q_exp = bundle['q_exp']; q_PI = bundle['q_PI']
    oracle = bundle['oracle_PI']

    has_demo = 'demo_cond_idx' in bundle and bundle['demo_cond_idx'].size == 3
    ex_bytes = bundle.get('three_examples_json', np.array(''))
    ex_text  = str(ex_bytes) if np.asarray(ex_bytes).size else ''
    try:
        import json as _json
        examples = _json.loads(ex_text) if ex_text else []
    except Exception:
        examples = []

    fig = plt.figure(figsize=(7.2, 7.65), constrained_layout=False)
    gs = gridspec.GridSpec(
        3, 6, figure=fig,
        height_ratios=[0.88, 1.05, 0.95],
        width_ratios=[1, 1, 1, 1, 1, 1],
    )
    fig.subplots_adjust(left=0.07, right=0.965, bottom=0.085, top=0.895,
                        wspace=0.74, hspace=0.66)
    fig.suptitle("PI-loop calibration transfers experimental scan behaviour to the digital twin",
                 x=0.07, y=0.966, ha='left', fontsize=9.2, fontweight='bold')
    fig.text(0.07, 0.936,
             "Far-field grating geometry constrains the controller fit; held-out controls test whether the calibrated PI map preserves trace-retrace quality.",
             ha='left', va='top', fontsize=6.4, color=PALETTE['muted'])

    def _pl(ax, label):
        panel_label(ax, label, x=-0.115, y=1.10)

    def _style_trace_ax(ax, ylabel=False):
        ax.set_xlabel('pixel')
        if ylabel:
            ax.set_ylabel('height (nm)')
        else:
            ax.set_ylabel('')
        ax.axhline(0, color='0.86', lw=0.45, zorder=0)
        ax.margins(x=0.02)

    # a, grating geometry plus clean experimental envelope.
    ax = fig.add_subplot(gs[0, 0:2]); _pl(ax, 'a')
    for k, ci in enumerate(clean_pick[:7]):
        ax.plot(_center(traces_exp[int(ci), 0]), lw=0.55,
                color=PALETTE['grey'], alpha=0.55,
                label='clean experimental traces' if k == 0 else None)
    ax.plot(_center(h_truth), color=PALETTE['blue'], lw=1.75,
            label=r'synthetic $h_{\mathrm{truth}}$')
    _style_trace_ax(ax, ylabel=True)
    ax.set_title('Synthetic target follows the grating envelope')
    ax.legend(frameon=False, loc='lower left', fontsize=5.8, handlelength=1.8)
    ax.set_ylim(-135, 130)

    # b, PI loss surface.
    ax = fig.add_subplot(gs[0, 2:4]); _pl(ax, 'b')
    P_grid = bundle['loss_P_grid']; I_grid = bundle['loss_I_grid']; L = bundle['loss_L']
    cond_for_surf = int(bundle['loss_cond'])
    logL = np.log10(np.maximum(L, 1e-12))
    im = ax.pcolormesh(np.log10(P_grid), np.log10(I_grid), logL.T,
                       shading='auto', cmap='magma_r', rasterized=True)
    levels = np.nanquantile(logL, [0.2, 0.4, 0.6, 0.8])
    ax.contour(np.log10(P_grid), np.log10(I_grid), logL.T,
               levels=levels, colors='white', linewidths=0.35, alpha=0.55)
    cb = fig.colorbar(im, ax=ax, fraction=0.048, pad=0.018)
    cb.set_label('')
    cb.ax.set_title(r'$\log_{10}$ loss', fontsize=5.5, pad=2)
    p_star = oracle[cond_for_surf]['log10_P']; i_star = oracle[cond_for_surf]['log10_I']
    ax.plot(p_star, i_star, marker='*', color=PALETTE['teal'], markersize=9.5,
            markeredgecolor='white', markeredgewidth=0.65)
    ax.text(0.03, 0.05,
            f"local optimum\nP={oracle[cond_for_surf]['P']:.2g}, I={oracle[cond_for_surf]['I']:.2g}",
            transform=ax.transAxes, ha='left', va='bottom', fontsize=5.8,
            color=PALETTE['ink'],
            bbox=dict(boxstyle='round,pad=0.18', fc='white', ec='none', alpha=0.78))
    ax.set_xlabel(r'$\log_{10} P$'); ax.set_ylabel(r'$\log_{10} I$')
    ax.set_title(f'Local PI loss surface (condition {cond_for_surf})')

    # c, map generalization.
    ax = fig.add_subplot(gs[0, 4:6]); _pl(ax, 'c')
    fit_use = [int(i) for i in fit_idx if int(i) in oracle]
    fit_log10P = np.array([oracle[i]['log10_P'] for i in fit_use])
    fit_log10I = np.array([oracle[i]['log10_I'] for i in fit_use])
    pred_logP  = np.log10(np.array([P_all[i] for i in fit_use]))
    pred_logI  = np.log10(np.array([I_all[i] for i in fit_use]))
    ax.scatter(fit_log10P, pred_logP, s=16, color=PALETTE['blue'],
               edgecolor='white', lw=0.35, label='P')
    ax.scatter(fit_log10I, pred_logI, s=17, color=PALETTE['orange'], marker='D',
               edgecolor='white', lw=0.35, label='I')
    lo = float(min(fit_log10P.min(), fit_log10I.min(), pred_logP.min(), pred_logI.min()))
    hi = float(max(fit_log10P.max(), fit_log10I.max(), pred_logP.max(), pred_logI.max()))
    pad = 0.12 * (hi - lo)
    ax.plot([lo-pad, hi+pad], [lo-pad, hi+pad], color=PALETTE['muted'], lw=0.65, ls='--')
    rP = np.corrcoef(fit_log10P, pred_logP)[0, 1]
    rI = np.corrcoef(fit_log10I, pred_logI)[0, 1]
    ax.text(0.04, 0.05, f'r(P)={rP:.2f}\nr(I)={rI:.2f}', transform=ax.transAxes,
            fontsize=5.8, color=PALETTE['muted'])
    ax.set_xlim(lo-pad, hi+pad); ax.set_ylim(lo-pad, hi+pad)
    ax.set_xlabel(r'local-fit $\log_{10}$ gain')
    ax.set_ylabel(r'predicted $\log_{10}$ gain', labelpad=1)
    ax.set_title('Ridge PI map across controls')
    ax.legend(frameon=False, fontsize=5.8, loc='upper left', handlelength=1.0)

    # d-f, three I regimes.
    row2_axes = []
    if has_demo:
        regimes = [
            ('small I: hysteresis',  PALETTE['orange']),
            ('optimal I: aligned',   PALETTE['blue']),
            ('large I: oscillatory', PALETTE['red']),
        ]
        demo_idx = bundle['demo_cond_idx']
        demo_tr  = bundle['demo_sim_tr']; demo_rt = bundle['demo_sim_rt']
        demo_PI  = bundle['demo_PI']
        for col, ((ttl, c), ci, P, I) in enumerate(
                zip(regimes, [int(demo_idx[k]) for k in range(3)],
                    demo_PI[:, 0], demo_PI[:, 1])):
            ax = fig.add_subplot(gs[1, 2*col:2*col+2]); row2_axes.append(ax); _pl(ax, 'def'[col])
            ax.plot(_center(traces_exp[ci, 0]), color=PALETTE['ink'], lw=0.9)
            ax.plot(_center(traces_exp[ci, 1]), color=PALETTE['ink'], lw=0.85, ls=':', alpha=0.86)
            ax.plot(_center(np.asarray(demo_tr[col])), color=c, lw=1.05)
            ax.plot(_center(np.asarray(demo_rt[col])), color=c, lw=0.95, ls=':', alpha=0.86)
            _style_trace_ax(ax, ylabel=(col == 0))
            ax.set_title(ttl)
            ax.text(0.03, 0.96,
                    f'cond {ci}; Iexp={float(igain_exp[ci]):.0f}\nP*={P:.2g}, I*={I:.2g}',
                    transform=ax.transAxes, ha='left', va='top', fontsize=5.55,
                    color=PALETTE['ink'],
                    bbox=dict(boxstyle='round,pad=0.15', fc='white', ec='none', alpha=0.72))
        ylim = (-165, 165)
        for ax in row2_axes:
            ax.set_ylim(*ylim)
    else:
        q_test = q_exp[test_idx]; order_t = np.argsort(q_test)
        picks = [(int(test_idx[order_t[0]]), 'best held-out', PALETTE['blue']),
                 (int(test_idx[order_t[-1]]), 'worst held-out', PALETTE['red'])]
        for col, (ci, ttl, c) in enumerate(picks):
            ax = fig.add_subplot(gs[1, 3*col:3*col+3]); row2_axes.append(ax); _pl(ax, 'de'[col])
            ax.plot(_center(traces_exp[ci, 0]), color=PALETTE['ink'], lw=0.9)
            ax.plot(_center(traces_exp[ci, 1]), color=PALETTE['ink'], lw=0.85, ls=':', alpha=0.86)
            ax.plot(_center(dt_PI[ci, 0]), color=c, lw=1.05)
            ax.plot(_center(dt_PI[ci, 1]), color=c, lw=0.95, ls=':', alpha=0.86)
            _style_trace_ax(ax, ylabel=(col == 0))
            ax.set_title(f'{ttl}: d={float(drive_exp[ci]):.0f} nm, sp={float(setpoint_exp[ci]):.2f}')

    # g, scan-quality recovery.
    ax = fig.add_subplot(gs[2, 0:2]); _pl(ax, 'g')
    finite_fit = np.isfinite(q_exp[fit_idx]) & np.isfinite(q_PI[fit_idx])
    finite_test = np.isfinite(q_exp[test_idx]) & np.isfinite(q_PI[test_idx])
    ax.scatter(q_exp[fit_idx][finite_fit], q_PI[fit_idx][finite_fit], s=15,
               color=PALETTE['blue'], edgecolor='white', lw=0.35, label=f'fit (n={finite_fit.sum()})')
    ax.scatter(q_exp[test_idx][finite_test], q_PI[test_idx][finite_test], s=24,
               color=PALETTE['orange'], marker='D', edgecolor='white', lw=0.35,
               label=f'held-out (n={finite_test.sum()})')
    qvals = np.concatenate([q_exp[fit_idx], q_PI[fit_idx], q_exp[test_idx], q_PI[test_idx]])
    qmax = max(float(np.nanpercentile(qvals, 95)), 25.0)
    ax.plot([0, qmax], [0, qmax], color=PALETTE['muted'], lw=0.65, ls='--')
    mae_hold = float(np.nanmean(np.abs(q_exp[test_idx] - q_PI[test_idx])))
    ax.text(0.04, 0.92, f'held-out MAE = {mae_hold:.1f} nm', transform=ax.transAxes,
            ha='left', va='top', fontsize=5.8, color=PALETTE['ink'])
    ax.set_xlim(0, qmax); ax.set_ylim(0, qmax)
    ax.set_xlabel('experimental scan quality (nm)')
    ax.set_ylabel('DT-simulated scan quality (nm)')
    ax.set_title('Held-out scan-quality recovery')
    ax.legend(frameon=False, fontsize=5.8, loc='lower right', handlelength=1.0)

    # h, behavioural signatures.
    ax = fig.add_subplot(gs[2, 2:4]); _pl(ax, 'h')
    names_h = ['small I', 'optimal I', 'large I']
    colors  = [PALETTE['orange'], PALETTE['blue'], PALETTE['red']]
    stats = ['trrt', 'hf_tr', 'gm_tr']
    stat_labels = ['trace-retrace\nRMSE', 'high-frequency\nresidual', 'gradient\nMAD']
    x_pos = np.arange(len(stats)); w = 0.22
    if examples:
        for k, ex in enumerate(examples):
            sim = [ex['sim_sig'][s] for s in stats]
            exp = [ex['exp_sig'][s] for s in stats]
            xpos = x_pos + (k - 1) * w * 1.08
            ax.bar(xpos, np.log1p(sim), width=w, color=colors[k], alpha=0.58)
            ax.scatter(xpos, np.log1p(exp), color=colors[k], edgecolor='black',
                       linewidth=0.7, s=21, zorder=3)
    ax.set_xticks(x_pos, stat_labels)
    ax.set_ylabel(r'$\log(1 + \mathrm{metric})$')
    ax.set_title('Regime-specific behavioural signatures')
    # Direct mini-legend inside panel.
    for k, (name, c) in enumerate(zip(names_h, colors)):
        ax.text(0.03 + 0.28*k, 0.98, name, transform=ax.transAxes,
                ha='left', va='top', fontsize=5.6, color=c)
    ax.scatter([], [], color='white', edgecolor='black', s=21, label='experiment')
    ax.bar([], [], color='0.7', alpha=0.58, label='DT')
    ax.legend(frameon=False, loc='upper right', fontsize=5.5, handlelength=0.8)

    # i, loss components.
    ax = fig.add_subplot(gs[2, 4:6]); _pl(ax, 'i')
    if examples:
        comps = np.array([
            [ex['shape_mse'], ex['trrt_term'], ex['hf_term'], ex['grad_term']]
            for ex in examples
        ])
        weights = np.array([1.0, 80.0, 300.0, 300.0])
        frac = comps * weights
        frac = frac / (np.nansum(frac, axis=1, keepdims=True) + 1e-12)
        labels = ['shape MSE', 'trace-retrace', 'HF residual', 'gradient MAD']
        bar_colors = [PALETTE['grey'], PALETTE['teal'], PALETTE['orange'], PALETTE['purple']]
        bottom = np.zeros(len(examples))
        x = np.arange(len(examples))
        for k in range(4):
            ax.bar(x, frac[:, k], bottom=bottom, color=bar_colors[k],
                   width=0.68, label=labels[k], alpha=0.92)
            bottom += frac[:, k]
        ax.set_xticks(x, ['small\nI', 'optimal\nI', 'large\nI'])
        ax.set_ylim(0, 1.0)
        ax.set_ylabel('fraction of weighted loss')
        ax.set_title('Loss terms emphasize failure modes')
        ax.legend(frameon=False, fontsize=5.45, loc='center left',
                  bbox_to_anchor=(1.01, 0.50), handlelength=1.0)

    from matplotlib.lines import Line2D
    handles = [
        Line2D([0], [0], color=PALETTE['ink'], lw=1.0, label='experiment trace'),
        Line2D([0], [0], color=PALETTE['ink'], lw=0.9, ls=':', label='experiment retrace'),
        Line2D([0], [0], color=PALETTE['orange'], lw=1.0, label='DT small I'),
        Line2D([0], [0], color=PALETTE['blue'], lw=1.0, label='DT optimal I'),
        Line2D([0], [0], color=PALETTE['red'], lw=1.0, label='DT large I'),
    ]
    fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(0.50, 0.014),
               ncol=5, frameon=False, fontsize=5.9, handlelength=1.5,
               handletextpad=0.45, columnspacing=1.05)
    fig.text(0.965, 0.036,
             'Dashed traces indicate retrace; diagonal in panel g marks perfect quality prediction.',
             ha='right', va='bottom', fontsize=5.55, color=PALETTE['muted'])

    if save:
        return save_pub(fig, out_dir, stem)
    return fig

def _figure_5_from_bundle(bundle: dict, out_dir: Path, *,
                           save: bool = True, stem: str = 'figure_5_cali_PI_vs_hybrid_vs_DD_nature'):
    setup_style()
    traces_exp = bundle['traces_exp']
    test_idx   = np.asarray(bundle['test_idx'], int)
    dt_PI      = bundle['dt_PI']; dd = bundle['dd']; hyb = bundle['hyb']
    drive_exp  = bundle['drive_exp']
    q_exp = bundle['q_exp']; q_PI = bundle['q_PI']; q_dd = bundle['q_dd']; q_hyb = bundle['q_hyb']
    rmse_PI = bundle['rmse_PI']; rmse_dd = bundle['rmse_dd']; rmse_hyb = bundle['rmse_hyb']

    h = test_idx
    names = ['PI fitting', 'PI + data-driven', 'pure data-driven']
    short_names = ['PI', 'PI+DD', 'DD']
    method_color = {
        'PI fitting': PALETTE['blue'],
        'PI + data-driven': PALETTE['purple'],
        'pure data-driven': PALETTE['orange'],
    }
    method_model = {'PI fitting': dt_PI, 'PI + data-driven': hyb, 'pure data-driven': dd}
    method_q = {'PI fitting': q_PI[h], 'PI + data-driven': q_hyb[h], 'pure data-driven': q_dd[h]}
    method_rmse = {
        'PI fitting': np.nanmean(rmse_PI[h], axis=1),
        'PI + data-driven': np.nanmean(rmse_hyb[h], axis=1),
        'pure data-driven': np.nanmean(rmse_dd[h], axis=1),
    }

    fig = plt.figure(figsize=(7.2, 6.35), constrained_layout=False)
    gs = gridspec.GridSpec(2, 6, figure=fig, height_ratios=[0.92, 1.06],
                           width_ratios=[1, 1, 1, 1, 1, 1])
    fig.subplots_adjust(left=0.07, right=0.965, bottom=0.115, top=0.87,
                        wspace=0.78, hspace=0.72)
    fig.suptitle("Held-out scan prediction: physics-guided PI versus learned corrections",
                 x=0.07, y=0.962, ha='left', fontsize=9.2, fontweight='bold')
    fig.text(0.07, 0.932,
             "Unfitted controls are scored by trace-retrace quality and by direct scan-line shape agreement.",
             ha='left', va='top', fontsize=6.35, color=PALETTE['muted'])

    def _fig5_label(ax, label):
        ax.text(-0.13, 1.08, label, transform=ax.transAxes,
                ha='left', va='top', fontsize=9.2, fontweight='bold',
                color='black', clip_on=False)

    qe = q_exp[h]
    finite_q_values = [qe[np.isfinite(qe)]]
    finite_q_values += [method_q[n][np.isfinite(method_q[n])] for n in names]
    finite_q_values = np.concatenate([v for v in finite_q_values if v.size])
    qmax = float(np.nanpercentile(finite_q_values, 97)) if finite_q_values.size else 30.0
    qmax = min(max(qmax * 1.05, 24.0), 60.0)

    ax = fig.add_subplot(gs[0, 0:2]); _fig5_label(ax, 'a.')
    for name in names:
        qm = method_q[name]
        finite = np.isfinite(qm) & np.isfinite(qe)
        ax.scatter(qe[finite], qm[finite], s=21,
                   color=method_color[name], edgecolor='white', lw=0.35,
                   alpha=0.88, label=name)
    ax.plot([0, qmax], [0, qmax], color=PALETTE['muted'], lw=0.65, ls='--')
    ax.set_xlim(0, qmax); ax.set_ylim(0, qmax)
    ax.set_xlabel('experimental quality (nm)')
    ax.set_ylabel('predicted quality (nm)')
    ax.set_title('Prediction calibration')
    ax.legend(frameon=False, fontsize=5.9, loc='upper left',
              handletextpad=0.35, borderpad=0.1)
    ax.set_aspect('equal', adjustable='box')

    ax = fig.add_subplot(gs[0, 2:4]); _fig5_label(ax, 'b.')
    qe = q_exp[h]
    mae_q = [float(np.nanmean(np.abs(qe - method_q[n]))) for n in names]
    medae_q = [float(np.nanmedian(np.abs(qe - method_q[n]))) for n in names]
    x = np.arange(len(names)); w = 0.36
    ax.bar(x - w/2, mae_q, width=w, color=[method_color[n] for n in names],
           alpha=0.86, label='mean abs. error')
    ax.bar(x + w/2, medae_q, width=w, color=[method_color[n] for n in names],
           alpha=0.36, label='median abs. error')
    for xi, v in zip(x - w/2, mae_q):
        ax.text(xi, v + 0.22, f'{v:.1f}', ha='center', va='bottom',
                fontsize=5.5, color=PALETTE['ink'])
    for xi, v in zip(x + w/2, medae_q):
        ax.text(xi, v + 0.22, f'{v:.1f}', ha='center', va='bottom',
                fontsize=5.5, color=PALETTE['muted'])
    ax.set_xticks(x, short_names)
    ax.set_ylabel('quality error (nm)')
    ax.set_title('Trace-retrace quality error')
    ax.set_ylim(0, max(mae_q + medae_q) * 1.58)
    ax.legend(frameon=False, fontsize=5.65, loc='upper left',
              bbox_to_anchor=(0.02, 0.99), handlelength=1.35,
              borderpad=0.1, labelspacing=0.25)

    ax = fig.add_subplot(gs[0, 4:6]); _fig5_label(ax, 'c.')
    box_data = [method_rmse[n][np.isfinite(method_rmse[n])] for n in names]
    rng = np.random.default_rng(5)
    bp = ax.boxplot(box_data, widths=0.50, patch_artist=True, showfliers=False,
                    medianprops=dict(color='black', lw=1.0),
                    whiskerprops=dict(color=PALETTE['ink'], lw=0.75),
                    capprops=dict(color=PALETTE['ink'], lw=0.75))
    for patch, n in zip(bp['boxes'], names):
        patch.set_facecolor(method_color[n]); patch.set_alpha(0.46)
        patch.set_edgecolor(method_color[n]); patch.set_linewidth(0.8)
    for i, vals in enumerate(box_data, start=1):
        if len(vals) == 0:
            continue
        jitter = rng.normal(0.0, 0.035, size=len(vals))
        ax.scatter(np.full(len(vals), i) + jitter, vals, s=7.5,
                   color=method_color[names[i-1]], alpha=0.62, lw=0, zorder=2)
    ax.set_xticks([1, 2, 3], short_names)
    ax.set_ylabel('line-shape RMSE (nm)')
    ax.set_title('Scan-line shape error')
    ax.set_yscale('log')
    all_shape = np.concatenate([v for v in box_data if len(v)])
    if all_shape.size:
        lo = max(8.0, float(np.nanpercentile(all_shape, 3)) * 0.82)
        hi = float(np.nanpercentile(all_shape, 97)) * 1.28
        ax.set_ylim(lo, hi)
        ticks = np.array([10, 15, 20, 30, 40, 60, 80, 100], float)
        ticks = ticks[(ticks >= lo) & (ticks <= hi)]
        if ticks.size:
            ax.set_yticks(ticks)
            ax.set_yticklabels([f'{t:g}' for t in ticks])
    ax.text(0.03, 0.97, 'log scale', transform=ax.transAxes,
            ha='left', va='top', fontsize=5.55, color=PALETTE['muted'])

    shape_gain = method_rmse['PI fitting'] - np.minimum(method_rmse['PI + data-driven'],
                                                        method_rmse['pure data-driven'])
    shape_gain[~np.isfinite(shape_gain)] = -np.inf
    if np.all(~np.isfinite(shape_gain)):
        j_overlay = int(np.nanargmax(np.abs(method_q['pure data-driven'] - method_q['PI fitting'])))
    else:
        j_overlay = int(np.nanargmax(shape_gain))
    cond_overlay = int(h[j_overlay])

    centered = [_center(traces_exp[cond_overlay, 0]), _center(traces_exp[cond_overlay, 1])]
    for arr in method_model.values():
        centered.extend([_center(arr[cond_overlay, 0]), _center(arr[cond_overlay, 1])])
    yy = np.concatenate([v[np.isfinite(v)] for v in centered if np.asarray(v).size])
    ymin, ymax = np.nanpercentile(yy, [1, 99]) if yy.size else (-120, 120)
    pad = max(15.0, 0.08 * (ymax - ymin))
    for col, name in enumerate(names):
        ax = fig.add_subplot(gs[1, 2*col:2*col+2]); _fig5_label(ax, f"{'def'[col]}.")
        arr = method_model[name]
        et = _center(traces_exp[cond_overlay, 0]); er = _center(traces_exp[cond_overlay, 1])
        st = _center(arr[cond_overlay, 0]); sr = _center(arr[cond_overlay, 1])
        ax.plot(et, color=PALETTE['ink'], lw=0.98)
        ax.plot(er, color=PALETTE['ink'], lw=0.86, ls=':', alpha=0.85)
        ax.plot(st, color=method_color[name], lw=1.08)
        ax.plot(sr, color=method_color[name], lw=0.95, ls=':', alpha=0.86)
        ax.set_xlabel('pixel')
        ax.set_ylabel('height (nm)' if col == 0 else '')
        ax.set_ylim(ymin - pad, ymax + pad)
        ax.margins(x=0.02)
        ax.axhline(0, color='0.87', lw=0.45, zorder=0)
        ax.set_title(f"{short_names[col]} on held-out cond. {cond_overlay}\n"
                     f"drive = {float(drive_exp[cond_overlay]):.0f} nm")
        q_pred = method_q[name][j_overlay]
        shape = method_rmse[name][j_overlay]
        ax.text(0.03, 0.06, f"quality {q_pred:.1f} nm\nshape {shape:.1f} nm",
                transform=ax.transAxes, ha='left', va='bottom', fontsize=5.65,
                color=method_color[name],
                bbox=dict(boxstyle='round,pad=0.16', fc='white', ec='none', alpha=0.76))

    from matplotlib.lines import Line2D
    leg_handles = [
        Line2D([0], [0], color=PALETTE['ink'], lw=1.0, label='experiment trace'),
        Line2D([0], [0], color=PALETTE['ink'], lw=0.9, ls=':', label='experiment retrace'),
        Line2D([0], [0], color=PALETTE['blue'], lw=1.0, label='PI model'),
        Line2D([0], [0], color=PALETTE['purple'], lw=1.0, label='PI + data-driven model'),
        Line2D([0], [0], color=PALETTE['orange'], lw=1.0, label='pure data-driven model'),
    ]
    fig.legend(handles=leg_handles, loc='lower center',
               bbox_to_anchor=(0.47, 0.018), ncol=5, frameon=False,
               fontsize=5.85, handletextpad=0.45, columnspacing=0.85)
    fig.text(0.985, 0.045,
             f"N held-out = {len(h)}. Dashed diagonal = perfect quality prediction.",
             ha='right', fontsize=5.7, color=PALETTE['muted'])

    summary = {
        name: {
            'n_test': int(np.sum(np.isfinite(method_q[name]) & np.isfinite(qe))),
            'quality_MAE_nm': float(np.nanmean(np.abs(qe - method_q[name]))),
            'quality_medAE_nm': float(np.nanmedian(np.abs(qe - method_q[name]))),
            'line_shape_RMSE_median_nm': float(np.nanmedian(method_rmse[name])),
            'line_shape_RMSE_mean_nm': float(np.nanmean(method_rmse[name])),
        }
        for name in names
    }
    if save:
        out_dir.mkdir(parents=True, exist_ok=True)
        (out_dir / 'figure_5_cali_summary.json').write_text(json.dumps(summary, indent=2))

    if save:
        return save_pub(fig, out_dir, stem)
    return fig


def replot_figure_4(bundle_path, out_dir=None, save=True):
    """Self-contained Figure 4 replot from a bundle file."""
    bundle = load_figure_bundle(Path(bundle_path))
    out_dir = Path(out_dir) if out_dir is not None else Path(bundle_path).parent
    return _figure_4_from_bundle(bundle, out_dir, save=save)


def replot_figure_5(bundle_path, out_dir=None, save=True):
    """Self-contained Figure 5 replot from a bundle file."""
    bundle = load_figure_bundle(Path(bundle_path))
    out_dir = Path(out_dir) if out_dir is not None else Path(bundle_path).parent
    return _figure_5_from_bundle(bundle, out_dir, save=save)


# ---------------------------------------------------------------------------
def main():
    out_dir = PROJECT_ROOT / 'output' / NATURE_DIRNAME
    out_dir.mkdir(parents=True, exist_ok=True)

    # Build the scanner once for the loss-surface panel
    import importlib
    import codes.Scanner_fixed_extended_fd as sfe
    import codes.Scanner_numba_substeps_v3 as sn
    importlib.reload(sfe); importlib.reload(sn)
    sn.install_numba_substep_methods(sfe.ScannerFD, verbose=False)
    from codes.dt_static_dynamic_calibration_scaffold_v3 import ScannerRunConfig

    b  = np.load('/tmp/cali_v2_basics.npz')
    fd_drive_nm=b['fd_drive_nm']; fd_height=b['fd_height']; fd_amp=b['fd_amp']; fd_phase=b['fd_phase']
    measured_fd = {float(fd_drive_nm[i]): {'d': fd_height[i], 'A': fd_amp[i], 'phi': fd_phase[i]}
                   for i in range(len(fd_drive_nm))}
    surface = sfe.FDDriveSurface.from_measured_fd(
        measured_fd, x_mode='d_over_A0', common_range='union', n_x=1024,
        extend_to_zero_amplitude=True, extension_n_fit=5, extension_n_bridge=30,
        extension_phi_mode='linear', extension_F_mode='nearest',
    )
    params = {'k':25,'A':float(np.nanmedian(fd_amp)),'d0':float(np.nanmax(fd_height)*0.8),
              'R':10,'H':1e-19,'E_star':1e9,'Q':250}
    scanner = sfe.ScannerFD(params=params, conversions={k:1.0 for k in params},
                            fd_model=sfe.make_normalized_fd_lookup(surface, conv_L=1.0))
    scanner_cfg = ScannerRunConfig(
        dx_hat=1.0, n_substeps=50, tau_A=None, tau_phi=None, tau_z=None,
        z_rate_limit_hat=1e6, d_init_hat=0.0, A_meas_init_hat=1.0,
        phi_meas_init_deg=120.0, T_I=3e-1, h_smooth_sigma_px=0.0,
        fd_n_d=4096, use_fast=True,
    )

    P_grid = np.logspace(-1.5, 1.5, 11); I_grid = np.logspace(-0.5, 2.5, 11)

    # Persist the plot-only data bundle FIRST so the figure builders can
    # consume it.  The figures are then rendered from the bundle, which
    # means they survive even if the live scanner / sklearn pipeline is
    # not available.
    bundle_dir = PROJECT_ROOT / 'output' / 'calibration_grating_v2_figures'
    bundle_path = save_figure_bundle(
        bundle_dir / BUNDLE_FILENAME,
        scanner=scanner, scanner_cfg=scanner_cfg,
        loss_P_grid=P_grid, loss_I_grid=I_grid,
    )
    paths4 = replot_figure_4(bundle_path, out_dir=out_dir)
    paths5 = replot_figure_5(bundle_path, out_dir=out_dir)

    # Update manifest.json with the new figures
    manifest = out_dir / 'manifest.json'
    if manifest.exists():
        m = json.loads(manifest.read_text())
    else:
        m = {}
    m['figure_4_cali_PI_fit'] = paths4
    m['figure_5_cali_PI_vs_hybrid_vs_DD'] = paths5
    m['figure_45_data_bundle'] = str(bundle_path)
    manifest.write_text(json.dumps(m, indent=2))
    print('updated manifest')


if __name__ == '__main__':
    main()
