from __future__ import annotations

from pathlib import Path

import numpy as np

from codes.nature_cali_grating_figures import _figure_5_from_bundle, load_figure_bundle


def _as_dict(bundle):
    if isinstance(bundle, dict):
        return dict(bundle)
    if isinstance(bundle, (str, Path)):
        return load_figure_bundle(Path(bundle))
    return {k: bundle[k] for k in bundle.files}


def plot_figure5(bundle, save_to=None, stem: str = "figure_5_cali_PI_vs_hybrid_vs_DD_nature"):
    """Render the updated publication-ready Figure 5.

    Parameters
    ----------
    bundle
        Either a dict, an opened np.load object, or a path to
        figure_45_data_bundle.npz.
    save_to
        Directory to save PNG/PDF/TIFF. If None, the figure is returned only.
    stem
        Output filename stem when save_to is provided.
    """
    bundle = _as_dict(bundle)
    out_dir = Path(save_to) if save_to is not None else Path(".")
    return _figure_5_from_bundle(bundle, out_dir, save=save_to is not None, stem=stem)


plot_figure_5 = plot_figure5

