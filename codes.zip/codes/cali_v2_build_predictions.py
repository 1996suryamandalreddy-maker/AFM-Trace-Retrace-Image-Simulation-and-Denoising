"""Build predictions for calibration grating v2 Nature-style figures.

Produces a cache `/tmp/cali_v2_predictions.npz` containing:
- DT trace/retrace for every condition using PI-only ridge predictions
- DT trace/retrace using local-oracle PI on fit conditions
- Pure-data-driven predictions of trace/retrace from controls + FD features
- Hybrid (DT + data-driven residual) predictions of trace/retrace
- Fit/test indices and underlying experimental data
"""
from __future__ import annotations

import sys, time, pickle
from pathlib import Path

import numpy as np
import pandas as pd
import importlib
from joblib import load


def main():
    sys.path.insert(0, '.')
    import codes.Scanner_fixed_extended_fd as sfe
    import codes.Scanner_numba_substeps_v3 as sn
    importlib.reload(sfe); importlib.reload(sn)
    sn.install_numba_substep_methods(sfe.ScannerFD, verbose=False)
    from codes.dt_static_dynamic_calibration_scaffold_v3 import (
        ScannerRunConfig, run_scanner_line, get_height_from_out,
    )
    from codes.dt_gp_static_calibration_v3 import diff_shifted
    from sklearn.linear_model import RidgeCV
    from sklearn.preprocessing import PolynomialFeatures, StandardScaler
    from sklearn.pipeline import make_pipeline
    from sklearn.impute import SimpleImputer

    b  = np.load('/tmp/cali_v2_basics.npz')
    p2 = np.load('/tmp/cali_v2_pipeline.npz')
    fd_drive_nm=b['fd_drive_nm']; fd_height=b['fd_height']; fd_amp=b['fd_amp']; fd_phase=b['fd_phase']
    traces_exp=b['traces_exp']; drive_exp=b['drive_exp']; setpoint_exp=b['setpoint_exp']
    igain_exp=b['igain_exp']; scan_rate_exp=b['scan_rate_exp']
    h_truth=p2['h_truth']; informative_mask=p2['informative_mask']
    N_COND = traces_exp.shape[0]

    measured_fd = {float(fd_drive_nm[i]): {'d': fd_height[i], 'A': fd_amp[i], 'phi': fd_phase[i]}
                   for i in range(len(fd_drive_nm))}
    surface = sfe.FDDriveSurface.from_measured_fd(
        measured_fd, x_mode='d_over_A0', common_range='union', n_x=1024,
        extend_to_zero_amplitude=True, extension_n_fit=5, extension_n_bridge=30,
        extension_phi_mode='linear', extension_F_mode='nearest',
    )
    params = {'k':25,'A':float(np.nanmedian(fd_amp)),'d0':float(np.nanmax(fd_height)*0.8),
              'R':10,'H':1e-19,'E_star':1e9,'Q':250}
    scanner = sfe.ScannerFD(params=params, conversions={k:1.0 for k in params},
                            fd_model=sfe.make_normalized_fd_lookup(surface, conv_L=1.0))
    scanner_cfg = ScannerRunConfig(
        dx_hat=1.0, n_substeps=50, tau_A=None, tau_phi=None, tau_z=None,
        z_rate_limit_hat=1e6, d_init_hat=0.0, A_meas_init_hat=1.0,
        phi_meas_init_deg=120.0, T_I=3e-1, h_smooth_sigma_px=0.0,
        fd_n_d=4096, use_fast=True,
    )
    FD_TABLE = {}
    def _fd_table_for(d):
        k = round(float(d), 4)
        if k not in FD_TABLE:
            FD_TABLE[k] = scanner.prepare_fd_table_for_drive(float(d), n_d=scanner_cfg.fd_n_d)
        return FD_TABLE[k]

    def run_dt(i, P, I, h_line=None):
        if h_line is None: h_line = h_truth
        fd_table = _fd_table_for(drive_exp[i])
        out = run_scanner_line(scanner, h_line, drive_nm=float(drive_exp[i]),
            setpoint=float(setpoint_exp[i]), scan_speed_hat=float(scan_rate_exp[i]),
            P=float(P), I=float(I), cfg=scanner_cfg, fd_table=fd_table)
        return get_height_from_out(out)

    # ----- Train/test split matching the v2 notebook -----
    RANDOM_SEED = 35
    n_fit_target, n_test_target = 40, 20
    info_idx = np.where(informative_mask)[0]
    rng = np.random.default_rng(RANDOM_SEED)
    shuffled = rng.permutation(info_idx)
    fit_idx  = np.sort(shuffled[:n_fit_target])
    test_idx = np.sort(shuffled[n_fit_target:n_fit_target+n_test_target])

    # ----- PI ridge model on labels from local fits -----
    local_fits = load('calibration_cache/calibration_grating_v2/local_PI_fits_balanced_v2iter.joblib')
    local_df = pd.DataFrame(local_fits)

    FEATURES = ['log_scan_speed', 'drive_nm', 'setpoint', 'log_I_exp']
    def cf(i):
        return {'log_scan_speed': float(np.log10(max(scan_rate_exp[int(i)], 1e-12))),
                'drive_nm': float(drive_exp[int(i)]),
                'setpoint': float(setpoint_exp[int(i)]),
                'log_I_exp': float(np.log10(max(igain_exp[int(i)], 1e-12)))}

    bound_lo_P, bound_hi_P = -2.5, 2.0
    bound_lo_I, bound_hi_I = -1.5, 3.0
    log10P = local_df['log10_P'].to_numpy(float); log10I = local_df['log10_I'].to_numpy(float)
    loss = local_df['loss'].to_numpy(float)
    hit_P = (np.abs(log10P-bound_lo_P)<0.05)|(np.abs(log10P-bound_hi_P)<0.05)
    hit_I = (np.abs(log10I-bound_lo_I)<0.05)|(np.abs(log10I-bound_hi_I)<0.05)
    loss_cap = np.nanpercentile(loss[np.isfinite(loss)],60)
    clean_mask = (np.isfinite(log10P) & np.isfinite(log10I) & np.isfinite(loss)
                  & ~(hit_P|hit_I) & (loss<loss_cap))
    train_records = []
    for keep, rec in zip(clean_mask, local_fits):
        if not keep: continue
        f = cf(rec['cond']); f.update({'log10_P': rec['log10_P'], 'log10_I': rec['log10_I']})
        train_records.append(f)
    train_df = pd.DataFrame(train_records)

    ridge_PI = make_pipeline(
        SimpleImputer(strategy='median'),
        PolynomialFeatures(degree=2, include_bias=False),
        StandardScaler(),
        RidgeCV(alphas=np.logspace(-3,3,25), cv=min(5,max(2,len(train_df)))),
    )
    ridge_PI.fit(train_df[FEATURES].to_numpy(float), train_df[['log10_P','log10_I']].to_numpy(float))

    def predict_PI(idxs):
        feats = np.array([[cf(i)[c] for c in FEATURES] for i in idxs], float)
        lp = ridge_PI.predict(feats)
        lp[:,0] = np.clip(lp[:,0], bound_lo_P, bound_hi_P)
        lp[:,1] = np.clip(lp[:,1], bound_lo_I, bound_hi_I)
        return 10.0**lp[:,0], 10.0**lp[:,1]

    all_idx = np.arange(N_COND)
    P_all, I_all = predict_PI(all_idx)

    # ----- DT runs (PI-only method) for all conditions -----
    print('Running DT with PI ridge for all conditions...')
    t0 = time.time()
    dt_PI = np.zeros_like(traces_exp)
    for i in all_idx:
        sim_tr, sim_rt = run_dt(int(i), P_all[i], I_all[i])
        n = min(len(sim_tr), traces_exp.shape[-1])
        dt_PI[i,0,:n] = sim_tr[:n]; dt_PI[i,1,:n] = sim_rt[:n]
    print(f'  done in {time.time()-t0:.1f}s')

    # ----- DT with local-oracle PI for fit conditions -----
    print('Running DT with oracle PI on fit conditions...')
    oracle_PI = {r['cond']: (r['P'], r['I']) for r in local_fits}
    dt_oracle = np.full_like(traces_exp, np.nan)
    for i in fit_idx:
        P,I = oracle_PI[int(i)]
        sim_tr, sim_rt = run_dt(int(i), P, I)
        n = min(len(sim_tr), traces_exp.shape[-1])
        dt_oracle[i,0,:n] = sim_tr[:n]; dt_oracle[i,1,:n] = sim_rt[:n]
    print('  done')

    # ----- Pure data-driven model: features -> trace/retrace (flattened to 2*256) -----
    # Build a richer feature vector including FD lookups at d=0 (A0) and the experimental I gain
    def features_for(i):
        d   = float(drive_exp[int(i)])
        sp  = float(setpoint_exp[int(i)])
        ig  = float(igain_exp[int(i)])
        A0  = float(scanner.get_A0_hat(d))
        log_ig = float(np.log10(max(ig, 1e-12)))
        return [d, sp, ig, log_ig, A0, np.log10(max(A0,1e-12)),
                d*sp, d*log_ig, sp*log_ig, A0*sp]

    feat_names = ['drive_nm','setpoint','I_exp','log_I_exp','A0',
                  'log_A0','drive_x_sp','drive_x_logI','sp_x_logI','A0_x_sp']

    X = np.array([features_for(i) for i in all_idx], float)
    Y_trace = traces_exp[:,0,:].copy()
    Y_retrace = traces_exp[:,1,:].copy()

    # Center each line (since DT predictions are zero-mean over interior, the
    # data-driven model also learns the *centered* shape).
    def center(arr, trim=10):
        arr = arr.copy()
        for i in range(arr.shape[0]):
            ln = arr[i, trim:-trim]
            mu = np.nanmean(ln)
            arr[i] = arr[i] - mu
        return arr
    Yt_c = center(Y_trace); Yr_c = center(Y_retrace)

    # Train direct ridge (multivariate output)
    from sklearn.linear_model import Ridge
    Xtr = X[fit_idx]; Yt_tr = Yt_c[fit_idx]; Yr_tr = Yr_c[fit_idx]
    poly = PolynomialFeatures(degree=2, include_bias=False)
    scaler = StandardScaler()
    Xtr_poly = scaler.fit_transform(poly.fit_transform(Xtr))
    Xall_poly = scaler.transform(poly.transform(X))
    ridge_trace = Ridge(alpha=10.0).fit(Xtr_poly, Yt_tr)
    ridge_retr  = Ridge(alpha=10.0).fit(Xtr_poly, Yr_tr)
    dd_PI = np.zeros_like(traces_exp)
    dd_PI[:,0,:] = ridge_trace.predict(Xall_poly)
    dd_PI[:,1,:] = ridge_retr.predict(Xall_poly)

    # ----- Hybrid: DT + residual data-driven correction -----
    # Residual = exp_centered - DT_centered, train on fit_idx, apply to all
    dt_PI_c = np.zeros_like(dt_PI)
    dt_PI_c[:,0,:] = center(dt_PI[:,0,:])
    dt_PI_c[:,1,:] = center(dt_PI[:,1,:])
    Rt = Yt_c - dt_PI_c[:,0,:]
    Rr = Yr_c - dt_PI_c[:,1,:]
    Rt_tr = Rt[fit_idx]; Rr_tr = Rr[fit_idx]
    ridge_res_t = Ridge(alpha=10.0).fit(Xtr_poly, Rt_tr)
    ridge_res_r = Ridge(alpha=10.0).fit(Xtr_poly, Rr_tr)
    hyb = np.zeros_like(traces_exp)
    hyb[:,0,:] = dt_PI_c[:,0,:] + ridge_res_t.predict(Xall_poly)
    hyb[:,1,:] = dt_PI_c[:,1,:] + ridge_res_r.predict(Xall_poly)

    # ----- Scan quality (trace-retrace RMSE) -----
    def trace_retrace_rmse(tr, rt, trim=10):
        n = min(len(tr), len(rt))
        if n <= 2*trim + 4: return np.nan
        t = tr[trim:n-trim] - np.nanmean(tr[trim:n-trim])
        r = rt[trim:n-trim] - np.nanmean(rt[trim:n-trim])
        m = np.isfinite(t) & np.isfinite(r)
        if m.sum() < 5: return np.nan
        return float(np.sqrt(np.nanmean((t[m]-r[m])**2)))

    def quality_of(arr):
        return np.array([trace_retrace_rmse(arr[i,0], arr[i,1]) for i in range(arr.shape[0])])

    q_exp = quality_of(traces_exp)
    q_PI  = quality_of(dt_PI)
    q_dd  = quality_of(dd_PI)
    q_hyb = quality_of(hyb)

    # Per-line trace+retrace RMSE between method and experiment (centered)
    def line_rmse(pred, exp, trim=10):
        s,e = pred, exp
        # use diff_shifted to align before RMSE
        sa, ea = diff_shifted(s, e)
        n = min(len(sa), len(ea))
        if n <= 2*trim+4: lo,hi=0,n
        else: lo,hi = trim, n-trim
        sc = sa[lo:hi] - np.nanmean(sa[lo:hi]); ec = ea[lo:hi] - np.nanmean(ea[lo:hi])
        m = np.isfinite(sc) & np.isfinite(ec)
        if m.sum() < 5: return np.nan
        return float(np.sqrt(np.nanmean((sc[m]-ec[m])**2)))

    def model_rmse(arr):
        out = np.zeros((arr.shape[0], 2))
        for i in range(arr.shape[0]):
            out[i,0] = line_rmse(arr[i,0], traces_exp[i,0])
            out[i,1] = line_rmse(arr[i,1], traces_exp[i,1])
        return out

    rmse_PI = model_rmse(dt_PI)
    rmse_dd = model_rmse(dd_PI)
    rmse_hyb = model_rmse(hyb)

    # ----- Save -----
    np.savez('/tmp/cali_v2_predictions.npz',
        fit_idx=fit_idx, test_idx=test_idx,
        h_truth=h_truth,
        traces_exp=traces_exp,
        dt_PI=dt_PI, dt_oracle=dt_oracle,
        dd=dd_PI, hyb=hyb,
        P_all=P_all, I_all=I_all,
        q_exp=q_exp, q_PI=q_PI, q_dd=q_dd, q_hyb=q_hyb,
        rmse_PI=rmse_PI, rmse_dd=rmse_dd, rmse_hyb=rmse_hyb,
        drive_exp=drive_exp, setpoint_exp=setpoint_exp, igain_exp=igain_exp,
    )
    print('Saved /tmp/cali_v2_predictions.npz')
    print('held-out median PI line rmse :', np.nanmedian(np.nanmean(rmse_PI[test_idx], axis=1)))
    print('held-out median DD line rmse :', np.nanmedian(np.nanmean(rmse_dd[test_idx], axis=1)))
    print('held-out median HYB line rmse:', np.nanmedian(np.nanmean(rmse_hyb[test_idx], axis=1)))
    print('held-out quality MAE PI :', float(np.nanmean(np.abs(q_exp[test_idx]-q_PI[test_idx]))))
    print('held-out quality MAE DD :', float(np.nanmean(np.abs(q_exp[test_idx]-q_dd[test_idx]))))
    print('held-out quality MAE HYB:', float(np.nanmean(np.abs(q_exp[test_idx]-q_hyb[test_idx]))))


if __name__ == '__main__':
    main()
