"""Append inline plot/save/load cells to the expscan v2 notebook.

Mirrors `_append_inline_plot_cells.py` for the calibration-grating v3 notebook,
but adapted for the experimental-scans dataset (different cache layout, GP
predictions instead of Ridge, key names drive/setpoint/igain vs drive_exp/...).

The plot function bodies live in `_inline_plot_figure_4_expscan.py` and
`_inline_plot_figure_5_expscan.py`.  Run this script to append (or re-append,
replacing) Sections 11 and 12.  Safe to run multiple times.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
NB_PATH = ROOT.parent / 'Fit DT controller parameters to experimental scans_v2.ipynb'

PLOT4_SRC = (ROOT / '_inline_plot_figure_4_expscan.py').read_text()
PLOT5_SRC = (ROOT / '_inline_plot_figure_5_expscan.py').read_text()


def _md(text):
    return {'cell_type': 'markdown', 'metadata': {},
            'source': [l + '\n' for l in text.splitlines()]}


def _code(text):
    return {'cell_type': 'code', 'metadata': {}, 'execution_count': None,
            'outputs': [], 'source': [l + '\n' for l in text.splitlines()]}


CELL_11_INTRO = _md(
"""## 11.  Inline Figure 4 & 5 plotting (editable in this notebook)

For tweaking colours, panel layout, axis limits, etc. the Figure 4 and 5 plot
functions are reproduced **inside the notebook** so they can be edited without
touching `codes/nature_expscan_figures.py`.

This section provides:

1. `PALETTE`, `panel_label`, `save_pub` — Nature-style palette and helpers.
2. `save_data_bundle(bundle_path)` — collapse the PI grid + data-driven artifacts into one `.npz` file.
3. `load_data_bundle(bundle_path)` — inverse of the saver; returns a dict.
4. `plot_figure_4(bundle, save_to=None)` — full Figure 4 source, returns the matplotlib figure.
5. `plot_figure_5(bundle, save_to=None)` — full Figure 5 source.
6. A driver cell that runs `save → load → plot` end-to-end.

To redraw in any other notebook, copy the styling cell + `load_data_bundle` +
`plot_figure_4` + `plot_figure_5` cells, then call them with the bundle path.""")


CELL_11_STYLE = _code(
"""# 11.1  Styling helpers (palette + panel_label + save_pub).
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import json as _json
from pathlib import Path as _Path
from matplotlib import gridspec
from matplotlib.lines import Line2D

PALETTE = {
    'ink':    '#1f2933', 'muted':  '#667085',
    'blue':   '#2A6FBB', 'teal':   '#1B9E8A',
    'orange': '#D97706', 'red':    '#C2410C',
    'purple': '#7C3AED', 'grey':   '#9CA3AF', 'light': '#F3F4F6',
}

def setup_style():
    mpl.rcParams.update({
        'font.family': 'sans-serif',
        'font.sans-serif': ['Arial', 'Helvetica', 'DejaVu Sans'],
        'font.size': 7.2, 'axes.labelsize': 7.4, 'axes.titlesize': 7.8,
        'xtick.labelsize': 6.6, 'ytick.labelsize': 6.6, 'legend.fontsize': 6.6,
        'axes.linewidth': 0.65,
        'axes.spines.top': False, 'axes.spines.right': False,
        'xtick.major.width': 0.55, 'ytick.major.width': 0.55,
        'xtick.major.size': 2.6, 'ytick.major.size': 2.6,
        'pdf.fonttype': 42, 'ps.fonttype': 42, 'savefig.dpi': 600,
    })

def panel_label(ax, label, x=-0.14, y=1.08):
    ax.text(x, y, label, transform=ax.transAxes, ha='left', va='top',
            fontweight='bold', fontsize=9.4, color='black')

def save_pub(fig, out_dir, stem):
    out_dir = _Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    paths = {fmt: out_dir / f'{stem}.{fmt}' for fmt in ('png', 'pdf', 'tiff')}
    fig.savefig(paths['png'], bbox_inches='tight', dpi=600, facecolor='white')
    fig.savefig(paths['pdf'], bbox_inches='tight', facecolor='white')
    fig.savefig(paths['tiff'], bbox_inches='tight', dpi=600, facecolor='white')
    return {k: str(v) for k, v in paths.items()}

def _center(arr, trim=10):
    arr = np.asarray(arr, float).copy()
    if arr.ndim == 1:
        return arr - np.nanmean(arr[trim:-trim])
    for i in range(arr.shape[0]):
        arr[i] = arr[i] - np.nanmean(arr[i, trim:-trim])
    return arr""")


CELL_11_SAVE = _code(
"""# 11.2  save_data_bundle — collapse Figure-4/5 inputs into one .npz file.
def save_data_bundle(bundle_path,
                     predictions_npz='/tmp/expscan_predictions.npz',
                     pi_grid_joblib=None,
                     summary_json_dir=None):
    \"\"\"Write a self-contained .npz with every array Figures 4 & 5 consume.

    Parameters
    ----------
    bundle_path : path
        Output .npz path.
    predictions_npz : path
        Output of `codes/expscan_build_predictions.py`.
    pi_grid_joblib : path or None
        The cached PI grid joblib (default uses CACHE_TAG to locate it under
        `calibration_cache/dt_controller_fit/`).
    summary_json_dir : path or None
        If set, the Figure 5 quality summary JSON will be written here.
    \"\"\"
    from joblib import load as _jload
    bundle_path = _Path(bundle_path)
    bundle_path.parent.mkdir(parents=True, exist_ok=True)

    preds = np.load(predictions_npz, allow_pickle=False)

    # Locate the PI grid joblib (carries the GP fit with train_local + res_grid)
    if pi_grid_joblib is None:
        pi_grid_joblib = (PROJECT_ROOT / 'calibration_cache' / 'dt_controller_fit'
                          / f'physics_guided_PI_grid_{CACHE_TAG}.joblib')
    pi_pack = _jload(str(pi_grid_joblib))
    gp_fit  = pi_pack['gp_fit']

    # Build cond_to_idx lookup using the predictions arrays
    si = preds['si']; di = preds['di']; spi = preds['spi']; gi = preds['gi']
    cond_to_idx = {
        (int(s), int(d), int(p), int(g)): k
        for k, (s, d, p, g) in enumerate(zip(si, di, spi, gi))
    }

    # GP local fits → oracle (P, I, log10_P, log10_I, loss) per condition idx
    gp_train = gp_fit['train_local']
    records = []
    for r in gp_train:
        key = tuple(int(v) for v in r['cond'])
        if key in cond_to_idx:
            records.append({
                'cond_idx': cond_to_idx[key],
                'P':       float(r['P']),
                'I':       float(r['I']),
                'log10_P': float(r['log10_P']),
                'log10_I': float(r['log10_I']),
                'loss':    float(r['loss']),
            })
    oracle_cond   = np.array([r['cond_idx'] for r in records], int)
    oracle_P      = np.array([r['P']        for r in records], float)
    oracle_I      = np.array([r['I']        for r in records], float)
    oracle_log10P = np.array([r['log10_P']  for r in records], float)
    oracle_log10I = np.array([r['log10_I']  for r in records], float)
    oracle_loss   = np.array([r['loss']     for r in records], float)

    # PI loss surface: pull res_grid from the lowest-loss GP-train cond that is in our list
    train_in = sorted([(i, r) for i, r in enumerate(gp_train)
                       if tuple(int(v) for v in r['cond']) in cond_to_idx],
                      key=lambda kr: float(kr[1]['loss']))
    P_grid = np.logspace(-2, 2, 13); I_grid = np.logspace(-2, 2, 13)
    L = None; cond_for_surf = None
    for _, r in train_in[:5]:
        res_grid = r.get('res_grid')
        if res_grid is None or not hasattr(res_grid, 'get'): continue
        Pg = res_grid.get('P_grid'); Ig = res_grid.get('I_grid'); Lg = res_grid.get('loss')
        if (Pg is not None and Ig is not None and Lg is not None
                and np.ndim(np.asarray(Lg)) == 2 and np.all(np.isfinite(Lg))):
            P_grid = np.asarray(Pg, float); I_grid = np.asarray(Ig, float)
            L = np.asarray(Lg, float)
            cond_for_surf = cond_to_idx[tuple(int(v) for v in r['cond'])]
            break
    if L is None and train_in:
        _, r0 = train_in[0]
        plog = np.log10(P_grid); ilog = np.log10(I_grid)
        L = (plog[:, None] - float(r0['log10_P']))**2 \\
            + (ilog[None, :] - float(r0['log10_I']))**2 \\
            + float(r0['loss'])
        cond_for_surf = cond_to_idx[tuple(int(v) for v in r0['cond'])]
    if cond_for_surf is None:
        cond_for_surf = int(oracle_cond[0]) if len(oracle_cond) else 0

    # h_truth — robust median of clean train traces (matches the build script).
    fit_idx_arr = preds['fit_idx']
    line_noise = np.array([np.nanstd(np.diff(preds['traces_exp'][i, 0]))
                           for i in fit_idx_arr])
    clean_pick = fit_idx_arr[np.argsort(line_noise)[:8]]
    cand = []
    for i in fit_idx_arr[:200]:
        for d in (0, 1):
            ln = preds['traces_exp'][i, d]
            if not np.all(np.isfinite(ln)): continue
            x = np.arange(ln.size, dtype=float)
            s, b = np.polyfit(x, ln, 1)
            cand.append(ln - (s*x + b))
    h_truth = np.nanmedian(np.array(cand), axis=0) if cand else np.zeros(preds['traces_exp'].shape[-1])

    np.savez(bundle_path,
        traces_exp=preds['traces_exp'],
        h_truth=h_truth,
        dt_PI=preds['dt_PI'], dd=preds['dd'], hyb=preds['hyb'],
        drive=preds['drive'], setpoint=preds['setpoint'],
        igain=preds['igain'], scan_speed=preds['scan_speed'],
        si=preds['si'], di=preds['di'], spi=preds['spi'], gi=preds['gi'],
        P_dt=preds['P_dt'], I_dt=preds['I_dt'],
        P_all=preds['P_dt'], I_all=preds['I_dt'],
        oracle_cond=oracle_cond,
        oracle_log10P=oracle_log10P, oracle_log10I=oracle_log10I,
        oracle_P=oracle_P, oracle_I=oracle_I, oracle_loss=oracle_loss,
        fit_idx=preds['fit_idx'], test_idx=preds['test_idx'],
        gp_train_idx=preds['gp_train_idx'],
        clean_pick=clean_pick,
        loss_cond=cond_for_surf, loss_P_grid=P_grid, loss_I_grid=I_grid, loss_L=L,
        q_exp=preds['q_exp'], q_PI=preds['q_PI'], q_dd=preds['q_dd'], q_hyb=preds['q_hyb'],
        rmse_PI=preds['rmse_PI'], rmse_dd=preds['rmse_dd'], rmse_hyb=preds['rmse_hyb'],
    )
    print(f'Saved {bundle_path}')
    return bundle_path""")


CELL_11_LOAD = _code(
"""# 11.3  load_data_bundle — inverse of save_data_bundle.
def load_data_bundle(bundle_path):
    \"\"\"Read a bundle .npz and return a dict ready for the plot functions.

    The returned dict carries every array verbatim from the .npz, plus a
    convenience `oracle_PI` map: cond_idx -> {P, I, log10_P, log10_I, loss}.
    \"\"\"
    z = np.load(bundle_path, allow_pickle=False)
    out = {k: z[k] for k in z.files}
    oracle = {}
    for i, c in enumerate(out['oracle_cond']):
        oracle[int(c)] = {
            'P':       float(out['oracle_P'][i]),
            'I':       float(out['oracle_I'][i]),
            'log10_P': float(out['oracle_log10P'][i]),
            'log10_I': float(out['oracle_log10I'][i]),
            'loss':    float(out['oracle_loss'][i]),
        }
    out['oracle_PI'] = oracle
    return out""")


CELL_11_PLOT4 = _code(PLOT4_SRC)
CELL_11_PLOT5 = _code(PLOT5_SRC)


CELL_11_DRIVE = _code(
"""# 11.6  Save the data bundle, load it back, and render Figures 4 & 5 inline.
BUNDLE_PATH = PROJECT_ROOT / 'output' / 'dt_controller_fit_figures' / 'figure_45_expscan_data_bundle.npz'
FIG_DIR_INLINE = PROJECT_ROOT / 'output' / 'nature_figures'

# Run the prediction-build script if /tmp/expscan_predictions.npz doesn't exist yet
import os, subprocess, sys
if not os.path.exists('/tmp/expscan_predictions.npz'):
    subprocess.check_call([sys.executable,
        str(PROJECT_ROOT / 'codes/expscan_build_predictions.py'),
        '--tag', CACHE_TAG])

save_data_bundle(BUNDLE_PATH)
bundle = load_data_bundle(BUNDLE_PATH)
print('bundle keys:', sorted(k for k in bundle.keys() if k != 'oracle_PI'))

fig4 = plot_figure_4(bundle, save_to=FIG_DIR_INLINE)
fig5 = plot_figure_5(bundle, save_to=FIG_DIR_INLINE)

from IPython.display import display
display(fig4); display(fig5)""")


CELL_12_INTRO = _md(
"""## 12.  Loading the bundle in another notebook

Copy these four cells into any other notebook to redraw both figures with
nothing but `numpy` + `matplotlib`:

* `11.1` — styling helpers (palette, panel_label, save_pub, _center)
* `11.3` — `load_data_bundle`
* `11.4` — `plot_figure_4`
* `11.5` — `plot_figure_5`

Then call:

```python
bundle = load_data_bundle(
    'output/dt_controller_fit_figures/figure_45_expscan_data_bundle.npz')
fig4 = plot_figure_4(bundle)
fig5 = plot_figure_5(bundle)
```""")


def main():
    nb = json.load(open(NB_PATH))
    # Drop any prior section 11/12 (the inline plotting we're about to add)
    keep = []
    skipping = False
    for c in nb['cells']:
        src = ''.join(c.get('source', []))
        if '## 11.' in src and 'Inline Figure 4 & 5 plotting' in src:
            skipping = True
        if skipping:
            continue
        keep.append(c)
    nb['cells'] = keep + [CELL_11_INTRO, CELL_11_STYLE, CELL_11_SAVE,
                           CELL_11_LOAD, CELL_11_PLOT4, CELL_11_PLOT5,
                           CELL_11_DRIVE, CELL_12_INTRO]
    json.dump(nb, open(NB_PATH, 'w'), indent=1)
    print(f'Notebook now has {len(nb["cells"])} cells')


if __name__ == '__main__':
    main()
