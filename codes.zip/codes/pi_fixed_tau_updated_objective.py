"""
pi_fixed_tau_updated_objective.py
=================================

Updated versions of:

1. make_scan_objective_exp_PI_fixed_tau
2. fit_controller_to_experiment_PI_fixed_tau

Main fixes relative to the pasted functions:
- Fixes the gradient/noise objective length mismatch:
      np.diff(...) has length N-1, so its denominator must also have length N-1.
- Avoids overwriting weight arguments such as w_height_match with local metric values.
- Adds robust denominator floors to avoid division by zero or instability when
  simulated/experimental height values cross zero.
- Keeps the fixed-tau behavior:
      tau_A_fixed=None   -> A filter disabled
      tau_phi_fixed=None -> phase filter disabled
      tau_z_fixed=None   -> z actuator filter disabled
- Supports the fast scanner path if available, and falls back to
  scan_line_trace_retrace_pi_drive otherwise.
- Adds explicit weights for the updated objective:
      w_trrt_match
      w_gradient_match
      w_gradient_noise
- Keeps older weight names in the signature for compatibility.

Paste this into your scanner/helper file after the needed imports, or import it
as a separate module.
"""

from __future__ import annotations

from typing import Optional, Dict, Any, Tuple
import numpy as np
from scipy.optimize import differential_evolution, minimize


# =============================================================================
# Compatibility helpers
# =============================================================================

def _is_enabled_tau(tau) -> bool:
    """Return True if a time constant should enable the corresponding filter."""
    if tau is None:
        return False
    try:
        return bool(np.isfinite(float(tau)) and float(tau) > 0.0)
    except Exception:
        return False


def unpack_controller_params_PI_fixed_tau(
    x,
    *,
    tau_A_fixed=None,
    tau_phi_fixed=None,
    tau_z_fixed=None,
) -> Dict[str, float]:
    """
    Optimized vector:
        x = [log10_P, log10_I]
    """
    x = np.asarray(x, dtype=float).ravel()
    if x.size != 2:
        raise ValueError(f"x must have length 2: [log10_P, log10_I], got {x.size}")

    log10_P, log10_I = x

    return {
        "P": float(10.0 ** log10_P),
        "I": float(10.0 ** log10_I),
        "tau_A": tau_A_fixed,
        "tau_phi": tau_phi_fixed,
        "tau_z": tau_z_fixed,
    }


def parse_h_exp(h_exp) -> Tuple[np.ndarray, np.ndarray]:
    """
    Parse experimental trace/retrace height pair.

    Accepts:
        - dict with keys 'trace'/'retrace'
        - dict with keys 'h_tr'/'h_rt'
        - tuple/list (trace, retrace)
        - array with shape (2, N)
    """
    if isinstance(h_exp, dict):
        if "trace" in h_exp and "retrace" in h_exp:
            return (
                np.asarray(h_exp["trace"], dtype=float).ravel(),
                np.asarray(h_exp["retrace"], dtype=float).ravel(),
            )
        if "h_tr" in h_exp and "h_rt" in h_exp:
            return (
                np.asarray(h_exp["h_tr"], dtype=float).ravel(),
                np.asarray(h_exp["h_rt"], dtype=float).ravel(),
            )

    if isinstance(h_exp, (tuple, list)) and len(h_exp) == 2:
        return (
            np.asarray(h_exp[0], dtype=float).ravel(),
            np.asarray(h_exp[1], dtype=float).ravel(),
        )

    arr = np.asarray(h_exp, dtype=float)
    if arr.ndim == 2 and arr.shape[0] == 2:
        return arr[0].ravel(), arr[1].ravel()

    raise ValueError(
        "Cannot parse h_exp. Expected dict with trace/retrace or h_tr/h_rt, "
        "tuple(trace, retrace), or array with shape (2, N)."
    )


def crop_to_common_length(*arrays):
    """Crop all 1D arrays to the shortest common length."""
    arrays = [np.asarray(a, dtype=float).ravel() for a in arrays]
    n = min(len(a) for a in arrays)
    return tuple(a[:n] for a in arrays)


def _trim_arrays(*arrays, trim: int = 0):
    """
    Trim edge pixels from all arrays.

    If the requested trim is too large, no trimming is applied.
    """
    arrays = [np.asarray(a, dtype=float).ravel() for a in arrays]
    if not arrays:
        return tuple(arrays)

    n = min(len(a) for a in arrays)
    arrays = [a[:n] for a in arrays]

    trim = int(trim)
    if trim <= 0 or n <= 2 * trim + 4:
        return tuple(arrays)

    return tuple(a[trim:-trim] for a in arrays)


def robust_mad(x, eps: float = 1e-12) -> float:
    """Robust scale estimate."""
    x = np.asarray(x, dtype=float).ravel()
    x = x[np.isfinite(x)]
    if x.size == 0:
        return eps
    med = np.nanmedian(x)
    return float(1.4826 * np.nanmedian(np.abs(x - med)) + eps)


def _safe_denom_from_pair(a, b, *, denom_floor_frac: float = 1e-6) -> np.ndarray:
    """
    Safe positive denominator for relative trace/retrace metrics.

    Uses |a| + |b| with a robust floor.
    """
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)

    denom = np.abs(a) + np.abs(b)

    scale = np.nanmedian(np.abs(np.r_[a, b]))
    if not np.isfinite(scale) or scale <= 0:
        scale = robust_mad(np.r_[a, b])
    floor = float(denom_floor_frac) * max(float(scale), 1e-12)

    return np.maximum(denom, floor)


def _relative_trace_retrace_mismatch(
    tr,
    rt,
    *,
    denom_floor_frac: float = 1e-6,
) -> float:
    """
    Mean relative trace/retrace mismatch:

        mean(|tr - rt| / (|tr| + |rt| + floor))
    """
    tr = np.asarray(tr, dtype=float).ravel()
    rt = np.asarray(rt, dtype=float).ravel()
    tr, rt = crop_to_common_length(tr, rt)

    mask = np.isfinite(tr) & np.isfinite(rt)
    if np.sum(mask) < 3:
        return np.inf

    tr = tr[mask]
    rt = rt[mask]

    denom = _safe_denom_from_pair(
        tr,
        rt,
        denom_floor_frac=denom_floor_frac,
    )

    return float(np.nanmean(np.abs(tr - rt) / denom))


def _relative_gradient_stats(
    tr,
    rt,
    *,
    denom_floor_frac: float = 1e-6,
) -> Tuple[float, float]:
    """
    Relative gradient strength and gradient-noise statistics.

    Important fix:
        diff(tr) and diff(rt) have length N-1.
        Therefore the denominator must also be length N-1.

    We use a midpoint denominator:

        denom[i] = 0.5 * (
            |tr[i]| + |tr[i+1]| + |rt[i]| + |rt[i+1]|
        )

    Then:

        g[i] = (|diff(tr)[i]| + |diff(rt)[i]|) / denom[i]

    Returns
    -------
    mean_g, std_g
    """
    tr = np.asarray(tr, dtype=float).ravel()
    rt = np.asarray(rt, dtype=float).ravel()
    tr, rt = crop_to_common_length(tr, rt)

    mask = np.isfinite(tr) & np.isfinite(rt)
    if np.sum(mask) < 4:
        return np.inf, np.inf

    tr = tr[mask]
    rt = rt[mask]

    dtr = np.diff(tr)
    drt = np.diff(rt)

    # N-1 denominator to match diff length.
    denom = 0.5 * (
        np.abs(tr[:-1])
        + np.abs(tr[1:])
        + np.abs(rt[:-1])
        + np.abs(rt[1:])
    )

    scale = np.nanmedian(np.abs(np.r_[tr, rt]))
    if not np.isfinite(scale) or scale <= 0:
        scale = robust_mad(np.r_[tr, rt])

    floor = float(denom_floor_frac) * max(float(scale), 1e-12)
    denom = np.maximum(denom, floor)

    g = (np.abs(dtr) + np.abs(drt)) / denom
    g = g[np.isfinite(g)]

    if g.size < 3:
        return np.inf, np.inf

    return float(np.nanmean(g)), float(np.nanstd(g))


def compute_updated_relative_scan_loss(
    sim_tr,
    sim_rt,
    exp_tr,
    exp_rt,
    *,
    trim: int = 20,
    w_trrt_match: float = 2.0,
    w_gradient_match: float = 2.0,
    w_gradient_noise: float = 1.0,
    denom_floor_frac: float = 1e-6,
) -> Tuple[float, Dict[str, float]]:
    """
    Updated objective based on relative trace/retrace mismatch, gradient strength,
    and gradient-noise statistics.

    This is the corrected version of:

        w_height_match_sim = mean(abs((sim_tr - sim_rt)/(sim_tr + sim_rt)))
        w_gradient_sim = mean((abs(diff(sim_tr)) + abs(diff(sim_rt))) /
                              (sim_tr + sim_rt))
        w_noise_sim = std((abs(diff(sim_tr)) + abs(diff(sim_rt))) /
                          (sim_tr + sim_rt))

    The corrected gradient terms use N-1 denominators.
    """
    sim_tr, sim_rt, exp_tr, exp_rt = crop_to_common_length(
        sim_tr,
        sim_rt,
        exp_tr,
        exp_rt,
    )

    sim_tr, sim_rt, exp_tr, exp_rt = _trim_arrays(
        sim_tr,
        sim_rt,
        exp_tr,
        exp_rt,
        trim=trim,
    )

    trrt_sim = _relative_trace_retrace_mismatch(
        sim_tr,
        sim_rt,
        denom_floor_frac=denom_floor_frac,
    )
    trrt_exp = _relative_trace_retrace_mismatch(
        exp_tr,
        exp_rt,
        denom_floor_frac=denom_floor_frac,
    )

    grad_mean_sim, grad_std_sim = _relative_gradient_stats(
        sim_tr,
        sim_rt,
        denom_floor_frac=denom_floor_frac,
    )
    grad_mean_exp, grad_std_exp = _relative_gradient_stats(
        exp_tr,
        exp_rt,
        denom_floor_frac=denom_floor_frac,
    )

    L_trrt = abs(trrt_sim - trrt_exp)
    L_gradient = abs(grad_mean_sim - grad_mean_exp)
    L_noise = abs(grad_std_sim - grad_std_exp)

    loss = (
        float(w_trrt_match) * L_trrt
        + float(w_gradient_match) * L_gradient
        + float(w_gradient_noise) * L_noise
    )

    details = {
        "L_trrt": float(L_trrt),
        "L_gradient": float(L_gradient),
        "L_noise": float(L_noise),

        "trrt_sim": float(trrt_sim),
        "trrt_exp": float(trrt_exp),

        "gradient_mean_sim": float(grad_mean_sim),
        "gradient_mean_exp": float(grad_mean_exp),

        "gradient_std_sim": float(grad_std_sim),
        "gradient_std_exp": float(grad_std_exp),

        "w_trrt_match": float(w_trrt_match),
        "w_gradient_match": float(w_gradient_match),
        "w_gradient_noise": float(w_gradient_noise),

        "trim": int(trim),
        "denom_floor_frac": float(denom_floor_frac),
    }

    if not np.isfinite(loss):
        loss = np.inf

    return float(loss), details


# =============================================================================
# Updated objective factory
# =============================================================================

def make_scan_objective_exp_PI_fixed_tau(
    scanner,
    h_input,
    h_exp,

    drive=20,
    setpoint=0.6,
    scan_speed_hat=1e3,
    dx_hat=1.0,

    # Fixed time constants. Default None means disabled.
    tau_A_fixed=None,
    tau_phi_fixed=None,
    tau_z_fixed=None,

    # Fixed scanner parameters
    z_rate_limit_hat=1e6,
    d_init_hat=250,
    phi_meas_init_deg=120,
    T_I=3e-1,
    integ_clip=None,

    # Substep controls
    n_substeps=50,
    dt_inner_max=None,
    antiwindup=True,
    contact_A_frac=0.02,
    saturation_A_frac=0.98,
    record_mode="last",
    carry_state_to_retrace=True,

    # Optional precomputed FD table
    fd_table=None,
    fd_n_d=4096,

    # Optional effective tip/edge smoothing
    h_smooth_sigma_px=0.0,

    # Loss parameters.
    # Existing names are kept for backward compatibility.
    trim=20,
    w_height_match=1.0,
    w_mse_match=0.5,
    w_diff_profile=0.1,
    w_ringing=0.05,
    w_amp=0.02,
    w_saturation=2.0,
    huber_delta=2.0,
    mse_floor_frac=0.03,
    hp_window=9,

    # New explicit weights for the updated objective.
    # If these are None, defaults are chosen to match your pasted objective:
    #     2 * trace/retrace mismatch + 2 * gradient mismatch + 1 * noise mismatch
    w_trrt_match=None,
    w_gradient_match=2.0,
    w_gradient_noise=1.0,
    denom_floor_frac=1e-6,

    verbose=False,
):
    """
    Objective for fitting only P and I while keeping time constants fixed.

    Optimized vector:
        x = [log10_P, log10_I]

    Fixed/optional time constants:
        tau_A_fixed=None   -> amplitude filter disabled
        tau_phi_fixed=None -> phase filter disabled
        tau_z_fixed=None   -> z actuator filter disabled
        T_I=None           -> pure integrator
        T_I>0              -> leaky integrator

    The updated loss compares statistical scan signatures instead of pixelwise
    ground-truth height:

        L = w_trrt_match      * |TRRT_sim - TRRT_exp|
          + w_gradient_match  * |Gmean_sim - Gmean_exp|
          + w_gradient_noise  * |Gstd_sim  - Gstd_exp|

    where gradient terms are correctly computed on N-1 arrays.
    """

    h_input = np.asarray(h_input, dtype=float).ravel()
    exp_tr, exp_rt = parse_h_exp(h_exp)

    use_A_filter = _is_enabled_tau(tau_A_fixed)
    use_phi_filter = _is_enabled_tau(tau_phi_fixed)
    use_z_filter = _is_enabled_tau(tau_z_fixed)

    A_filter_order = 1 if use_A_filter else None
    phi_filter_order = 1 if use_phi_filter else None
    z_filter_order = 1 if use_z_filter else None

    # Preserve your previous default behavior:
    # pasted code effectively used 2 * height mismatch.
    if w_trrt_match is None:
        w_trrt_match = 2.0

    if fd_table is None and hasattr(scanner, "prepare_fd_table_for_drive"):
        fd_table = scanner.prepare_fd_table_for_drive(
            drive_nm=drive,
            n_d=fd_n_d,
        )

    def _run_scanner(p):
        """Run fast scanner if available; otherwise fallback to older method."""
        if hasattr(scanner, "simulate_trace_retrace_substeps_fast"):
            return scanner.simulate_trace_retrace_substeps_fast(
                h_input,
                drive_nm=drive,
                setpoint=setpoint,

                scan_speed_hat=scan_speed_hat,
                dx_hat=dx_hat,

                P=p["P"],
                I=p["I"],

                A_filter_order=A_filter_order,
                tau_A=tau_A_fixed,

                phi_filter_order=phi_filter_order,
                tau_phi=tau_phi_fixed,

                z_filter_order=z_filter_order,
                tau_z=tau_z_fixed,
                z_rate_limit_hat=z_rate_limit_hat,

                d_init_hat=d_init_hat,
                phi_meas_init_deg=phi_meas_init_deg,
                T_I=T_I,
                integ_clip=integ_clip,

                n_substeps=n_substeps,
                dt_inner_max=dt_inner_max,

                antiwindup=antiwindup,
                contact_A_frac=contact_A_frac,
                saturation_A_frac=saturation_A_frac,

                record_mode=record_mode,
                carry_state_to_retrace=carry_state_to_retrace,

                fd_table=fd_table,
                fd_n_d=fd_n_d,
                h_smooth_sigma_px=h_smooth_sigma_px,
            )

        # Fallback to older non-numba scanner method.
        return scanner.scan_line_trace_retrace_pi_drive(
            h_hat=h_input,
            drive_nm=drive,
            setpoint=setpoint,

            scan_speed_hat=scan_speed_hat,
            dx_hat=dx_hat,

            P=p["P"],
            I=p["I"],

            A_filter_order=A_filter_order,
            tau_A=tau_A_fixed,

            phi_filter_order=phi_filter_order,
            tau_phi=tau_phi_fixed,

            z_filter_order=z_filter_order,
            tau_z=tau_z_fixed,
            z_rate_limit_hat=z_rate_limit_hat,

            d_init_hat=d_init_hat,
            phi_meas_init_deg=phi_meas_init_deg,
            T_I=T_I,
            integ_clip=integ_clip,

            use_substeps=True,
            n_substeps=n_substeps,
            dt_inner_max=dt_inner_max,
        )

    def objective(x, return_full=False):
        p = unpack_controller_params_PI_fixed_tau(
            x,
            tau_A_fixed=tau_A_fixed,
            tau_phi_fixed=tau_phi_fixed,
            tau_z_fixed=tau_z_fixed,
        )

        try:
            out = _run_scanner(p)

            sim_tr = np.asarray(out["trace"]["d_hat"], dtype=float).ravel()
            sim_rt = np.asarray(out["retrace"]["d_hat"], dtype=float).ravel()

            loss, details = compute_updated_relative_scan_loss(
                sim_tr,
                sim_rt,
                exp_tr,
                exp_rt,
                trim=trim,
                w_trrt_match=w_trrt_match,
                w_gradient_match=w_gradient_match,
                w_gradient_noise=w_gradient_noise,
                denom_floor_frac=denom_floor_frac,
            )

            details.update(
                {
                    "P": float(p["P"]),
                    "I": float(p["I"]),
                    "tau_A": tau_A_fixed,
                    "tau_phi": tau_phi_fixed,
                    "tau_z": tau_z_fixed,
                    "A_filter_enabled": bool(use_A_filter),
                    "phi_filter_enabled": bool(use_phi_filter),
                    "z_filter_enabled": bool(use_z_filter),
                    "n_substeps": int(n_substeps),
                    "dt_inner_max": None if dt_inner_max is None else float(dt_inner_max),
                    "h_smooth_sigma_px": float(h_smooth_sigma_px),
                }
            )

            if return_full:
                return float(loss), details, out, p

            return float(loss)

        except Exception as e:
            if verbose:
                print("Objective failed:", repr(e))

            if return_full:
                return np.inf, {"error": str(e), "P": p["P"], "I": p["I"]}, None, p

            return np.inf

    return objective


# =============================================================================
# Updated fitter
# =============================================================================

def fit_controller_to_experiment_PI_fixed_tau(
    scanner,
    h_input,
    h_exp,

    drive=20,
    setpoint=0.6,
    scan_speed_hat=1e3,
    dx_hat=1.0,

    # Fixed time constants.
    # Default None means disabled.
    tau_A_fixed=None,
    tau_phi_fixed=None,
    tau_z_fixed=None,

    # Backward-compatible alias. If tau_z is provided, it overrides tau_z_fixed.
    tau_z=None,

    # Fixed scanner parameters
    z_rate_limit_hat=1e6,
    d_init_hat=250,
    phi_meas_init_deg=120,
    T_I=3e-1,
    integ_clip=None,

    # Substep controls
    n_substeps=50,
    dt_inner_max=None,
    antiwindup=True,
    contact_A_frac=0.02,
    saturation_A_frac=0.98,
    record_mode="last",
    carry_state_to_retrace=True,

    # Optional precomputed FD table
    fd_table=None,
    fd_n_d=4096,

    # Optional effective tip/edge smoothing
    h_smooth_sigma_px=0.0,

    # Loss parameters.
    # Older names are retained for compatibility.
    trim=20,
    w_height_match=1.0,
    w_mse_match=0.5,
    w_diff_profile=0.1,
    w_ringing=0.05,
    w_amp=0.02,
    w_saturation=2.0,
    huber_delta=2.0,
    mse_floor_frac=0.03,
    hp_window=9,

    # New explicit objective weights.
    w_trrt_match=None,
    w_gradient_match=2.0,
    w_gradient_noise=1.0,
    denom_floor_frac=1e-6,

    # Optimizer controls
    maxiter_global=200,
    maxiter_local=300,
    global_tol=0.02,
    local_xatol=1e-3,
    local_fatol=1e-4,
    loss_target=None,
    seed=0,
    popsize=8,

    # Optional: use coarse grid instead of differential evolution
    use_grid_init=False,
    n_grid_P=25,
    n_grid_I=25,

    # Bounds in log10-space
    bounds=None,

    verbose=True,
):
    """
    Fit only P and I while keeping all time constants fixed.

    Optimized vector:
        x = [log10_P, log10_I]

    Default behavior:
        tau_A_fixed=None   -> amplitude detector filter disabled
        tau_phi_fixed=None -> phase detector filter disabled
        tau_z_fixed=None   -> z actuator filter disabled
        T_I=0.3            -> leaky integrator memory enabled

    Updated objective:
        Uses relative trace/retrace mismatch, relative gradient strength, and
        relative gradient-noise statistics. This avoids requiring exact
        ground-truth topography.
    """

    if tau_z is not None:
        tau_z_fixed = tau_z

    if bounds is None:
        bounds = [
            (-4.0, 2.0),   # log10_P
            (-5.0, 2.0),   # log10_I
        ]

    if fd_table is None and hasattr(scanner, "prepare_fd_table_for_drive"):
        fd_table = scanner.prepare_fd_table_for_drive(
            drive_nm=drive,
            n_d=fd_n_d,
        )

    objective = make_scan_objective_exp_PI_fixed_tau(
        scanner=scanner,
        h_input=h_input,
        h_exp=h_exp,

        drive=drive,
        setpoint=setpoint,
        scan_speed_hat=scan_speed_hat,
        dx_hat=dx_hat,

        tau_A_fixed=tau_A_fixed,
        tau_phi_fixed=tau_phi_fixed,
        tau_z_fixed=tau_z_fixed,

        z_rate_limit_hat=z_rate_limit_hat,
        d_init_hat=d_init_hat,
        phi_meas_init_deg=phi_meas_init_deg,
        T_I=T_I,
        integ_clip=integ_clip,

        n_substeps=n_substeps,
        dt_inner_max=dt_inner_max,
        antiwindup=antiwindup,
        contact_A_frac=contact_A_frac,
        saturation_A_frac=saturation_A_frac,
        record_mode=record_mode,
        carry_state_to_retrace=carry_state_to_retrace,

        fd_table=fd_table,
        fd_n_d=fd_n_d,
        h_smooth_sigma_px=h_smooth_sigma_px,

        trim=trim,
        w_height_match=w_height_match,
        w_mse_match=w_mse_match,
        w_diff_profile=w_diff_profile,
        w_ringing=w_ringing,
        w_amp=w_amp,
        w_saturation=w_saturation,
        huber_delta=huber_delta,
        mse_floor_frac=mse_floor_frac,
        hp_window=hp_window,

        w_trrt_match=w_trrt_match,
        w_gradient_match=w_gradient_match,
        w_gradient_noise=w_gradient_noise,
        denom_floor_frac=denom_floor_frac,

        verbose=False,
    )

    best_seen = {
        "loss": np.inf,
        "x": None,
    }

    # ------------------------------------------------------------
    # Optional grid initialization.
    # For 2D P/I fitting, this is often faster and more transparent.
    # ------------------------------------------------------------
    res_grid = None

    if use_grid_init:
        logP_grid = np.linspace(bounds[0][0], bounds[0][1], int(n_grid_P))
        logI_grid = np.linspace(bounds[1][0], bounds[1][1], int(n_grid_I))

        loss_grid = np.full((len(logP_grid), len(logI_grid)), np.nan)

        for i, logP in enumerate(logP_grid):
            for j, logI in enumerate(logI_grid):
                x = np.array([logP, logI], dtype=float)
                loss = objective(x)
                loss_grid[i, j] = loss

                if np.isfinite(loss) and loss < best_seen["loss"]:
                    best_seen["loss"] = float(loss)
                    best_seen["x"] = x.copy()

                    if verbose:
                        p = unpack_controller_params_PI_fixed_tau(
                            x,
                            tau_A_fixed=tau_A_fixed,
                            tau_phi_fixed=tau_phi_fixed,
                            tau_z_fixed=tau_z_fixed,
                        )
                        print(
                            f"[grid] loss={loss:.5g}, "
                            f"P={p['P']:.4g}, I={p['I']:.4g}"
                        )

                if loss_target is not None and np.isfinite(loss) and loss <= loss_target:
                    if verbose:
                        print(f"Stopping early in grid because loss <= {loss_target}")

                    best_loss, best_details, best_out, best_params = objective(
                        best_seen["x"],
                        return_full=True,
                    )

                    return {
                        "best_x": best_seen["x"],
                        "best_params": best_params,
                        "best_loss": best_loss,
                        "best_details": best_details,
                        "best_out": best_out,
                        "best_source": "grid_early_stop",
                        "res_global": None,
                        "res_local": None,
                        "res_grid": {
                            "logP_grid": logP_grid,
                            "logI_grid": logI_grid,
                            "loss_grid": loss_grid,
                        },
                        "objective": objective,
                        "tau_A_fixed": tau_A_fixed,
                        "tau_phi_fixed": tau_phi_fixed,
                        "tau_z_fixed": tau_z_fixed,
                        "T_I": T_I,
                        "fd_table": fd_table,
                        "bounds": bounds,
                    }

        res_grid = {
            "logP_grid": logP_grid,
            "logI_grid": logI_grid,
            "loss_grid": loss_grid,
        }

        x0 = best_seen["x"]
        if x0 is None:
            x0 = np.array(
                [
                    0.5 * (bounds[0][0] + bounds[0][1]),
                    0.5 * (bounds[1][0] + bounds[1][1]),
                ],
                dtype=float,
            )

        res_global = None

    else:
        # ------------------------------------------------------------
        # Differential evolution global search.
        # ------------------------------------------------------------
        def callback(xk, convergence):
            loss = objective(xk)

            if np.isfinite(loss) and loss < best_seen["loss"]:
                best_seen["loss"] = float(loss)
                best_seen["x"] = np.array(xk, dtype=float)

                if verbose:
                    p = unpack_controller_params_PI_fixed_tau(
                        xk,
                        tau_A_fixed=tau_A_fixed,
                        tau_phi_fixed=tau_phi_fixed,
                        tau_z_fixed=tau_z_fixed,
                    )
                    print(
                        f"[global] loss={loss:.5g}, "
                        f"P={p['P']:.4g}, I={p['I']:.4g}"
                    )

            if loss_target is not None and np.isfinite(loss) and loss <= loss_target:
                if verbose:
                    print(f"Stopping early because loss <= loss_target = {loss_target}")
                return True

            return False

        res_global = differential_evolution(
            objective,
            bounds=bounds,
            seed=seed,
            maxiter=maxiter_global,
            popsize=popsize,
            tol=global_tol,
            polish=False,
            updating="immediate",
            workers=1,
            callback=callback,
        )

        if best_seen["x"] is not None and best_seen["loss"] < res_global.fun:
            x0 = best_seen["x"]
        else:
            x0 = res_global.x

    # ------------------------------------------------------------
    # Local refinement.
    # ------------------------------------------------------------
    res_local = minimize(
        objective,
        x0,
        method="Nelder-Mead",
        options={
            "maxiter": maxiter_local,
            "xatol": local_xatol,
            "fatol": local_fatol,
        },
    )

    # Decide best source.
    candidates = []

    if best_seen["x"] is not None and np.isfinite(best_seen["loss"]):
        candidates.append(("best_seen", best_seen["x"], best_seen["loss"]))

    if res_global is not None and np.isfinite(res_global.fun):
        candidates.append(("global", res_global.x, res_global.fun))

    if res_local is not None and np.isfinite(res_local.fun):
        candidates.append(("local", res_local.x, res_local.fun))

    if len(candidates) == 0:
        # Last-resort fallback.
        best_x = np.array(
            [
                0.5 * (bounds[0][0] + bounds[0][1]),
                0.5 * (bounds[1][0] + bounds[1][1]),
            ],
            dtype=float,
        )
        best_source = "fallback_midpoint"
    else:
        best_source, best_x, _ = min(candidates, key=lambda t: t[2])

    best_loss, best_details, best_out, best_params = objective(
        best_x,
        return_full=True,
    )

    return {
        "best_x": best_x,
        "best_params": best_params,
        "best_loss": best_loss,
        "best_details": best_details,
        "best_out": best_out,
        "best_source": best_source,

        "res_global": res_global,
        "res_local": res_local,
        "res_grid": res_grid,

        "objective": objective,

        "tau_A_fixed": tau_A_fixed,
        "tau_phi_fixed": tau_phi_fixed,
        "tau_z_fixed": tau_z_fixed,
        "T_I": T_I,

        "n_substeps": n_substeps,
        "dt_inner_max": dt_inner_max,
        "h_smooth_sigma_px": h_smooth_sigma_px,

        "fd_table": fd_table,
        "bounds": bounds,

        "objective_weights": {
            "w_trrt_match": 2.0 if w_trrt_match is None else float(w_trrt_match),
            "w_gradient_match": float(w_gradient_match),
            "w_gradient_noise": float(w_gradient_noise),
            "denom_floor_frac": float(denom_floor_frac),
        },
    }
