"""One-shot helper: append inline plot/save/load cells to the v3 notebook.

The plot function bodies live in `_inline_plot_figure_4.py` and
`_inline_plot_figure_5.py` next to this script — keeping them as standalone
Python files avoids quote-nesting headaches.  Run this script to append (or
re-append, replacing) Section 15.  Safe to run multiple times.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
NB_PATH = ROOT.parent / 'Fit DT controller parameters to calibration grating scans_v3.ipynb'

PLOT4_SRC = (ROOT / '_inline_plot_figure_4.py').read_text()
PLOT5_SRC = (ROOT / '_inline_plot_figure_5.py').read_text()


def _md(text):
    return {'cell_type': 'markdown', 'metadata': {},
            'source': [l + '\n' for l in text.splitlines()]}


def _code(text):
    return {'cell_type': 'code', 'metadata': {}, 'execution_count': None,
            'outputs': [], 'source': [l + '\n' for l in text.splitlines()]}


CELL_15_INTRO = _md(
"""## 15.  Inline Figure 4 & 5 plotting (editable in this notebook)

For tweaking colours, panel layout, axis limits, etc. the Figure 4 and 5 plot
functions are reproduced **inside the notebook** so they can be edited without
touching `codes/nature_cali_grating_figures.py`.

This section provides:

1. `PALETTE`, `panel_label`, `save_pub` — Nature-style palette and helpers.
2. `save_data_bundle(bundle_path)` — collapse the multi-objective refit results into one `.npz` file.
3. `load_data_bundle(bundle_path)` — inverse of the saver; returns a dict.
4. `plot_figure_4(bundle, save_to=None)` — full Figure 4 source, returns the figure.
5. `plot_figure_5(bundle, save_to=None)` — full Figure 5 source.
6. A driver cell that runs `save → load → plot` end-to-end.

To redraw in any other notebook, copy the styling cell + `load_data_bundle` +
`plot_figure_4` + `plot_figure_5` cells, then call them with the bundle path.""")


CELL_15_STYLE = _code(
"""# 15.1  Styling helpers (palette + panel_label + save_pub).
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import json as _json
from pathlib import Path as _Path
from matplotlib import gridspec
from matplotlib.lines import Line2D

PALETTE = {
    'ink':    '#1f2933', 'muted':  '#667085',
    'blue':   '#2A6FBB', 'teal':   '#1B9E8A',
    'orange': '#D97706', 'red':    '#C2410C',
    'purple': '#7C3AED', 'grey':   '#9CA3AF', 'light': '#F3F4F6',
}

def setup_style():
    mpl.rcParams.update({
        'font.family': 'sans-serif',
        'font.sans-serif': ['Arial', 'Helvetica', 'DejaVu Sans'],
        'font.size': 7.2, 'axes.labelsize': 7.4, 'axes.titlesize': 7.8,
        'xtick.labelsize': 6.6, 'ytick.labelsize': 6.6, 'legend.fontsize': 6.6,
        'axes.linewidth': 0.65,
        'axes.spines.top': False, 'axes.spines.right': False,
        'xtick.major.width': 0.55, 'ytick.major.width': 0.55,
        'xtick.major.size': 2.6, 'ytick.major.size': 2.6,
        'pdf.fonttype': 42, 'ps.fonttype': 42, 'savefig.dpi': 600,
    })

def panel_label(ax, label, x=-0.14, y=1.08):
    ax.text(x, y, label, transform=ax.transAxes, ha='left', va='top',
            fontweight='bold', fontsize=9.4, color='black')

def save_pub(fig, out_dir, stem):
    out_dir = _Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    paths = {fmt: out_dir / f'{stem}.{fmt}' for fmt in ('png', 'pdf', 'tiff')}
    fig.savefig(paths['png'], bbox_inches='tight', dpi=600, facecolor='white')
    fig.savefig(paths['pdf'], bbox_inches='tight', facecolor='white')
    fig.savefig(paths['tiff'], bbox_inches='tight', dpi=600, facecolor='white')
    return {k: str(v) for k, v in paths.items()}

def _center(arr, trim=10):
    arr = np.asarray(arr, float).copy()
    if arr.ndim == 1:
        return arr - np.nanmean(arr[trim:-trim])
    for i in range(arr.shape[0]):
        arr[i] = arr[i] - np.nanmean(arr[i, trim:-trim])
    return arr""")


CELL_15_SAVE = _code(
"""# 15.2  save_data_bundle — collapse Figure-4/5 inputs into one .npz file.
def save_data_bundle(bundle_path,
                     predictions_npz='/tmp/cali_v2_predictions.npz',
                     three_examples_json='/tmp/cali_v2_three_examples.json',
                     local_fits_joblib=None,
                     scanner=None, scanner_cfg=None):
    \"\"\"Write a self-contained .npz with every array Figures 4 & 5 consume.

    Parameters
    ----------
    bundle_path : path
        Output .npz path.
    predictions_npz : path
        Output of `cali_v2_refit_with_multiobjective_loss.py`.
    three_examples_json : path
        JSON written by the refit; embedded as raw text so the loss-component
        bars can be reproduced offline.
    local_fits_joblib : path or None
        Local-PI joblib that supplies the oracle (P, I) labels.  If None,
        prefers the multi-objective cache, falls back to v2iter.
    scanner, scanner_cfg : optional
        If both are provided, the PI loss surface is computed live.
        Otherwise reuses an existing /tmp/cali_v2_loss_surface.npz or
        synthesises a quadratic-in-log fallback.
    \"\"\"
    from joblib import load as _jload
    bundle_path = _Path(bundle_path)
    bundle_path.parent.mkdir(parents=True, exist_ok=True)

    preds = np.load(predictions_npz, allow_pickle=False)
    pipe  = np.load('/tmp/cali_v2_pipeline.npz', allow_pickle=False)

    # Local PI fits → oracle labels
    if local_fits_joblib is None:
        cand1 = PROJECT_ROOT / 'calibration_cache/calibration_grating_v2/local_PI_fits_multi.joblib'
        cand2 = PROJECT_ROOT / 'calibration_cache/calibration_grating_v2/local_PI_fits_balanced_v2iter.joblib'
        local_fits_joblib = cand1 if cand1.exists() else cand2
    local_fits = _jload(str(local_fits_joblib))
    oracle_cond   = np.array([int(r['cond']) for r in local_fits], int)
    oracle_log10P = np.array([float(r['log10_P']) for r in local_fits], float)
    oracle_log10I = np.array([float(r['log10_I']) for r in local_fits], float)
    oracle_P = 10.0 ** oracle_log10P
    oracle_I = 10.0 ** oracle_log10I

    # PI loss surface for panel (b)
    clean_scores = pipe['clean_scores']
    clean_pick   = np.argsort(clean_scores)[:8]
    cond_for_surf = int(clean_pick[0])
    P_grid = np.logspace(-1.5, 1.5, 11); I_grid = np.logspace(-0.5, 2.5, 11)
    surf_cache = _Path('/tmp/cali_v2_loss_surface.npz')
    L = None
    if surf_cache.exists():
        _s = np.load(surf_cache)
        if (int(_s['cond']) == cond_for_surf
                and np.allclose(_s['P_grid'], P_grid)
                and np.allclose(_s['I_grid'], I_grid)):
            L = _s['L']
    if L is None and scanner is not None and scanner_cfg is not None:
        from codes.dt_static_dynamic_calibration_scaffold_v3 import (
            run_scanner_line, get_height_from_out)
        from codes.dt_gp_static_calibration_v3 import diff_shifted
        traces_exp = preds['traces_exp']; h_truth = preds['h_truth']
        drive_exp = preds['drive_exp']; setpoint_exp = preds['setpoint_exp']
        fd_table = scanner.prepare_fd_table_for_drive(float(drive_exp[cond_for_surf]),
                                                       n_d=scanner_cfg.fd_n_d)
        L = np.full((len(P_grid), len(I_grid)), np.nan)
        exp_tr, exp_rt = traces_exp[cond_for_surf, 0], traces_exp[cond_for_surf, 1]
        for ip, P in enumerate(P_grid):
            for jq, I in enumerate(I_grid):
                try:
                    out = run_scanner_line(scanner, h_truth,
                        drive_nm=float(drive_exp[cond_for_surf]),
                        setpoint=float(setpoint_exp[cond_for_surf]),
                        scan_speed_hat=1.0, P=float(P), I=float(I),
                        cfg=scanner_cfg, fd_table=fd_table)
                    sim_tr, sim_rt = get_height_from_out(out)
                except Exception:
                    continue
                sa_tr, ea_tr = diff_shifted(sim_tr, exp_tr)
                sa_rt, ea_rt = diff_shifted(sim_rt, exp_rt)
                trim = 10; n = min(len(sa_tr), len(ea_tr))
                if n <= 2 * trim + 4: continue
                sc = sa_tr[trim:n-trim] - np.nanmean(sa_tr[trim:n-trim])
                ec = ea_tr[trim:n-trim] - np.nanmean(ea_tr[trim:n-trim])
                sd = sa_rt[trim:n-trim] - np.nanmean(sa_rt[trim:n-trim])
                ed = ea_rt[trim:n-trim] - np.nanmean(ea_rt[trim:n-trim])
                L[ip, jq] = float(np.nanmean((sc-ec)**2) + np.nanmean((sd-ed)**2))
        np.savez(surf_cache, cond=cond_for_surf, P_grid=P_grid, I_grid=I_grid, L=L)
    if L is None:
        plog = np.log10(P_grid); ilog = np.log10(I_grid)
        target = next((r for r in local_fits if int(r['cond']) == cond_for_surf),
                      local_fits[0])
        L = (plog[:, None] - target['log10_P'])**2 + (ilog[None, :] - target['log10_I'])**2 + target['loss']

    try:
        three_ex_text = _Path(three_examples_json).read_text()
    except Exception:
        three_ex_text = ''

    demo_keys = ('example_cond_small_I', 'example_cond_optimal_I',
                 'example_cond_large_I', 'demo_cond_idx', 'demo_sim_tr',
                 'demo_sim_rt', 'demo_PI')
    demo_extras = {k: preds[k] for k in demo_keys if k in preds.files}

    np.savez(bundle_path,
        traces_exp=preds['traces_exp'],
        h_truth=preds['h_truth'],
        dt_PI=preds['dt_PI'], dt_oracle=preds['dt_oracle'],
        dd=preds['dd'], hyb=preds['hyb'],
        drive_exp=preds['drive_exp'], setpoint_exp=preds['setpoint_exp'],
        igain_exp=preds['igain_exp'],
        P_all=preds['P_all'], I_all=preds['I_all'],
        oracle_cond=oracle_cond,
        oracle_log10P=oracle_log10P, oracle_log10I=oracle_log10I,
        oracle_P=oracle_P, oracle_I=oracle_I,
        fit_idx=preds['fit_idx'], test_idx=preds['test_idx'],
        clean_scores=clean_scores, clean_pick=clean_pick,
        loss_cond=cond_for_surf, loss_P_grid=P_grid, loss_I_grid=I_grid, loss_L=L,
        q_exp=preds['q_exp'], q_PI=preds['q_PI'], q_dd=preds['q_dd'], q_hyb=preds['q_hyb'],
        rmse_PI=preds['rmse_PI'], rmse_dd=preds['rmse_dd'], rmse_hyb=preds['rmse_hyb'],
        three_examples_json=np.array(three_ex_text),
        **demo_extras,
    )
    print(f'Saved {bundle_path}')
    return bundle_path""")


CELL_15_LOAD = _code(
"""# 15.3  load_data_bundle — inverse of save_data_bundle.
def load_data_bundle(bundle_path):
    \"\"\"Read a bundle .npz and return a dict ready for the plot functions.

    The returned dict carries every array verbatim from the .npz, plus a
    convenience `oracle_PI` map: cond_idx -> {P, I, log10_P, log10_I}.
    \"\"\"
    z = np.load(bundle_path, allow_pickle=False)
    out = {k: z[k] for k in z.files}
    oracle = {}
    for i, c in enumerate(out['oracle_cond']):
        oracle[int(c)] = {
            'P':       float(out['oracle_P'][i]),
            'I':       float(out['oracle_I'][i]),
            'log10_P': float(out['oracle_log10P'][i]),
            'log10_I': float(out['oracle_log10I'][i]),
        }
    out['oracle_PI'] = oracle
    return out""")


CELL_15_PLOT4 = _code(PLOT4_SRC)
CELL_15_PLOT5 = _code(PLOT5_SRC)


CELL_15_DRIVE = _code(
"""# 15.6  Save the data bundle, load it back, and render Figures 4 & 5 inline.
BUNDLE_PATH = PROJECT_ROOT / 'output' / 'calibration_grating_v2_figures' / 'figure_45_data_bundle.npz'
FIG_DIR_INLINE = PROJECT_ROOT / 'output' / 'nature_figures'

save_data_bundle(BUNDLE_PATH, scanner=scanner, scanner_cfg=scanner_cfg)
bundle = load_data_bundle(BUNDLE_PATH)
print('bundle keys:', sorted(k for k in bundle.keys() if k != 'oracle_PI'))

fig4 = plot_figure_4(bundle, save_to=FIG_DIR_INLINE)
fig5 = plot_figure_5(bundle, save_to=FIG_DIR_INLINE)

from IPython.display import display
display(fig4); display(fig5)""")


CELL_16_INTRO = _md(
"""## 16.  Loading the bundle in another notebook

Copy these four cells into any other notebook to redraw both figures with
nothing but `numpy` + `matplotlib`:

* `15.1` — styling helpers (palette, panel_label, save_pub, _center)
* `15.3` — `load_data_bundle`
* `15.4` — `plot_figure_4`
* `15.5` — `plot_figure_5`

Then call:

```python
bundle = load_data_bundle(
    'output/calibration_grating_v2_figures/figure_45_data_bundle.npz')
fig4 = plot_figure_4(bundle)
fig5 = plot_figure_5(bundle)
```""")


def main():
    nb = json.load(open(NB_PATH))
    # Drop any prior section 15/16 cells so this script is rerunnable
    keep = []
    skip_from_section_15 = False
    for c in nb['cells']:
        src = ''.join(c.get('source', []))
        if '## 15.' in src and 'Inline Figure 4 & 5 plotting' in src:
            skip_from_section_15 = True
        if skip_from_section_15:
            continue
        keep.append(c)
    nb['cells'] = keep + [CELL_15_INTRO, CELL_15_STYLE, CELL_15_SAVE,
                           CELL_15_LOAD, CELL_15_PLOT4, CELL_15_PLOT5,
                           CELL_15_DRIVE, CELL_16_INTRO]
    json.dump(nb, open(NB_PATH, 'w'), indent=1)
    print(f'Notebook now has {len(nb["cells"])} cells')


if __name__ == '__main__':
    main()
