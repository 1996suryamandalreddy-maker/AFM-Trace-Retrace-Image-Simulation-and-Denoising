"""Apply points 1, 2, 4, 5 from the post-Tap300-run analysis as one-shot patches.

1. Non-ideality classifier thresholds tuned to the AlScN sample scale
   (range_saturation_nm = 0.3, align_slow_nm = 3.0, stab_unstable_nm = 1.5,
   safety_clip_nm = -10).
2. PINN ODE residual normalised by its starting magnitude so it does not
   dominate the loss gradient; LAMBDA_R kept at 1e-3 for interpretability.
3. Stage-1 descriptor extractor falls back to an unwrapped-phase search when
   the raw-phase 90 degree crossing is not found — recovers sim d_AR / A_AR on
   Tap300 where the simulator's phase representation differs from the
   experimental wrap convention.
4. CNN-LSTM training cell appended at the end of the Tap300 notebook:
   - Self-supervised next-line MSE pretraining on the AlScN expscan dataset.
   - Supervised fine-tuning of the anomaly head against diagnose_non_ideality
     labels.
   - Saves model checkpoint + a per-line anomaly timeline figure.
"""
import json
from pathlib import Path

NB_PATH = (Path(__file__).resolve().parents[1]
            / 'Descriptor-aligned DT-SPM framework — Tap300.ipynb')


def _replace_in_cell(nb, idx, old, new, *, required=True):
    src = ''.join(nb['cells'][idx]['source'])
    if old in src:
        nb['cells'][idx]['source'] = src.replace(old, new).splitlines(keepends=True)
        nb['cells'][idx]['outputs'] = []
        nb['cells'][idx]['execution_count'] = None
        return True
    if required:
        raise RuntimeError(f'cell {idx}: target text not found')
    return False


def _set_cell(nb, idx, text):
    nb['cells'][idx]['source'] = text.splitlines(keepends=True)
    nb['cells'][idx]['outputs'] = []
    nb['cells'][idx]['execution_count'] = None


def _append_code(nb, text):
    nb['cells'].append({
        'cell_type': 'code', 'metadata': {}, 'execution_count': None,
        'outputs': [], 'source': [l + '\n' for l in text.splitlines()],
    })


def _append_md(nb, text):
    nb['cells'].append({
        'cell_type': 'markdown', 'metadata': {},
        'source': [l + '\n' for l in text.splitlines()],
    })


# -------------------------------------------------------------------------
# 1. Non-ideality classifier defaults for AlScN scale
# -------------------------------------------------------------------------
NON_IDEALITY_PATCH = (
    '''def diagnose_non_ideality(rec, scale=None, *,
                             stab_unstable_nm=5.0,    # absolute Q_stab threshold (nm)
                             align_slow_nm=15.0,      # absolute Q_align threshold (nm)
                             range_saturation_nm=20.0, # max range below which a scan is flat / saturated
                             safety_clip_nm=-250.0):    # << post-fix tuning: typical centred-trace 5th pct ≈ -113 nm on the grating''',
    '''def diagnose_non_ideality(rec, scale=None, *,
                             stab_unstable_nm=1.5,    # AlScN HF residual envelope is smaller
                             align_slow_nm=3.0,       # typical Q_align on AlScN is < 1 nm
                             range_saturation_nm=0.3, # AlScN topography variations ~1 nm; saturation < 0.3
                             safety_clip_nm=-10.0):   # AlScN centred-trace 5th pct ≈ -2 nm typically'''
)


# -------------------------------------------------------------------------
# 2. PINN ODE residual normalised by starting magnitude
# -------------------------------------------------------------------------
ODE_PATCH = (
    '''    def ODE_residual(A, phi, d, V, model):
        dAdd = (A[..., 2:] - A[..., :-2]) / (d[..., 2:] - d[..., :-2] + 1e-9)
        dphi_dd = (phi[..., 2:] - phi[..., :-2]) / (d[..., 2:] - d[..., :-2] + 1e-9)
        return (dAdd ** 2 + 0.01 * dphi_dd ** 2).mean()''',
    '''    def ODE_residual(A, phi, d, V, model, _baseline=[None]):
        """Normalised ODE residual.

        PATCH: the raw squared-finite-difference proxy lives in (nm/nm)² units
        and explodes on the Tap300 dataset (~1e11 at init), swamping the
        descriptor and sparsity gradients.  We capture the magnitude at the
        first call and rescale subsequent values by it so the term is O(1).
        """
        dAdd = (A[..., 2:] - A[..., :-2]) / (d[..., 2:] - d[..., :-2] + 1e-9)
        dphi_dd = (phi[..., 2:] - phi[..., :-2]) / (d[..., 2:] - d[..., :-2] + 1e-9)
        raw = (dAdd ** 2 + 0.01 * dphi_dd ** 2).mean()
        if _baseline[0] is None:
            _baseline[0] = float(raw.detach().clamp(min=1e-6))
        return raw / _baseline[0]'''
)


# -------------------------------------------------------------------------
# 4. d_AR phase unwrap fallback in extract_stage1.
#    The change: when no raw 90° crossing is found, try np.unwrap on phi and
#    repeat the search; if found, return the unwrapped d_AR / A_AR.
# -------------------------------------------------------------------------
UNWRAP_PATCH = (
    '''    # Contact-regime descriptors (Tap300 sweeps reach into contact at most drives)
    cross = np.where(np.diff(np.sign(phi - 90.0)) != 0)[0]
    if cross.size > 0:
        k = cross[-1]
        d_AR = float(d[k] + (90 - phi[k]) / (phi[k+1] - phi[k] + 1e-12) * (d[k+1] - d[k]))
        A_AR = float(np.interp(d_AR, d, A))
    else:
        d_AR = A_AR = float('nan')''',
    '''    # Contact-regime descriptors (Tap300 sweeps reach into contact at most drives).
    # PATCH (point 4): if the raw-phase 90° crossing is not found, try the search
    # on the unwrapped phase.  The RK45 simulator emits phase in a different
    # absolute-wrap convention than the experimental lock-in output; the
    # unwrap-and-retry recovers sim d_AR / A_AR for Tap300.
    def _find_AR(d_arr, phi_arr):
        cross = np.where(np.diff(np.sign(phi_arr - 90.0)) != 0)[0]
        if cross.size == 0: return float('nan'), float('nan')
        k = cross[-1]
        d_AR = float(d_arr[k] + (90 - phi_arr[k]) / (phi_arr[k+1] - phi_arr[k] + 1e-12)
                       * (d_arr[k+1] - d_arr[k]))
        return d_AR, float(np.interp(d_AR, d_arr, A))
    d_AR, A_AR = _find_AR(d, phi)
    if not np.isfinite(d_AR):
        phi_uw = np.degrees(np.unwrap(np.radians(phi)))
        # try at 90° and at common wrap-shifted reference (90 ± 360 increments)
        for ref in (90.0, 90.0 + 360.0, 90.0 - 360.0):
            dA, AA = _find_AR(d, phi_uw - ref + 90.0)
            if np.isfinite(dA):
                d_AR, A_AR = dA, AA; break'''
)


# -------------------------------------------------------------------------
# 5. CNN-LSTM training scaffold appended to the Tap300 notebook.
# -------------------------------------------------------------------------
CNN_LSTM_HEADER = '''## 12.  CNN-LSTM training on the AlScN expscan dataset

PATCH (point 5): two-phase training of the OnlineDT head defined in §10.

- Phase 1 — self-supervised next-line MSE prediction.  Builds a sequence of
  (experimental_line_k, DT_line_k) pairs from the 900 expscan conditions and
  trains the CNN feature extractor + short-term LSTM to predict line k+1
  given lines [k−K+1, k].
- Phase 2 — supervised fine-tuning of the anomaly head against the
  `diagnose_non_ideality()` labels from §8 (`feedback_oscillation` and
  `out_of_range` cases become positives; the rest are negatives).

The supervised step uses class-balanced BCE because the positive class is
sparse on AlScN.  Both phases are minimal demonstrators (200 + 200 epochs);
raise the epoch counts for production training.
'''

CNN_LSTM_CELL = r'''if TORCH_OK:
    import time as _t
    # ---- Build the (exp, DT, next_exp) sequence corpus ----
    # We use the 60 v3 calibration-grating conditions as one demo "session",
    # and split the AlScN expscan conditions (900 conditions × 2 directions
    # = 1800 lines) into sliding windows of K=32.
    K = Stage3FittingParameters().short_window
    n_pix = traces_exp.shape[-1]

    # Flatten conditions × {trace, retrace} into a 2D sequence ordered by cond
    exp_flat = traces_exp.reshape(-1, n_pix)
    dt_flat  = dt_PI.reshape(-1, n_pix)
    n_lines  = exp_flat.shape[0]
    print(f'Total expscan lines available: {n_lines}')

    # Center each line by interior mean for stable learning
    def _ctr(x, trim=10):
        m = np.nanmean(x[trim:-trim])
        return (x - m).astype(np.float32)
    exp_c = np.stack([_ctr(exp_flat[i]) for i in range(n_lines)])
    dt_c  = np.stack([_ctr(dt_flat[i])  for i in range(n_lines)])

    # Build supervision labels per condition (anomaly = saturation or
    # feedback_oscillation or out_of_range from §8).  We map them to lines:
    # both trace and retrace inherit the cond label.
    POSITIVE = {'feedback_oscillation', 'out_of_range'}
    cond_label = np.array(
        [1 if diag_df.iloc[i]['label'] in POSITIVE else 0
          for i in range(len(diag_df))], dtype=np.float32)
    # diag_df is over 'exp' source rows; expand cond_label across trace+retrace
    if cond_label.size == traces_exp.shape[0]:
        line_label = np.repeat(cond_label, 2)   # match exp_flat ordering
    else:
        line_label = np.zeros(n_lines, dtype=np.float32)
    print(f'  positive lines (anomaly = 1): {int(line_label.sum())} / {len(line_label)}')

    # ---- Build sliding-window batches ----
    def make_windows(arr, K=K):
        n = arr.shape[0] - K
        out = np.stack([arr[i:i+K] for i in range(n)], axis=0)
        return out
    exp_win = make_windows(exp_c)            # (N_win, K, n_pix)
    dt_win  = make_windows(dt_c)
    nxt_exp = exp_c[K:]                       # next-line target (N_win, n_pix)
    line_lbl_win = line_label[K-1:-1]         # label of the last line in window
    print(f'Sliding-window batches: {exp_win.shape}')

    # Train/eval split: hold out the last 20% of windows for evaluation
    n_train = int(0.8 * exp_win.shape[0])
    idx = np.arange(exp_win.shape[0]); np.random.default_rng(0).shuffle(idx)
    tr_idx, ev_idx = idx[:n_train], idx[n_train:]
    print(f'  train: {tr_idx.size} windows, eval: {ev_idx.size} windows')

    exp_T = torch.tensor(exp_win, dtype=torch.float32)
    dt_T  = torch.tensor(dt_win,  dtype=torch.float32)
    nxt_T = torch.tensor(nxt_exp, dtype=torch.float32)
    lbl_T = torch.tensor(line_lbl_win, dtype=torch.float32)

    # ---- Instantiate the CNN-LSTM ----
    p3 = Stage3FittingParameters()
    online = OnlineDTHead(p3)
    print('OnlineDTHead built.')

    # ---- Phase 1: self-supervised next-line MSE pretraining ----
    # We add a tiny next-line decoder head on top of the short-LSTM features
    # for this phase only; the deployed model exposes the anomaly head.
    class _NextLineDecoder(nn.Module):
        def __init__(self, in_dim, n_pix):
            super().__init__()
            self.fc = nn.Sequential(nn.Linear(in_dim, 128), nn.GELU(),
                                      nn.Linear(128, n_pix))
        def forward(self, h): return self.fc(h)
    pre_dec = _NextLineDecoder(p3.short_LSTM_hidden + p3.long_LSTM_hidden, n_pix)

    opt = torch.optim.Adam(list(online.parameters()) + list(pre_dec.parameters()), lr=1e-3)
    BATCH = 64; N_EPOCH_P1 = 200
    history_p1 = []
    t0 = _t.time()
    for epoch in range(N_EPOCH_P1):
        # mini-batch
        b = np.random.choice(tr_idx, size=min(BATCH, tr_idx.size), replace=False)
        e_b = exp_T[b]; d_b = dt_T[b]; nx_b = nxt_T[b]
        # Forward: same path as the head, then take comb features and decode
        B, Kw, P = e_b.shape
        feats = online.cnn(e_b.reshape(B*Kw, P), d_b.reshape(B*Kw, P)).reshape(B, Kw, -1)
        short_out, _ = online.short(feats)
        long_out, _  = online.long(feats[:, ::p3.long_decimation, :])
        comb = torch.cat([short_out[:, -1, :], long_out[:, -1, :]], dim=-1)
        pred = pre_dec(comb)
        loss = ((pred - nx_b)**2).mean()
        opt.zero_grad(); loss.backward(); opt.step()
        history_p1.append(float(loss))
    print(f'Phase 1 done in {_t.time()-t0:.1f}s.  last MSE = {history_p1[-1]:.4f}')

    # ---- Phase 2: supervised fine-tune of the anomaly head ----
    pos_w = torch.tensor([(lbl_T == 0).sum() / max(1, (lbl_T == 1).sum())], dtype=torch.float32)
    bce = nn.BCEWithLogitsLoss(pos_weight=pos_w)
    opt = torch.optim.Adam(online.parameters(), lr=5e-4)
    N_EPOCH_P2 = 200
    history_p2 = []
    t0 = _t.time()
    for epoch in range(N_EPOCH_P2):
        b = np.random.choice(tr_idx, size=min(BATCH, tr_idx.size), replace=False)
        e_b = exp_T[b]; d_b = dt_T[b]; y_b = lbl_T[b]
        out = online(e_b, d_b)
        logit = online.anomaly[0](torch.cat([out['anomaly'].new_zeros(0)] +
                                              [torch.cat([online.short(online.cnn(
                                                  e_b.reshape(BATCH*K, P),
                                                  d_b.reshape(BATCH*K, P)).reshape(BATCH, K, -1))[0][:, -1, :],
                                                  online.long(online.cnn(
                                                  e_b.reshape(BATCH*K, P),
                                                  d_b.reshape(BATCH*K, P)).reshape(BATCH, K, -1)[:, ::p3.long_decimation, :])[0][:, -1, :]], dim=-1)],
                                              dim=0))
        # Simpler: just use the head's anomaly output (its raw logit equivalent)
        logits = torch.logit(out['anomaly'].clamp(1e-6, 1 - 1e-6))
        loss = bce(logits, y_b)
        opt.zero_grad(); loss.backward(); opt.step()
        history_p2.append(float(loss))
    print(f'Phase 2 done in {_t.time()-t0:.1f}s.  last BCE = {history_p2[-1]:.4f}')

    # ---- Held-out evaluation ----
    with torch.no_grad():
        out = online(exp_T[ev_idx], dt_T[ev_idx])
        scores = out['anomaly'].cpu().numpy()
        labels = lbl_T[ev_idx].cpu().numpy()
    # Simple ROC-style summary
    from sklearn.metrics import roc_auc_score, average_precision_score
    try:
        auc = float(roc_auc_score(labels, scores)) if labels.sum() > 0 else float('nan')
        ap  = float(average_precision_score(labels, scores)) if labels.sum() > 0 else float('nan')
    except Exception:
        auc = ap = float('nan')
    print(f'Held-out:  AUC = {auc:.3f}   AP = {ap:.3f}')

    # ---- Anomaly timeline figure ----
    fig, axes = plt.subplots(2, 1, figsize=(9.0, 4.0), sharex=True,
                              constrained_layout=True)
    ax = axes[0]
    order = np.argsort(ev_idx)
    ax.plot(np.array(history_p1), color=PALETTE['PI'],   label='phase 1: next-line MSE')
    ax2 = ax.twinx()
    ax2.plot(np.array(history_p2), color=PALETTE['hybrid'], label='phase 2: BCE')
    ax.set_xlabel('epoch'); ax.set_ylabel('MSE', color=PALETTE['PI'])
    ax2.set_ylabel('BCE', color=PALETTE['hybrid'])
    ax.set_title('CNN-LSTM training history')

    ax = axes[1]
    ax.plot(scores, color=PALETTE['hybrid'], lw=1.2, label='anomaly score')
    ax.scatter(np.where(labels == 1)[0], scores[labels == 1], color=PALETTE['unstable'],
                s=18, edgecolor='white', label='positive (anomaly)')
    ax.axhline(0.5, color='0.5', lw=0.6, ls='--', label='threshold 0.5')
    ax.set_xlabel('held-out window index')
    ax.set_ylabel('anomaly score'); ax.set_ylim(0, 1)
    ax.set_title(f'CNN-LSTM held-out anomaly timeline (AUC={auc:.2f}, AP={ap:.2f})')
    ax.legend(frameon=False, fontsize=8)
    fig.savefig(FIG_DIR / 'lstm_anomaly_trained.png')

    # Save the trained model
    ckpt = PROJECT_ROOT / 'output' / 'dt_models' / 'tap300_online_dt.pt'
    ckpt.parent.mkdir(parents=True, exist_ok=True)
    torch.save({'state_dict': online.state_dict(),
                 'stage3_params': asdict(p3),
                 'auc': auc, 'ap': ap,
                 'history_p1': history_p1, 'history_p2': history_p2},
                str(ckpt))
    print(f'Saved trained model to {ckpt}')'''


def main():
    nb = json.load(open(NB_PATH))

    # 1. Non-ideality thresholds — cell 31 in the framework notebook layout
    print('Patch 1: non-ideality thresholds → AlScN scale')
    _replace_in_cell(nb, 31, *NON_IDEALITY_PATCH)

    # 2. ODE residual normalisation — cell 35
    print('Patch 2: ODE residual normalised by starting magnitude')
    _replace_in_cell(nb, 35, *ODE_PATCH)

    # 4. d_AR unwrap fallback — cell 9
    print('Patch 4: phase-unwrap fallback for d_AR / A_AR')
    _replace_in_cell(nb, 9, *UNWRAP_PATCH)

    # 5. Append the CNN-LSTM training scaffold
    print('Patch 5: append CNN-LSTM training cells')
    _append_md(nb, CNN_LSTM_HEADER)
    _append_code(nb, CNN_LSTM_CELL)

    json.dump(nb, open(NB_PATH, 'w'), indent=1)
    print(f'\nPatched notebook ({len(nb["cells"])} cells)')


if __name__ == '__main__':
    main()
