
"""
dt_scan_state_hybrid_layers_v2.py

Hybrid scan-state residual layers for an SPM digital twin.

Purpose
-------
Do not force scan-line amplitude-phase points onto the FD curve. Instead use the
FD/controller model as a physics backbone and learn the scan-state residual:

    d_eff    = d_DT + delta_d_dyn(x)
    A_pred   = A_FD(d_eff, drive)   + delta_A0(x_static)   + delta_A_dyn(x_dyn)
    phi_pred = phi_FD(d_eff, drive) + delta_phi0(x_static) + delta_phi_dyn(x_dyn)
    h_pred   = h_DT + delta_h_dyn(x_dyn)

The file also includes a pure data-driven baseline that learns directly:

    controls + direction + x_position -> A_exp, phi_exp, h_exp

Expected arrays
---------------
traces_exp_height.shape = (n_speed, n_drive, n_setpoint, n_gain, 2, n_pix)
traces_exp_amp.shape    = same
traces_exp_phase.shape  = same
"""

from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Optional, Sequence, Tuple, Dict, Any, Callable, Union
import numpy as np

try:
    import pandas as pd
except Exception:
    pd = None

try:
    from codes.dt_static_dynamic_calibration_scaffold_v3 import run_scanner_line, prepare_fd_table
except Exception:
    try:
        from dt_static_dynamic_calibration_scaffold_v3 import run_scanner_line, prepare_fd_table
    except Exception:
        run_scanner_line = None
        prepare_fd_table = None


# -----------------------------------------------------------------------------
# Configs
# -----------------------------------------------------------------------------

@dataclass
class ResidualDatasetConfig:
    pairing: str = "quantile_by_A"       # "pixel", "quantile_by_A", or "quantile_by_h"
    max_points_per_direction: int = 128
    n_synthetic_lines_per_condition: int = 1
    random_state: int = 0
    phase_period_deg: float = 360.0
    stable_only: bool = True
    min_A_frac_of_A95: float = 0.03
    max_abs_phi_residual_deg: Optional[float] = None
    include_retrace: bool = True
    trim_edges: int = 5


@dataclass
class StaticScanStateConfig:
    # Include setpoint because your scan-state clouds are strongly setpoint-dependent.
    feature_cols: Tuple[str, ...] = ("drive_nm", "setpoint", "d_dt", "A_fd", "phi_fd")
    target_cols: Tuple[str, ...] = ("delta_A_raw", "delta_phi_raw")
    model_type: str = "histgb"           # "histgb", "extratrees", "randomforest"
    random_state: int = 0
    max_iter: int = 300
    learning_rate: float = 0.05
    max_leaf_nodes: int = 31
    min_samples_leaf: int = 20
    n_estimators: int = 300
    max_depth: Optional[int] = None
    max_train_points: Optional[int] = 50000


@dataclass
class DynamicScanStateConfig:
    feature_cols: Tuple[str, ...] = (
        "log_scan_speed", "drive_nm", "setpoint", "log_I_exp",
        "log_P_sim", "log_I_sim", "direction_sign", "x_norm",
        "d_dt", "A_fd", "phi_fd", "h_dt", "z_dt",
        "dd_dt", "dA_fd", "dphi_fd", "dh_dt", "dz_dt",
        "A_static_orig", "phi_static_orig",
    )
    target_cols: Tuple[str, ...] = (
        "delta_d_dyn_target", "delta_A_dyn_target",
        "delta_phi_dyn_target", "delta_h_dyn_target",
    )
    model_type: str = "histgb"
    random_state: int = 0
    max_iter: int = 400
    learning_rate: float = 0.04
    max_leaf_nodes: int = 31
    min_samples_leaf: int = 30
    n_estimators: int = 400
    max_depth: Optional[int] = None
    max_train_points: Optional[int] = 100000


@dataclass
class PureDataConfig:
    feature_cols: Tuple[str, ...] = (
        "log_scan_speed", "drive_nm", "setpoint",
        "log_I_exp", "direction_sign", "x_exp_norm",
    )
    target_cols: Tuple[str, ...] = ("exp_A", "exp_phi", "exp_h")
    model_type: str = "histgb"
    random_state: int = 0
    max_iter: int = 400
    learning_rate: float = 0.04
    max_leaf_nodes: int = 31
    min_samples_leaf: int = 30
    n_estimators: int = 400
    max_depth: Optional[int] = None
    max_train_points: Optional[int] = 100000


# -----------------------------------------------------------------------------
# Utilities
# -----------------------------------------------------------------------------

def _require_pandas(df=None):
    if pd is None:
        raise ImportError("pandas is required.")
    if df is not None and not hasattr(df, "columns"):
        raise TypeError("Expected a pandas DataFrame.")


def robust_mad(x, eps=1e-12):
    x = np.asarray(x, dtype=float).ravel()
    x = x[np.isfinite(x)]
    if x.size == 0:
        return eps
    med = np.nanmedian(x)
    return float(1.4826 * np.nanmedian(np.abs(x - med)) + eps)


def wrap_phase_diff_deg(diff, period=360.0):
    diff = np.asarray(diff, dtype=float)
    return (diff + 0.5 * period) % period - 0.5 * period


def condition_key(si, di, spi, gi):
    return f"{int(si)}_{int(di)}_{int(spi)}_{int(gi)}"


def _trim(x, trim):
    x = np.asarray(x, dtype=float).ravel()
    trim = int(trim)
    if trim <= 0 or x.size <= 2 * trim + 4:
        return x
    return x[trim:-trim]


def _finite_mask(*xs):
    m = np.ones_like(np.asarray(xs[0], dtype=float), dtype=bool)
    for x in xs:
        m &= np.isfinite(np.asarray(x, dtype=float))
    return m


def _subsample_indices(n, max_points, rng):
    n = int(n)
    if max_points is None or n <= int(max_points):
        return np.arange(n, dtype=int)
    return np.sort(rng.choice(n, size=int(max_points), replace=False))


def _sample_df(df, max_points, seed):
    if max_points is None or len(df) <= int(max_points):
        return df
    return df.sample(n=int(max_points), random_state=int(seed), replace=False)


def _finite_training_mask(df, feature_cols, target_cols):
    X = df[list(feature_cols)].to_numpy(dtype=float)
    Y = df[list(target_cols)].to_numpy(dtype=float)
    return np.isfinite(X).all(axis=1) & np.isfinite(Y).all(axis=1)


# -----------------------------------------------------------------------------
# FD table helpers
# -----------------------------------------------------------------------------

class FDTableCache:
    def __init__(self, scanner=None, fd_tables=None, n_d=4096, round_decimals=8):
        self.scanner = scanner
        self.fd_tables = fd_tables
        self.n_d = int(n_d)
        self.round_decimals = int(round_decimals)
        self.cache = {}

    def _key(self, drive_nm):
        return round(float(drive_nm), self.round_decimals)

    def get(self, drive_nm, drive_index=None):
        if self.fd_tables is not None:
            if isinstance(self.fd_tables, dict):
                if drive_index is not None and drive_index in self.fd_tables:
                    return self.fd_tables[drive_index]
                k = self._key(drive_nm)
                if k in self.fd_tables:
                    return self.fd_tables[k]
                if float(drive_nm) in self.fd_tables:
                    return self.fd_tables[float(drive_nm)]
            else:
                if drive_index is not None:
                    return self.fd_tables[int(drive_index)]

        k = self._key(drive_nm)
        if k not in self.cache:
            if self.scanner is None:
                raise ValueError("No scanner available to build missing FD table.")
            if hasattr(self.scanner, "prepare_fd_table_for_drive"):
                self.cache[k] = self.scanner.prepare_fd_table_for_drive(
                    drive_nm=float(drive_nm), n_d=self.n_d
                )
            elif prepare_fd_table is not None:
                self.cache[k] = prepare_fd_table(self.scanner, float(drive_nm), self.n_d)
            else:
                raise ValueError("Cannot prepare FD table for this scanner.")
        return self.cache[k]


def _fd_arrays(fd_table):
    d = fd_table.get("d_grid", fd_table.get("d", None))
    A = fd_table.get("A_grid", fd_table.get("A", None))
    phi = fd_table.get("phi_grid", fd_table.get("phi", None))
    if d is None or A is None or phi is None:
        raise KeyError("fd_table must contain d_grid/d, A_grid/A, phi_grid/phi.")
    d = np.asarray(d, dtype=float).ravel()
    A = np.asarray(A, dtype=float).ravel()
    phi = np.asarray(phi, dtype=float).ravel()
    m = np.isfinite(d) & np.isfinite(A) & np.isfinite(phi)
    d, A, phi = d[m], A[m], phi[m]
    order = np.argsort(d)
    return d[order], A[order], phi[order]


def interp_fd_table(fd_table, d_query):
    d, A, phi = _fd_arrays(fd_table)
    q = np.asarray(d_query, dtype=float)
    return (
        np.interp(q, d, A, left=A[0], right=A[-1]),
        np.interp(q, d, phi, left=phi[0], right=phi[-1]),
    )


def invert_fd_A_to_d(fd_table, A_query):
    d, A, _ = _fd_arrays(fd_table)
    order = np.argsort(A)
    Au, idx = np.unique(A[order], return_index=True)
    du = d[order][idx]
    Aq = np.asarray(A_query, dtype=float)
    if Au.size < 2:
        return np.full_like(Aq, np.nan, dtype=float)
    return np.interp(np.clip(Aq, Au[0], Au[-1]), Au, du)


# -----------------------------------------------------------------------------
# Scanner output extraction
# -----------------------------------------------------------------------------

def _pick(dct, keys):
    if not isinstance(dct, dict):
        return None
    for k in keys:
        if k in dct and dct[k] is not None:
            return np.asarray(dct[k], dtype=float).ravel()
    return None


def extract_dt_direction_state(direction_dict, fd_table=None):
    h_dt = _pick(direction_dict, ["h_hat", "height_hat", "height", "height_out_hat", "z_out_hat"])
    z_dt = _pick(direction_dict, ["z_hat", "z", "z_meas_hat", "z_cmd_hat", "z_out_hat"])
    d_dt = _pick(direction_dict, ["gap_hat", "d_ts_hat", "distance_hat", "d_true_hat", "d_eff_hat"])
    A_fd = _pick(direction_dict, ["A_hat", "A_meas_hat", "A_meas", "A_true_hat", "A_true", "amp_hat", "amp"])
    phi_fd = _pick(direction_dict, ["phi_deg", "phi_hat_deg", "phi_meas_deg", "phi_meas", "phase_deg", "phase"])

    # Fallback for older scanner outputs. Better: explicitly output gap_hat.
    if d_dt is None:
        d_dt = _pick(direction_dict, ["d_hat"])
    if h_dt is None:
        h_dt = _pick(direction_dict, ["d_hat"])

    if d_dt is not None and fd_table is not None and (A_fd is None or phi_fd is None):
        Ai, pi = interp_fd_table(fd_table, d_dt)
        if A_fd is None: A_fd = Ai
        if phi_fd is None: phi_fd = pi

    vals = [v for v in [h_dt, z_dt, d_dt, A_fd, phi_fd] if v is not None]
    if not vals:
        raise ValueError("Could not extract scanner output arrays.")
    n = min(len(v) for v in vals)

    def fix(v):
        if v is None:
            return np.full(n, np.nan)
        return np.asarray(v, dtype=float).ravel()[:n]

    return {"h_dt": fix(h_dt), "z_dt": fix(z_dt), "d_dt": fix(d_dt), "A_fd": fix(A_fd), "phi_fd": fix(phi_fd)}


def extract_dt_state_from_out(out, fd_table=None):
    return {
        "trace": extract_dt_direction_state(out["trace"], fd_table),
        "retrace": extract_dt_direction_state(out["retrace"], fd_table),
    }


def add_history_features(state):
    out = dict(state)
    def diffpad(x):
        x = np.asarray(x, dtype=float).ravel()
        y = np.empty_like(x)
        if x.size:
            y[0] = 0.0
            y[1:] = np.diff(x)
        return y
    out["dd_dt"] = diffpad(out["d_dt"])
    out["dA_fd"] = diffpad(out["A_fd"])
    out["dphi_fd"] = diffpad(out["phi_fd"])
    out["dh_dt"] = diffpad(out["h_dt"])
    out["dz_dt"] = diffpad(out["z_dt"])
    out["x_norm"] = np.linspace(0.0, 1.0, len(out["A_fd"]))
    return out


# -----------------------------------------------------------------------------
# Pairing and dataset construction
# -----------------------------------------------------------------------------

def _pair_quantile(sim_key, exp_key, max_points, rng):
    n = min(len(sim_key), len(exp_key))
    if n < 5:
        return None, None
    sim_key = np.asarray(sim_key, dtype=float)[:n]
    exp_key = np.asarray(exp_key, dtype=float)[:n]
    m = np.isfinite(sim_key) & np.isfinite(exp_key)
    if np.sum(m) < 5:
        return None, None
    valid = np.where(m)[0]
    sim_order = valid[np.argsort(sim_key[m])]
    exp_order = valid[np.argsort(exp_key[m])]
    q = _subsample_indices(len(sim_order), max_points, rng)
    return sim_order[q], exp_order[q]


def pair_sim_exp_samples(sim_state, exp_h, exp_A, exp_phi, *, pairing, max_points, rng, trim_edges=0):
    exp_h = _trim(exp_h, trim_edges); exp_A = _trim(exp_A, trim_edges); exp_phi = _trim(exp_phi, trim_edges)
    sim_state = {k: _trim(v, trim_edges) for k, v in sim_state.items()}
    n = min([len(exp_h), len(exp_A), len(exp_phi)] + [len(v) for v in sim_state.values()])
    if n < 5:
        return None
    exp_h, exp_A, exp_phi = exp_h[:n], exp_A[:n], exp_phi[:n]
    sim_state = {k: v[:n] for k, v in sim_state.items()}
    exp_x_norm = np.linspace(0.0, 1.0, n)

    if pairing == "pixel":
        idx = _subsample_indices(n, max_points, rng)
        si, ei = idx, idx
    elif pairing == "quantile_by_A":
        si, ei = _pair_quantile(sim_state["A_fd"], exp_A, max_points, rng)
    elif pairing == "quantile_by_h":
        si, ei = _pair_quantile(sim_state["h_dt"], exp_h, max_points, rng)
    else:
        raise ValueError("pairing must be 'pixel', 'quantile_by_A', or 'quantile_by_h'.")
    if si is None:
        return None

    out = {k: np.asarray(v, dtype=float)[si] for k, v in sim_state.items()}
    out["exp_h"] = exp_h[ei]
    out["exp_A"] = exp_A[ei]
    out["exp_phi"] = exp_phi[ei]
    out["x_exp_norm"] = exp_x_norm[ei]
    return out


def make_all_conditions(traces_exp_height, speed_indices=None, drive_indices=None, setpoint_indices=None, gain_indices=None):
    arr = np.asarray(traces_exp_height)
    ns, nd, nsp, ng = arr.shape[:4]
    def ids(x, n):
        return np.arange(n, dtype=int) if x is None else np.asarray(x, dtype=int)
    return [(int(si), int(di), int(spi), int(gi))
            for si in ids(speed_indices, ns)
            for di in ids(drive_indices, nd)
            for spi in ids(setpoint_indices, nsp)
            for gi in ids(gain_indices, ng)]


def get_PI_for_condition(cond, *, P_grid=None, I_grid=None, controller_fn=None, controls=None):
    if controller_fn is not None:
        return controller_fn(cond, controls)
    if P_grid is None or I_grid is None:
        raise ValueError("Provide P_grid/I_grid or controller_fn.")
    si, di, spi, gi = cond
    return float(P_grid[si, di, spi, gi]), float(I_grid[si, di, spi, gi])


def _stability_mask(A_fd, exp_A, phi_fd, exp_phi, cfg):
    m = _finite_mask(A_fd, exp_A, phi_fd, exp_phi)
    if cfg.stable_only:
        A_all = np.r_[np.asarray(A_fd)[np.isfinite(A_fd)], np.asarray(exp_A)[np.isfinite(exp_A)]]
        if A_all.size > 5:
            A95 = np.nanpercentile(A_all, 95)
            if np.isfinite(A95) and A95 > 0:
                m &= np.asarray(A_fd) > cfg.min_A_frac_of_A95 * A95
                m &= np.asarray(exp_A) > cfg.min_A_frac_of_A95 * A95
        if cfg.max_abs_phi_residual_deg is not None:
            dphi = wrap_phase_diff_deg(np.asarray(exp_phi) - np.asarray(phi_fd), cfg.phase_period_deg)
            m &= np.abs(dphi) <= float(cfg.max_abs_phi_residual_deg)
    return m


def build_residual_dataset(
    scanner,
    traces_exp_height,
    traces_exp_amp,
    traces_exp_phase,
    synthetic_lines,
    scan_speeds_hat,
    drives_nm,
    setpoints,
    i_gains_exp,
    *,
    scanner_cfg,
    P_grid=None,
    I_grid=None,
    controller_fn: Optional[Callable] = None,
    conds=None,
    fd_cache=None,
    fd_tables=None,
    cfg=None,
):
    if run_scanner_line is None:
        raise ImportError("Could not import run_scanner_line from dt_static_dynamic_calibration_scaffold_v3.")
    if cfg is None:
        cfg = ResidualDatasetConfig()
    if fd_cache is None:
        fd_cache = FDTableCache(scanner=scanner, fd_tables=fd_tables, n_d=scanner_cfg.fd_n_d)
    if conds is None:
        conds = make_all_conditions(traces_exp_height)

    rng = np.random.default_rng(cfg.random_state)
    rows = []
    n_lines = len(synthetic_lines)

    for cond in conds:
        si, di, spi, gi = cond
        speed = float(scan_speeds_hat[si]); drive = float(drives_nm[di])
        setpoint = float(setpoints[spi]); I_exp = float(i_gains_exp[gi])
        P_sim, I_sim = get_PI_for_condition(
            cond, P_grid=P_grid, I_grid=I_grid, controller_fn=controller_fn,
            controls={"scan_speed_hat": speed, "drive_nm": drive, "setpoint": setpoint, "I_exp": I_exp},
        )
        fd_table = fd_cache.get(drive, drive_index=di)

        for q in range(int(cfg.n_synthetic_lines_per_condition)):
            line_idx = q % n_lines
            out = run_scanner_line(
                scanner, np.asarray(synthetic_lines[line_idx], dtype=float).ravel(),
                drive_nm=drive, setpoint=setpoint, scan_speed_hat=speed,
                P=P_sim, I=I_sim, cfg=scanner_cfg, fd_table=fd_table,
            )
            states = extract_dt_state_from_out(out, fd_table=fd_table)
            dirs = ["trace", "retrace"] if cfg.include_retrace else ["trace"]
            for dir_name in dirs:
                dind = 0 if dir_name == "trace" else 1
                sign = 1.0 if dir_name == "trace" else -1.0
                state = add_history_features(states[dir_name])
                paired = pair_sim_exp_samples(
                    state,
                    traces_exp_height[si, di, spi, gi, dind],
                    traces_exp_amp[si, di, spi, gi, dind],
                    traces_exp_phase[si, di, spi, gi, dind],
                    pairing=cfg.pairing,
                    max_points=cfg.max_points_per_direction,
                    rng=rng,
                    trim_edges=cfg.trim_edges,
                )
                if paired is None:
                    continue
                m = _stability_mask(paired["A_fd"], paired["exp_A"], paired["phi_fd"], paired["exp_phi"], cfg)
                if np.sum(m) < 5:
                    continue
                midx = np.where(m)[0]
                d_from_A = invert_fd_A_to_d(fd_table, paired["exp_A"][m])
                dA = paired["exp_A"][m] - paired["A_fd"][m]
                dphi = wrap_phase_diff_deg(paired["exp_phi"][m] - paired["phi_fd"][m], cfg.phase_period_deg)
                dh = paired["exp_h"][m] - paired["h_dt"][m]
                dd = d_from_A - paired["d_dt"][m]

                for t, ii in enumerate(midx):
                    rows.append({
                        "cond_key": condition_key(si, di, spi, gi),
                        "si": si, "di": di, "spi": spi, "gi": gi,
                        "synthetic_line_index": int(line_idx),
                        "direction": dir_name, "direction_sign": sign,
                        "scan_speed_hat": speed, "log_scan_speed": np.log10(max(speed, 1e-30)),
                        "drive_nm": drive, "setpoint": setpoint,
                        "I_exp": I_exp, "log_I_exp": np.log10(max(I_exp, 1e-30)),
                        "P_sim": P_sim, "I_sim": I_sim,
                        "log_P_sim": np.log10(max(P_sim, 1e-30)),
                        "log_I_sim": np.log10(max(I_sim, 1e-30)),
                        "x_norm": float(paired["x_norm"][ii]),
                        "x_exp_norm": float(paired["x_exp_norm"][ii]),
                        "h_dt": float(paired["h_dt"][ii]), "z_dt": float(paired["z_dt"][ii]),
                        "d_dt": float(paired["d_dt"][ii]), "A_fd": float(paired["A_fd"][ii]),
                        "phi_fd": float(paired["phi_fd"][ii]),
                        "dd_dt": float(paired["dd_dt"][ii]), "dA_fd": float(paired["dA_fd"][ii]),
                        "dphi_fd": float(paired["dphi_fd"][ii]),
                        "dh_dt": float(paired["dh_dt"][ii]), "dz_dt": float(paired["dz_dt"][ii]),
                        "exp_h": float(paired["exp_h"][ii]),
                        "exp_A": float(paired["exp_A"][ii]),
                        "exp_phi": float(paired["exp_phi"][ii]),
                        "d_from_A_exp": float(d_from_A[t]),
                        "delta_d_from_A": float(dd[t]),
                        "delta_A_raw": float(dA[t]),
                        "delta_phi_raw": float(dphi[t]),
                        "delta_h_raw": float(dh[t]),
                    })

    if pd is None:
        return rows
    return pd.DataFrame(rows)


# -----------------------------------------------------------------------------
# Regressor wrappers
# -----------------------------------------------------------------------------

def _make_regressor(model_type, cfg):
    try:
        from sklearn.ensemble import ExtraTreesRegressor, RandomForestRegressor, HistGradientBoostingRegressor
        from sklearn.multioutput import MultiOutputRegressor
        from sklearn.pipeline import make_pipeline
        from sklearn.impute import SimpleImputer
        from sklearn.preprocessing import StandardScaler
    except Exception as exc:
        raise ImportError("Install scikit-learn to use this module.") from exc

    mt = model_type.lower()
    if mt == "histgb":
        base = HistGradientBoostingRegressor(
            max_iter=int(cfg.max_iter),
            learning_rate=float(cfg.learning_rate),
            max_leaf_nodes=int(cfg.max_leaf_nodes),
            min_samples_leaf=int(cfg.min_samples_leaf),
            random_state=int(cfg.random_state),
            l2_regularization=1e-4,
        )
        return make_pipeline(SimpleImputer(strategy="median"), StandardScaler(), MultiOutputRegressor(base))
    if mt == "extratrees":
        return make_pipeline(SimpleImputer(strategy="median"), ExtraTreesRegressor(
            n_estimators=int(cfg.n_estimators), max_depth=cfg.max_depth,
            min_samples_leaf=int(cfg.min_samples_leaf), random_state=int(cfg.random_state), n_jobs=-1))
    if mt == "randomforest":
        return make_pipeline(SimpleImputer(strategy="median"), RandomForestRegressor(
            n_estimators=int(cfg.n_estimators), max_depth=cfg.max_depth,
            min_samples_leaf=int(cfg.min_samples_leaf), random_state=int(cfg.random_state), n_jobs=-1))
    raise ValueError("model_type must be histgb, extratrees, or randomforest.")


def _X(data, cols):
    if pd is not None and hasattr(data, "columns"):
        return data[list(cols)].to_numpy(dtype=float)
    if isinstance(data, dict):
        return np.column_stack([np.asarray(data[c], dtype=float).ravel() for c in cols])
    return np.asarray(data, dtype=float)


class StaticScanStateLayer:
    def __init__(self, model, feature_cols, target_cols, config):
        self.model = model; self.feature_cols = tuple(feature_cols)
        self.target_cols = tuple(target_cols); self.config = config
    def predict(self, data):
        Y = self.model.predict(_X(data, self.feature_cols))
        return Y[:, 0], Y[:, 1]


class DynamicScanStateLayer:
    def __init__(self, model, feature_cols, target_cols, config):
        self.model = model; self.feature_cols = tuple(feature_cols)
        self.target_cols = tuple(target_cols); self.config = config
    def predict(self, data):
        Y = self.model.predict(_X(data, self.feature_cols))
        if Y.shape[1] == 3:
            z = np.zeros_like(Y[:, 0])
            return Y[:, 0], Y[:, 1], Y[:, 2], z
        return Y[:, 0], Y[:, 1], Y[:, 2], Y[:, 3]


class PureDataLayer:
    def __init__(self, model, feature_cols, target_cols, config):
        self.model = model; self.feature_cols = tuple(feature_cols)
        self.target_cols = tuple(target_cols); self.config = config
    def predict(self, data):
        Y = self.model.predict(_X(data, self.feature_cols))
        return Y[:, 0], Y[:, 1], Y[:, 2]


def _fit_layer(df, cfg, layer_cls, extra_mask=None):
    _require_pandas(df)
    m = _finite_training_mask(df, cfg.feature_cols, cfg.target_cols)
    if extra_mask is not None:
        m &= np.asarray(extra_mask, dtype=bool)
    dff = _sample_df(df.loc[m].copy(), cfg.max_train_points, cfg.random_state)
    X = dff[list(cfg.feature_cols)].to_numpy(dtype=float)
    Y = dff[list(cfg.target_cols)].to_numpy(dtype=float)
    model = _make_regressor(cfg.model_type, cfg)
    model.fit(X, Y)
    return layer_cls(model, cfg.feature_cols, cfg.target_cols, asdict(cfg)), {
        "n_train": int(len(dff)), "feature_cols": cfg.feature_cols,
        "target_cols": cfg.target_cols, "model_type": cfg.model_type,
    }


def fit_static_scan_state_layer(df_train, cfg=None, extra_mask=None):
    return _fit_layer(df_train, cfg or StaticScanStateConfig(), StaticScanStateLayer, extra_mask)


def fit_dynamic_scan_state_layer(df_train, cfg=None, extra_mask=None):
    return _fit_layer(df_train, cfg or DynamicScanStateConfig(), DynamicScanStateLayer, extra_mask)


def fit_pure_data_layer(df_train, cfg=None, extra_mask=None):
    return _fit_layer(df_train, cfg or PureDataConfig(), PureDataLayer, extra_mask)


# -----------------------------------------------------------------------------
# Targets and prediction
# -----------------------------------------------------------------------------

def add_static_predictions(df, static_layer):
    _require_pandas(df)
    out = df.copy()
    dA0, dphi0 = static_layer.predict(out)
    out["delta_A0"] = dA0
    out["delta_phi0"] = dphi0
    out["A_static_orig"] = out["A_fd"].to_numpy(float) + dA0
    out["phi_static_orig"] = out["phi_fd"].to_numpy(float) + dphi0
    return out


def add_static_and_dynamic_targets(
    df_base, static_layer, fd_cache, *, phase_period_deg=360.0,
    use_target_deff_for_dynamic_targets=True,
):
    _require_pandas(df_base)
    df = add_static_predictions(df_base, static_layer)
    df["delta_d_dyn_target"] = df["delta_d_from_A"].to_numpy(float)
    df["delta_h_dyn_target"] = df["exp_h"].to_numpy(float) - df["h_dt"].to_numpy(float)

    if use_target_deff_for_dynamic_targets:
        d_eff = df["d_dt"].to_numpy(float) + df["delta_d_dyn_target"].to_numpy(float)
        df["d_eff_target"] = d_eff
        Aeff = np.empty(len(df)); peff = np.empty(len(df))
        for (di, drive), idx in df.groupby(["di", "drive_nm"]).groups.items():
            idx = np.asarray(list(idx), dtype=int)
            fd = fd_cache.get(float(drive), drive_index=int(di))
            Aeff[idx], peff[idx] = interp_fd_table(fd, d_eff[idx])

        tmp = df.copy()
        tmp["d_dt"] = d_eff
        tmp["A_fd"] = Aeff
        tmp["phi_fd"] = peff
        dA0_eff, dphi0_eff = static_layer.predict(tmp)

        df["A_fd_eff_target"] = Aeff
        df["phi_fd_eff_target"] = peff
        df["A_static_eff_target"] = Aeff + dA0_eff
        df["phi_static_eff_target"] = peff + dphi0_eff
        A_base = df["A_static_eff_target"].to_numpy(float)
        phi_base = df["phi_static_eff_target"].to_numpy(float)
    else:
        df["d_eff_target"] = df["d_dt"].to_numpy(float)
        df["A_static_eff_target"] = df["A_static_orig"].to_numpy(float)
        df["phi_static_eff_target"] = df["phi_static_orig"].to_numpy(float)
        A_base = df["A_static_orig"].to_numpy(float)
        phi_base = df["phi_static_orig"].to_numpy(float)

    df["delta_A_dyn_target"] = df["exp_A"].to_numpy(float) - A_base
    df["delta_phi_dyn_target"] = wrap_phase_diff_deg(
        df["exp_phi"].to_numpy(float) - phi_base, period=phase_period_deg)
    return df


def predict_static_on_dataframe(df, static_layer):
    d = add_static_predictions(df, static_layer)
    return {"A_pred": d["A_static_orig"].to_numpy(float),
            "phi_pred": d["phi_static_orig"].to_numpy(float),
            "h_pred": d["h_dt"].to_numpy(float)}


def predict_pure_on_dataframe(df, pure_layer):
    A, phi, h = pure_layer.predict(df)
    return {"A_pred": A, "phi_pred": phi, "h_pred": h}


def predict_hybrid_on_dataframe(
    df, *, fd_cache, static_layer, dynamic_layer, phase_period_deg=360.0, static_at_deff=True
):
    d0 = add_static_predictions(df, static_layer)
    dd, dA_dyn, dphi_dyn, dh_dyn = dynamic_layer.predict(d0)
    d_eff = d0["d_dt"].to_numpy(float) + dd
    Aeff = np.empty(len(d0)); peff = np.empty(len(d0))
    for (di, drive), idx in d0.groupby(["di", "drive_nm"]).groups.items():
        idx = np.asarray(list(idx), dtype=int)
        fd = fd_cache.get(float(drive), drive_index=int(di))
        Aeff[idx], peff[idx] = interp_fd_table(fd, d_eff[idx])
    if static_at_deff:
        tmp = d0.copy()
        tmp["d_dt"] = d_eff; tmp["A_fd"] = Aeff; tmp["phi_fd"] = peff
        dA0, dphi0 = static_layer.predict(tmp)
    else:
        dA0 = d0["delta_A0"].to_numpy(float)
        dphi0 = d0["delta_phi0"].to_numpy(float)
    return {
        "d_eff": d_eff, "A_eff": Aeff, "phi_eff": peff,
        "delta_d_dyn": dd, "delta_A_dyn": dA_dyn,
        "delta_phi_dyn": dphi_dyn, "delta_h_dyn": dh_dyn,
        "A_pred": Aeff + dA0 + dA_dyn,
        "phi_pred": peff + dphi0 + dphi_dyn,
        "h_pred": d0["h_dt"].to_numpy(float) + dh_dyn,
    }


# -----------------------------------------------------------------------------
# Evaluation
# -----------------------------------------------------------------------------

def _mae(x):
    x = np.asarray(x, dtype=float); x = x[np.isfinite(x)]
    return np.nan if x.size == 0 else float(np.mean(np.abs(x)))

def _rmse(x):
    x = np.asarray(x, dtype=float); x = x[np.isfinite(x)]
    return np.nan if x.size == 0 else float(np.sqrt(np.mean(x*x)))

def _r2(y, yp):
    y = np.asarray(y, dtype=float); yp = np.asarray(yp, dtype=float)
    m = np.isfinite(y) & np.isfinite(yp)
    if np.sum(m) < 3: return np.nan
    yy, pp = y[m], yp[m]
    den = np.sum((yy - np.mean(yy))**2)
    return np.nan if den <= 0 else float(1 - np.sum((pp - yy)**2) / den)


def summarize_prediction_errors(df, pred, *, phase_period_deg=360.0, model_name="model"):
    eA = np.asarray(pred["A_pred"]) - df["exp_A"].to_numpy(float)
    eph = wrap_phase_diff_deg(np.asarray(pred["phi_pred"]) - df["exp_phi"].to_numpy(float), phase_period_deg)
    eh = np.asarray(pred["h_pred"]) - df["exp_h"].to_numpy(float)
    return {
        "model": model_name, "n": int(len(df)),
        "A_mae": _mae(eA), "A_rmse": _rmse(eA), "A_r2": _r2(df["exp_A"], pred["A_pred"]),
        "phi_mae": _mae(eph), "phi_rmse": _rmse(eph), "phi_r2": _r2(df["exp_phi"], pred["phi_pred"]),
        "h_mae": _mae(eh), "h_rmse": _rmse(eh), "h_r2": _r2(df["exp_h"], pred["h_pred"]),
    }


def evaluate_scan_state_models(
    df_test, *, fd_cache=None, static_layer=None, dynamic_layer=None,
    pure_layer=None, phase_period_deg=360.0
):
    _require_pandas(df_test)
    rows = []
    rows.append(summarize_prediction_errors(
        df_test,
        {"A_pred": df_test["A_fd"].to_numpy(float),
         "phi_pred": df_test["phi_fd"].to_numpy(float),
         "h_pred": df_test["h_dt"].to_numpy(float)},
        phase_period_deg=phase_period_deg,
        model_name="FD_only",
    ))
    if pure_layer is not None:
        rows.append(summarize_prediction_errors(
            df_test, predict_pure_on_dataframe(df_test, pure_layer),
            phase_period_deg=phase_period_deg, model_name="pure_data"))
    if static_layer is not None:
        rows.append(summarize_prediction_errors(
            df_test, predict_static_on_dataframe(df_test, static_layer),
            phase_period_deg=phase_period_deg, model_name="FD_plus_static"))
    if static_layer is not None and dynamic_layer is not None:
        if fd_cache is None:
            raise ValueError("fd_cache required for hybrid prediction.")
        rows.append(summarize_prediction_errors(
            df_test,
            predict_hybrid_on_dataframe(df_test, fd_cache=fd_cache,
                                        static_layer=static_layer,
                                        dynamic_layer=dynamic_layer,
                                        phase_period_deg=phase_period_deg),
            phase_period_deg=phase_period_deg,
            model_name="FD_plus_static_dynamic"))
    return pd.DataFrame(rows)


def residual_summary(df, cols=None):
    _require_pandas(df)
    if cols is None:
        cols = ["delta_A_raw", "delta_phi_raw", "delta_d_from_A",
                "delta_A_dyn_target", "delta_phi_dyn_target",
                "delta_d_dyn_target", "delta_h_dyn_target"]
        cols = [c for c in cols if c in df.columns]
    rows = []
    for c in cols:
        x = df[c].to_numpy(float); x = x[np.isfinite(x)]
        if x.size:
            rows.append({"column": c, "n": int(x.size), "mean": float(np.mean(x)),
                         "std": float(np.std(x)), "mad": robust_mad(x),
                         "p05": float(np.percentile(x, 5)),
                         "p50": float(np.percentile(x, 50)),
                         "p95": float(np.percentile(x, 95))})
    return pd.DataFrame(rows)


def split_condition_keys(df, test_frac=0.2, seed=0):
    _require_pandas(df)
    keys = np.array(sorted(df["cond_key"].unique()))
    rng = np.random.default_rng(seed)
    perm = rng.permutation(len(keys))
    nt = int(round(len(keys) * float(test_frac)))
    return set(keys[perm[nt:]]), set(keys[perm[:nt]])


# -----------------------------------------------------------------------------
# Apply layers to one new DT output
# -----------------------------------------------------------------------------

def _state_to_df(state, controls, direction):
    _require_pandas()
    state = add_history_features(state)
    n = len(state["A_fd"])
    speed = float(controls["scan_speed_hat"])
    drive = float(controls["drive_nm"])
    setp = float(controls["setpoint"])
    Iexp = float(controls.get("I_exp", np.nan))
    Psim = float(controls["P_sim"])
    Isim = float(controls["I_sim"])
    sign = 1.0 if direction == "trace" else -1.0
    df = pd.DataFrame({
        "cond_key": ["new"] * n,
        "si": np.full(n, -1, dtype=int),
        "di": np.full(n, int(controls.get("di", 0)), dtype=int),
        "spi": np.full(n, -1, dtype=int),
        "gi": np.full(n, -1, dtype=int),
        "scan_speed_hat": np.full(n, speed),
        "log_scan_speed": np.full(n, np.log10(max(speed, 1e-30))),
        "drive_nm": np.full(n, drive),
        "setpoint": np.full(n, setp),
        "I_exp": np.full(n, Iexp),
        "log_I_exp": np.full(n, np.log10(max(Iexp, 1e-30))),
        "P_sim": np.full(n, Psim),
        "I_sim": np.full(n, Isim),
        "log_P_sim": np.full(n, np.log10(max(Psim, 1e-30))),
        "log_I_sim": np.full(n, np.log10(max(Isim, 1e-30))),
        "direction": [direction] * n,
        "direction_sign": np.full(n, sign),
        "x_exp_norm": np.linspace(0.0, 1.0, n),
    })
    for k, v in state.items():
        df[k] = np.asarray(v, dtype=float).ravel()[:n]
    return df


def predict_corrected_channels_for_out(
    out, *, controls, fd_table, static_layer, dynamic_layer,
    phase_period_deg=360.0, static_at_deff=True
):
    states = extract_dt_state_from_out(out, fd_table=fd_table)
    di = int(controls.get("di", 0))
    drive_key = round(float(controls["drive_nm"]), 8)
    fd_cache = FDTableCache(fd_tables={di: fd_table, drive_key: fd_table})
    ans = {}
    for direction in ["trace", "retrace"]:
        df = _state_to_df(states[direction], controls, direction)
        pred = predict_hybrid_on_dataframe(
            df, fd_cache=fd_cache, static_layer=static_layer,
            dynamic_layer=dynamic_layer, phase_period_deg=phase_period_deg,
            static_at_deff=static_at_deff,
        )
        ans[direction] = {
            "h_dt": df["h_dt"].to_numpy(float),
            "z_dt": df["z_dt"].to_numpy(float),
            "d_dt": df["d_dt"].to_numpy(float),
            "A_fd": df["A_fd"].to_numpy(float),
            "phi_fd": df["phi_fd"].to_numpy(float),
            "d_eff": pred["d_eff"],
            "A_pred": pred["A_pred"],
            "phi_pred": pred["phi_pred"],
            "h_pred": pred["h_pred"],
            "delta_d_dyn": pred["delta_d_dyn"],
            "delta_A_dyn": pred["delta_A_dyn"],
            "delta_phi_dyn": pred["delta_phi_dyn"],
            "delta_h_dyn": pred["delta_h_dyn"],
        }
    return ans
