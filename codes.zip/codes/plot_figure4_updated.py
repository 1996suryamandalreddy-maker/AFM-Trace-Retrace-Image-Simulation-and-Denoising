from __future__ import annotations

import json
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import gridspec
from matplotlib.lines import Line2D


PALETTE = {
    "ink": "#1f2933",
    "muted": "#667085",
    "blue": "#2A6FBB",
    "teal": "#1B9E8A",
    "orange": "#D97706",
    "red": "#C2410C",
    "purple": "#7C3AED",
    "grey": "#9CA3AF",
    "light": "#F3F4F6",
}


def setup_style() -> None:
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
            "font.size": 6.9,
            "axes.labelsize": 7.0,
            "axes.titlesize": 7.2,
            "xtick.labelsize": 6.1,
            "ytick.labelsize": 6.1,
            "legend.fontsize": 6.0,
            "axes.linewidth": 0.55,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "xtick.major.width": 0.55,
            "ytick.major.width": 0.55,
            "xtick.major.size": 2.5,
            "ytick.major.size": 2.5,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "savefig.dpi": 600,
        }
    )


def panel_label(ax, label: str, x: float = -0.115, y: float = 1.10) -> None:
    ax.text(
        x,
        y,
        label,
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontweight="bold",
        fontsize=9.4,
        color="black",
    )


def save_pub(fig, out_dir, stem: str) -> dict[str, str]:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = {
        "png": out_dir / f"{stem}.png",
        "pdf": out_dir / f"{stem}.pdf",
        "tiff": out_dir / f"{stem}.tiff",
    }
    fig.savefig(paths["png"], bbox_inches="tight", dpi=600, facecolor="white")
    fig.savefig(paths["pdf"], bbox_inches="tight", facecolor="white")
    fig.savefig(paths["tiff"], bbox_inches="tight", dpi=600, facecolor="white")
    return {k: str(v) for k, v in paths.items()}


def _center(arr, trim: int = 10):
    arr = np.asarray(arr, float).copy()
    if arr.ndim == 1:
        return arr - np.nanmean(arr[trim:-trim])
    for i in range(arr.shape[0]):
        arr[i] = arr[i] - np.nanmean(arr[i, trim:-trim])
    return arr


def _as_dict(bundle):
    if isinstance(bundle, dict):
        return dict(bundle)
    if isinstance(bundle, (str, Path)):
        z = np.load(bundle, allow_pickle=False)
        out = {k: z[k] for k in z.files}
    else:
        out = {k: bundle[k] for k in bundle.files}
    if "oracle_PI" not in out and "oracle_cond" in out:
        oracle = {}
        for i, c in enumerate(out["oracle_cond"]):
            oracle[int(c)] = {
                "P": float(out["oracle_P"][i]),
                "I": float(out["oracle_I"][i]),
                "log10_P": float(out["oracle_log10P"][i]),
                "log10_I": float(out["oracle_log10I"][i]),
            }
        out["oracle_PI"] = oracle
    return out


def plot_figure4(bundle, save_to=None, stem: str = "figure_4_cali_PI_fit_nature"):
    """Render the updated publication-ready Figure 4.

    Parameters
    ----------
    bundle
        Either a dict, an opened np.load object, or a path to
        figure_45_data_bundle.npz.
    save_to
        Directory to save PNG/PDF/TIFF. If None, the figure is returned only.
    stem
        Output filename stem when save_to is provided.
    """
    setup_style()
    bundle = _as_dict(bundle)

    traces_exp = bundle["traces_exp"]
    h_truth = bundle["h_truth"]
    fit_idx = np.asarray(bundle["fit_idx"], int)
    test_idx = np.asarray(bundle["test_idx"], int)
    dt_PI = bundle["dt_PI"]
    drive_exp = bundle["drive_exp"]
    setpoint_exp = bundle["setpoint_exp"]
    igain_exp = bundle.get("igain_exp", np.full(traces_exp.shape[0], np.nan))
    P_all = bundle["P_all"]
    I_all = bundle["I_all"]
    clean_pick = np.asarray(bundle["clean_pick"], int)
    q_exp = bundle["q_exp"]
    q_PI = bundle["q_PI"]
    oracle = bundle["oracle_PI"]

    has_demo = "demo_cond_idx" in bundle and np.asarray(bundle["demo_cond_idx"]).size == 3
    ex_bytes = bundle.get("three_examples_json", np.array(""))
    ex_text = str(ex_bytes) if np.asarray(ex_bytes).size else ""
    try:
        examples = json.loads(ex_text) if ex_text else []
    except Exception:
        examples = []

    fig = plt.figure(figsize=(7.2, 7.65), constrained_layout=False)
    gs = gridspec.GridSpec(
        3,
        6,
        figure=fig,
        height_ratios=[0.88, 1.05, 0.95],
        width_ratios=[1, 1, 1, 1, 1, 1],
    )
    fig.subplots_adjust(
        left=0.07,
        right=0.965,
        bottom=0.085,
        top=0.895,
        wspace=0.74,
        hspace=0.66,
    )
    fig.suptitle(
        "PI-loop calibration transfers experimental scan behaviour to the digital twin",
        x=0.07,
        y=0.966,
        ha="left",
        fontsize=9.2,
        fontweight="bold",
    )
    fig.text(
        0.07,
        0.936,
        "Far-field grating geometry constrains the controller fit; held-out controls test whether the calibrated PI map preserves trace-retrace quality.",
        ha="left",
        va="top",
        fontsize=6.4,
        color=PALETTE["muted"],
    )

    def _style_trace_ax(ax, ylabel=False):
        ax.set_xlabel("pixel")
        ax.set_ylabel("height (nm)" if ylabel else "")
        ax.axhline(0, color="0.86", lw=0.45, zorder=0)
        ax.margins(x=0.02)

    ax = fig.add_subplot(gs[0, 0:2])
    panel_label(ax, "a")
    for k, ci in enumerate(clean_pick[:7]):
        ax.plot(
            _center(traces_exp[int(ci), 0]),
            lw=0.55,
            color=PALETTE["grey"],
            alpha=0.55,
            label="clean experimental traces" if k == 0 else None,
        )
    ax.plot(
        _center(h_truth),
        color=PALETTE["blue"],
        lw=1.75,
        label=r"synthetic $h_{\mathrm{truth}}$",
    )
    _style_trace_ax(ax, ylabel=True)
    ax.set_title("Synthetic target follows the grating envelope")
    ax.legend(frameon=False, loc="lower left", fontsize=5.8, handlelength=1.8)
    ax.set_ylim(-135, 130)

    ax = fig.add_subplot(gs[0, 2:4])
    panel_label(ax, "b")
    P_grid = bundle["loss_P_grid"]
    I_grid = bundle["loss_I_grid"]
    L = bundle["loss_L"]
    cond_for_surf = int(bundle["loss_cond"])
    logL = np.log10(np.maximum(L, 1e-12))
    im = ax.pcolormesh(
        np.log10(P_grid),
        np.log10(I_grid),
        logL.T,
        shading="auto",
        cmap="magma_r",
        rasterized=True,
    )
    levels = np.nanquantile(logL, [0.2, 0.4, 0.6, 0.8])
    ax.contour(
        np.log10(P_grid),
        np.log10(I_grid),
        logL.T,
        levels=levels,
        colors="white",
        linewidths=0.35,
        alpha=0.55,
    )
    cb = fig.colorbar(im, ax=ax, fraction=0.048, pad=0.018)
    cb.set_label("")
    cb.ax.set_title(r"$\log_{10}$ loss", fontsize=5.5, pad=2)
    p_star = oracle[cond_for_surf]["log10_P"]
    i_star = oracle[cond_for_surf]["log10_I"]
    ax.plot(
        p_star,
        i_star,
        marker="*",
        color=PALETTE["teal"],
        markersize=9.5,
        markeredgecolor="white",
        markeredgewidth=0.65,
    )
    ax.text(
        0.03,
        0.05,
        f"local optimum\nP={oracle[cond_for_surf]['P']:.2g}, I={oracle[cond_for_surf]['I']:.2g}",
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=5.8,
        color=PALETTE["ink"],
        bbox=dict(boxstyle="round,pad=0.18", fc="white", ec="none", alpha=0.78),
    )
    ax.set_xlabel(r"$\log_{10} P$")
    ax.set_ylabel(r"$\log_{10} I$")
    ax.set_title(f"Local PI loss surface (condition {cond_for_surf})")

    ax = fig.add_subplot(gs[0, 4:6])
    panel_label(ax, "c")
    fit_use = [int(i) for i in fit_idx if int(i) in oracle]
    fit_log10P = np.array([oracle[i]["log10_P"] for i in fit_use])
    fit_log10I = np.array([oracle[i]["log10_I"] for i in fit_use])
    pred_logP = np.log10(np.array([P_all[i] for i in fit_use]))
    pred_logI = np.log10(np.array([I_all[i] for i in fit_use]))
    ax.scatter(
        fit_log10P,
        pred_logP,
        s=16,
        color=PALETTE["blue"],
        edgecolor="white",
        lw=0.35,
        label="P",
    )
    ax.scatter(
        fit_log10I,
        pred_logI,
        s=17,
        color=PALETTE["orange"],
        marker="D",
        edgecolor="white",
        lw=0.35,
        label="I",
    )
    lo = float(min(fit_log10P.min(), fit_log10I.min(), pred_logP.min(), pred_logI.min()))
    hi = float(max(fit_log10P.max(), fit_log10I.max(), pred_logP.max(), pred_logI.max()))
    pad = 0.12 * (hi - lo)
    ax.plot([lo - pad, hi + pad], [lo - pad, hi + pad], color=PALETTE["muted"], lw=0.65, ls="--")
    rP = np.corrcoef(fit_log10P, pred_logP)[0, 1]
    rI = np.corrcoef(fit_log10I, pred_logI)[0, 1]
    ax.text(0.04, 0.05, f"r(P)={rP:.2f}\nr(I)={rI:.2f}", transform=ax.transAxes, fontsize=5.8, color=PALETTE["muted"])
    ax.set_xlim(lo - pad, hi + pad)
    ax.set_ylim(lo - pad, hi + pad)
    ax.set_xlabel(r"local-fit $\log_{10}$ gain")
    ax.set_ylabel(r"predicted $\log_{10}$ gain", labelpad=1)
    ax.set_title("Ridge PI map across controls")
    ax.legend(frameon=False, fontsize=5.8, loc="upper left", handlelength=1.0)

    if has_demo:
        regimes = [
            ("small I: hysteresis", PALETTE["orange"]),
            ("optimal I: aligned", PALETTE["blue"]),
            ("large I: oscillatory", PALETTE["red"]),
        ]
        demo_idx = bundle["demo_cond_idx"]
        demo_tr = bundle["demo_sim_tr"]
        demo_rt = bundle["demo_sim_rt"]
        demo_PI = bundle["demo_PI"]
        row_axes = []
        for col, ((ttl, c), ci, P, I) in enumerate(
            zip(regimes, [int(demo_idx[k]) for k in range(3)], demo_PI[:, 0], demo_PI[:, 1])
        ):
            ax = fig.add_subplot(gs[1, 2 * col : 2 * col + 2])
            row_axes.append(ax)
            panel_label(ax, "def"[col])
            ax.plot(_center(traces_exp[ci, 0]), color=PALETTE["ink"], lw=0.9)
            ax.plot(_center(traces_exp[ci, 1]), color=PALETTE["ink"], lw=0.85, ls=":", alpha=0.86)
            ax.plot(_center(np.asarray(demo_tr[col])), color=c, lw=1.05)
            ax.plot(_center(np.asarray(demo_rt[col])), color=c, lw=0.95, ls=":", alpha=0.86)
            _style_trace_ax(ax, ylabel=(col == 0))
            ax.set_title(ttl)
            ax.text(
                0.03,
                0.96,
                f"cond {ci}; Iexp={float(igain_exp[ci]):.0f}\nP*={P:.2g}, I*={I:.2g}",
                transform=ax.transAxes,
                ha="left",
                va="top",
                fontsize=5.55,
                color=PALETTE["ink"],
                bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none", alpha=0.72),
            )
        for ax in row_axes:
            ax.set_ylim(-165, 165)

    ax = fig.add_subplot(gs[2, 0:2])
    panel_label(ax, "g")
    finite_fit = np.isfinite(q_exp[fit_idx]) & np.isfinite(q_PI[fit_idx])
    finite_test = np.isfinite(q_exp[test_idx]) & np.isfinite(q_PI[test_idx])
    ax.scatter(q_exp[fit_idx][finite_fit], q_PI[fit_idx][finite_fit], s=15, color=PALETTE["blue"], edgecolor="white", lw=0.35, label=f"fit (n={finite_fit.sum()})")
    ax.scatter(q_exp[test_idx][finite_test], q_PI[test_idx][finite_test], s=24, color=PALETTE["orange"], marker="D", edgecolor="white", lw=0.35, label=f"held-out (n={finite_test.sum()})")
    qvals = np.concatenate([q_exp[fit_idx], q_PI[fit_idx], q_exp[test_idx], q_PI[test_idx]])
    qmax = max(float(np.nanpercentile(qvals, 95)), 25.0)
    ax.plot([0, qmax], [0, qmax], color=PALETTE["muted"], lw=0.65, ls="--")
    mae_hold = float(np.nanmean(np.abs(q_exp[test_idx] - q_PI[test_idx])))
    ax.text(0.04, 0.92, f"held-out MAE = {mae_hold:.1f} nm", transform=ax.transAxes, ha="left", va="top", fontsize=5.8, color=PALETTE["ink"])
    ax.set_xlim(0, qmax)
    ax.set_ylim(0, qmax)
    ax.set_xlabel("experimental scan quality (nm)")
    ax.set_ylabel("DT-simulated scan quality (nm)")
    ax.set_title("Held-out scan-quality recovery")
    ax.legend(frameon=False, fontsize=5.8, loc="lower right", handlelength=1.0)

    ax = fig.add_subplot(gs[2, 2:4])
    panel_label(ax, "h")
    names_h = ["small I", "optimal I", "large I"]
    colors = [PALETTE["orange"], PALETTE["blue"], PALETTE["red"]]
    stats = ["trrt", "hf_tr", "gm_tr"]
    stat_labels = ["trace-retrace\nRMSE", "high-frequency\nresidual", "gradient\nMAD"]
    x_pos = np.arange(len(stats))
    w = 0.22
    if examples:
        for k, ex in enumerate(examples):
            sim = [ex["sim_sig"][s] for s in stats]
            exp = [ex["exp_sig"][s] for s in stats]
            xpos = x_pos + (k - 1) * w * 1.08
            ax.bar(xpos, np.log1p(sim), width=w, color=colors[k], alpha=0.58)
            ax.scatter(xpos, np.log1p(exp), color=colors[k], edgecolor="black", linewidth=0.7, s=21, zorder=3)
    ax.set_xticks(x_pos, stat_labels)
    ax.set_ylabel(r"$\log(1 + \mathrm{metric})$")
    ax.set_title("Regime-specific behavioural signatures")
    for k, (name, c) in enumerate(zip(names_h, colors)):
        ax.text(0.03 + 0.28 * k, 0.98, name, transform=ax.transAxes, ha="left", va="top", fontsize=5.6, color=c)
    ax.scatter([], [], color="white", edgecolor="black", s=21, label="experiment")
    ax.bar([], [], color="0.7", alpha=0.58, label="DT")
    ax.legend(frameon=False, loc="upper right", fontsize=5.5, handlelength=0.8)

    ax = fig.add_subplot(gs[2, 4:6])
    panel_label(ax, "i")
    if examples:
        comps = np.array([[ex["shape_mse"], ex["trrt_term"], ex["hf_term"], ex["grad_term"]] for ex in examples])
        weights = np.array([1.0, 80.0, 300.0, 300.0])
        frac = comps * weights
        frac = frac / (np.nansum(frac, axis=1, keepdims=True) + 1e-12)
        labels = ["shape MSE", "trace-retrace", "HF residual", "gradient MAD"]
        bar_colors = [PALETTE["grey"], PALETTE["teal"], PALETTE["orange"], PALETTE["purple"]]
        bottom = np.zeros(len(examples))
        x = np.arange(len(examples))
        for k in range(4):
            ax.bar(x, frac[:, k], bottom=bottom, color=bar_colors[k], width=0.68, label=labels[k], alpha=0.92)
            bottom += frac[:, k]
        ax.set_xticks(x, ["small\nI", "optimal\nI", "large\nI"])
        ax.set_ylim(0, 1.0)
        ax.set_ylabel("fraction of weighted loss")
        ax.set_title("Loss terms emphasize failure modes")
        ax.legend(frameon=False, fontsize=5.45, loc="center left", bbox_to_anchor=(1.01, 0.50), handlelength=1.0)

    handles = [
        Line2D([0], [0], color=PALETTE["ink"], lw=1.0, label="experiment trace"),
        Line2D([0], [0], color=PALETTE["ink"], lw=0.9, ls=":", label="experiment retrace"),
        Line2D([0], [0], color=PALETTE["orange"], lw=1.0, label="DT small I"),
        Line2D([0], [0], color=PALETTE["blue"], lw=1.0, label="DT optimal I"),
        Line2D([0], [0], color=PALETTE["red"], lw=1.0, label="DT large I"),
    ]
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.50, 0.014), ncol=5, frameon=False, fontsize=5.9, handlelength=1.5, handletextpad=0.45, columnspacing=1.05)
    fig.text(0.965, 0.036, "Dashed traces indicate retrace; diagonal in panel g marks perfect quality prediction.", ha="right", va="bottom", fontsize=5.55, color=PALETTE["muted"])

    if save_to is not None:
        paths = save_pub(fig, save_to, stem)
        print("Saved Figure 4:", paths["png"])
    return fig


def plot_figure_4(bundle, save_to=None, stem: str = "figure_4_cali_PI_fit_nature"):
    """Compatibility alias for notebooks that use plot_figure_4()."""
    return plot_figure4(bundle, save_to=save_to, stem=stem)

