"""
fd_priors.py
============

Turn a standard `params` dict (handbook / nominal cantilever + sample values)
into a usable Bayesian-flavored prior for the FD calibration:

    1. parameter GRIDS centered on the prior  (for surrogate library build)
    2. parameter BOUNDS for DE / minimize
    3. initial guess X0 for local optimizers
    4. optional Gaussian PRIOR PENALTY added to the loss

Conventions
-----------
- For parameters known on a log scale (E_star, H), the prior is log-normal:
        log10(theta) ~ Normal(log10(mu), sigma_dex)
  with sigma expressed in *decades* (e.g. 0.3 dex = factor of 2 std-dev).
- For parameters known on a linear scale (a0, R, Q), the prior is normal:
        theta ~ Normal(mu, sigma_factor * mu)
  with sigma_factor as a fractional width (e.g. 0.3 = ±30% std-dev).
- For aux knobs (phase_offset_deg, drive_scale), the prior is normal with an
  absolute sigma in deg or unitless ratio.

Usage
-----
    from fd_priors import make_default_prior

    prior = make_default_prior(params)        # uses your handbook params dict

    grids   = prior.grids(("E_star","H","a0"), n_points=6, n_sigma=2.5)
    bounds  = prior.bounds(("E_star","H","a0","phase_offset_deg"), n_sigma=3.0)
    x0      = prior.x0(    ("E_star","H","a0","phase_offset_deg"))

    # build library centered on the prior:
    lib = build_fd_param_library(..., E_grid=grids["E_star"],
                                  H_grid=grids["H"], a0_grid=grids["a0"], ...)

    # optionally add a soft penalty to the calibrator loss:
    cal = FDSurrogateCalibrator(lib, fd_curves, cfg)
    cal.loss = prior.wrap_loss(cal.loss, weight=0.05)

    # warm-started local fit (no DE needed if priors are good):
    res = cal.fit(bounds=bounds, x0=x0, method="L-BFGS-B")
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Optional, Sequence, Tuple

import numpy as np


# ============================================================
# 1) DEFAULT PRIOR WIDTHS (overridable)
# ============================================================
# Log-scale standard deviations expressed in DECADES (dex).
# 0.30 dex = factor 2 spread,  0.18 dex = factor 1.5 spread.
DEFAULT_LOG_SIGMA_DEX = {
    "E_star": 0.30,    # ±factor 2:   sample modulus is often uncertain by 2x
    "H":      0.30,    # Hamaker varies wildly; broad prior
}

# Linear-scale fractional widths (sigma / mu).
DEFAULT_LIN_SIGMA_FRAC = {
    "a0": 0.30,        # ±30%
    "R":  0.20,        # ±20% (tip radius from manufacturer)
    "Q":  0.10,        # ±10% (Q from thermal tune is usually tight)
    "k":  0.15,        # ±15% (cantilever spring constant)
    "f0": 0.01,        # ±1% (f0 well known from frequency sweep)
}

# Absolute (unitful) sigmas for auxiliary knobs.
DEFAULT_ABS_SIGMA = {
    "phase_offset_deg": 8.0,    # deg
    "drive_scale":      0.10,   # unitless multiplicative factor
}

# Which parameters live on a log scale (for grid layout & prior shape).
DEFAULT_LOG_SCALE = {
    "E_star": True,
    "H":      True,
    "a0":     False,
    "R":      False,
    "Q":      False,
    "k":      False,
    "f0":     False,
    "phase_offset_deg": False,
    "drive_scale":      False,
}


# ============================================================
# 2) PRIOR DATA CLASS
# ============================================================
@dataclass
class MaterialPrior:
    """
    Lightweight container for prior beliefs over the calibration parameters.

    Attributes
    ----------
    values : Dict[str, float]
        Prior mean (point estimate) for each parameter.
    log_sigma_dex : Dict[str, float]
        Std-dev in decades, used for log-scaled parameters.
    lin_sigma_frac : Dict[str, float]
        Fractional std-dev (sigma/mu) for linear-scaled positive parameters.
    abs_sigma : Dict[str, float]
        Absolute std-dev for auxiliary knobs (phase_offset_deg, drive_scale).
    log_scale : Dict[str, bool]
        Whether the parameter lives on a log scale.
    """
    values: Dict[str, float]
    log_sigma_dex: Dict[str, float] = field(default_factory=dict)
    lin_sigma_frac: Dict[str, float] = field(default_factory=dict)
    abs_sigma: Dict[str, float] = field(default_factory=dict)
    log_scale: Dict[str, bool] = field(default_factory=dict)

    # ---- internals ----
    def _is_log(self, name: str) -> bool:
        return bool(self.log_scale.get(name, DEFAULT_LOG_SCALE.get(name, False)))

    def _sigma(self, name: str) -> float:
        """Return std-dev *in the natural coordinates of the parameter*.

        For log-scale parameters this is in decades.
        For linear positive parameters it's an absolute value (frac * mu).
        For aux parameters it's an absolute value (already in deg / unitless).
        """
        if self._is_log(name):
            return float(self.log_sigma_dex.get(name, DEFAULT_LOG_SIGMA_DEX.get(name, 0.3)))
        if name in DEFAULT_ABS_SIGMA or name in self.abs_sigma:
            return float(self.abs_sigma.get(name, DEFAULT_ABS_SIGMA.get(name, 1.0)))
        mu = float(self.values[name])
        frac = float(self.lin_sigma_frac.get(name, DEFAULT_LIN_SIGMA_FRAC.get(name, 0.2)))
        return frac * abs(mu)

    # ---- accessor 1:  initial guess ----
    def x0(self, fit_keys: Sequence[str]) -> Dict[str, float]:
        return {k: float(self.values[k]) for k in fit_keys}

    # ---- accessor 2:  bounds ----
    def bounds(self, fit_keys: Sequence[str], n_sigma: float = 3.0,
               clip_positive: bool = True) -> Dict[str, Tuple[float, float]]:
        out: Dict[str, Tuple[float, float]] = {}
        for k in fit_keys:
            mu = float(self.values[k])
            sig = self._sigma(k)
            if self._is_log(k):
                lo = float(10 ** (np.log10(mu) - n_sigma * sig))
                hi = float(10 ** (np.log10(mu) + n_sigma * sig))
            else:
                lo = mu - n_sigma * sig
                hi = mu + n_sigma * sig
            if clip_positive and k in ("E_star", "H", "a0", "R", "Q", "k", "f0"):
                lo = max(lo, 1e-30)
            out[k] = (float(lo), float(hi))
        return out

    # ---- accessor 3:  surrogate library grids ----
    def grids(self, fit_keys: Sequence[str], n_points: int = 6,
              n_sigma: float = 2.5) -> Dict[str, np.ndarray]:
        out: Dict[str, np.ndarray] = {}
        for k in fit_keys:
            mu = float(self.values[k])
            sig = self._sigma(k)
            if self._is_log(k):
                lo = 10 ** (np.log10(mu) - n_sigma * sig)
                hi = 10 ** (np.log10(mu) + n_sigma * sig)
                out[k] = np.geomspace(lo, hi, int(n_points))
            else:
                lo = mu - n_sigma * sig
                hi = mu + n_sigma * sig
                if k in ("E_star", "H", "a0", "R", "Q", "k", "f0"):
                    lo = max(lo, 1e-30)
                out[k] = np.linspace(lo, hi, int(n_points))
        return out

    # ---- accessor 4:  Gaussian penalty ----
    def penalty(self, theta: Dict[str, float], weight: float = 1.0) -> float:
        """
        Sum of squared standardized deviations from the prior mean.

        Returns weight * sum_i ( (theta_i - mu_i) / sigma_i )^2.
        For log-scale params, deviations are computed in log10 space.
        Only parameters that are BOTH in `theta` AND in `self.values` contribute.
        """
        tot = 0.0
        for k, v in theta.items():
            if k not in self.values:
                continue
            mu = float(self.values[k])
            sig = self._sigma(k)
            if sig <= 0:
                continue
            if self._is_log(k):
                if v <= 0 or mu <= 0:
                    continue
                z = (np.log10(v) - np.log10(mu)) / sig
            else:
                z = (float(v) - mu) / sig
            tot += float(z * z)
        return float(weight) * tot

    def wrap_loss(self, loss_fn: Callable[[Dict[str, float]], float],
                   weight: float = 1.0) -> Callable[[Dict[str, float]], float]:
        """Return a new loss = data_loss + weight * prior_penalty."""
        def wrapped(theta: Dict[str, float]) -> float:
            return float(loss_fn(theta)) + self.penalty(theta, weight=weight)
        return wrapped

    # ---- diagnostic ----
    def report(self, fit_keys: Optional[Sequence[str]] = None) -> str:
        keys = list(fit_keys) if fit_keys is not None else list(self.values.keys())
        lines = ["MaterialPrior summary"]
        lines.append(f"  {'param':>18s}  {'mu':>14s}  {'sigma':>14s}  {'scale':>5s}  "
                     f"{'-3sigma':>14s}  {'+3sigma':>14s}")
        for k in keys:
            mu = float(self.values[k])
            sig = self._sigma(k)
            scale = "log" if self._is_log(k) else "lin"
            if self._is_log(k):
                lo = 10 ** (np.log10(mu) - 3 * sig)
                hi = 10 ** (np.log10(mu) + 3 * sig)
            else:
                lo = mu - 3 * sig
                hi = mu + 3 * sig
            lines.append(f"  {k:>18s}  {mu:14.4g}  {sig:14.4g}  {scale:>5s}  "
                         f"{lo:14.4g}  {hi:14.4g}")
        return "\n".join(lines)


# ============================================================
# 3) BUILDER FROM A STANDARD `params` DICT
# ============================================================
def make_default_prior(
    params: Dict[str, float],
    log_sigma_dex_overrides: Optional[Dict[str, float]] = None,
    lin_sigma_frac_overrides: Optional[Dict[str, float]] = None,
    abs_sigma_overrides: Optional[Dict[str, float]] = None,
    include_aux: bool = True,
) -> MaterialPrior:
    """
    Build a sensible MaterialPrior from your standard params dict.

    Parameters
    ----------
    params : the same dict you pass to build_normalized_spm_params, e.g.
        {'k', 'A', 'd0', 'a0', 'R', 'f0', 'Q', 'E_star', 'H', ...}
        Only physically-meaningful keys (E_star, H, a0, R, Q, k, f0) become priors.
    log_sigma_dex_overrides, lin_sigma_frac_overrides, abs_sigma_overrides :
        Override defaults per-key.  Use these to tighten priors you trust
        (e.g. Q from thermal tune) and loosen those you don't (sample modulus).
    include_aux : if True, also seed phase_offset_deg=0 and drive_scale=1.0
        so they can be fit alongside material params.
    """
    keys_of_interest = ("E_star", "H", "a0", "R", "Q", "k", "f0")
    values: Dict[str, float] = {}
    for k in keys_of_interest:
        if k in params:
            values[k] = float(params[k])
    if include_aux:
        values["phase_offset_deg"] = 0.0
        values["drive_scale"] = 1.0

    log_sigma = dict(DEFAULT_LOG_SIGMA_DEX)
    if log_sigma_dex_overrides:
        log_sigma.update(log_sigma_dex_overrides)

    lin_sigma = dict(DEFAULT_LIN_SIGMA_FRAC)
    if lin_sigma_frac_overrides:
        lin_sigma.update(lin_sigma_frac_overrides)

    abs_sigma = dict(DEFAULT_ABS_SIGMA)
    if abs_sigma_overrides:
        abs_sigma.update(abs_sigma_overrides)

    log_scale = dict(DEFAULT_LOG_SCALE)

    return MaterialPrior(
        values=values,
        log_sigma_dex=log_sigma,
        lin_sigma_frac=lin_sigma,
        abs_sigma=abs_sigma,
        log_scale=log_scale,
    )


# ============================================================
# 4) END-TO-END EXAMPLE
# ============================================================
if __name__ == "__main__":
    # ----- the example params from the user prompt -----
    drive = 100e-9
    params = {
        "k": 1,
        "A": drive,
        "d0": drive * 1.25,
        "a0": 0.164e-9,
        "R": 20e-9,
        "f0": 75e3,
        "Q": 200,
        "E_star": 1 / ((1 - 0.3 ** 2) / 130e9 + (1 - 0.3 ** 2) / 1.2e9),
        "H": 7.1e-20,
    }

    # ----- build a prior with tighter Q (we trust thermal tune) and looser H -----
    prior = make_default_prior(
        params,
        lin_sigma_frac_overrides={"Q": 0.05, "R": 0.30},
        log_sigma_dex_overrides={"H": 0.5},
    )
    print(prior.report(("E_star", "H", "a0", "R", "Q", "phase_offset_deg")))

    # ----- 1. grids for the surrogate library -----
    fit_mat = ("E_star", "H", "a0")
    grids = prior.grids(fit_mat, n_points=6, n_sigma=2.5)
    print("\nLibrary grids:")
    for k, g in grids.items():
        print(f"  {k:>8}: [{g[0]:.4g} ... {g[-1]:.4g}]   {g}")

    # ----- 2. bounds for the optimizer -----
    fit_all = ("E_star", "H", "a0", "phase_offset_deg")
    bounds = prior.bounds(fit_all, n_sigma=3.0)
    print("\nBounds:")
    for k, (lo, hi) in bounds.items():
        print(f"  {k:>18}: [{lo:.4g}, {hi:.4g}]")

    # ----- 3. initial guess for warm-started local optimization -----
    x0 = prior.x0(fit_all)
    print("\nInitial guess x0:", x0)

    # ----- 4. prior penalty (try a few candidate thetas) -----
    print("\nPenalty examples (n_sigma deviations):")
    for label, theta in [
        ("at prior mean", x0),
        ("E* x2",         {**x0, "E_star": x0["E_star"] * 2.0}),
        ("a0 +50%",       {**x0, "a0": x0["a0"] * 1.5}),
        ("phase off=15",  {**x0, "phase_offset_deg": 15.0}),
    ]:
        print(f"  {label:>15}:  penalty(weight=1) = {prior.penalty(theta):.3f}")

    # ----- 5. wiring it into the surrogate calibrator -----
    print("""
    Workflow integration
    --------------------
    from fd_surrogate_calibration import (
        build_fd_param_library, FDSurrogateCalibrator, SurrogateCalibrationConfig,
    )
    from fd_only_calibration import FDCalibrationCurve

    # build the surrogate library on the prior-centered grids
    lib = build_fd_param_library(
        base_params=params, conversions=conversions,
        E_grid=grids["E_star"], H_grid=grids["H"], a0_grid=grids["a0"],
        drives_si=drives_si, solver=solver,
        n_d_hat=140, d_start_factor=1.25, d_end_hat=-7.0,
        n_jobs=8, cache_path="fd_param_library.npz",
    )

    cal = FDSurrogateCalibrator(lib, fd_curves, SurrogateCalibrationConfig())
    cal.loss = prior.wrap_loss(cal.loss, weight=0.05)   # soft Bayesian penalty

    # warm-started local fit; no DE needed:
    res = cal.fit(bounds=bounds, x0=x0, method="L-BFGS-B")
    print("theta_best =", res["theta_best"])
    """)
