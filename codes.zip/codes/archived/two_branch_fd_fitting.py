"""
Two-branch fitting for tapping/contact-mode FD amplitude/phase curves.

Purpose
-------
Use this when a single FD model fits amplitude but cannot fit the phase branch,
especially at large drive where the phase has two dynamical branches.

The code is written around a black-box forward model:

    A_pred, phi_pred = forward_model(d_nm, drive_nm, params)

where params is a dict containing at least physical parameters such as
C1, C2, a0, Q, and C3. You can wrap your existing RK45 FD simulator with this
signature. See `make_forward_model_template` near the end.

Main workflows
--------------
1. Fit one curve:

    fit = fit_one_curve_two_branch(curve, forward_model, cfg)

2. Fit multiple drives globally with smooth C3/offsets:

    fit = fit_global_two_branch(curves, forward_model, cfg)

3. Plot diagnostics:

    plot_two_branch_fit(curve, fit, forward_model)
    plot_global_two_branch_fit(curves, fit, forward_model)

Data convention
---------------
- `d_nm`/`height_nm` is the x-axis in your FD plot. Keep the same sign/order as
  your existing single-fit code. If your simulator uses the opposite sign,
  handle that inside `forward_model` or enable fitted `d_offset_nm`.
- `phi_deg` is in degrees. Phase residuals are wrapped to [-period/2, period/2].
  Default period is 360 deg. Set cfg.phase_period_deg=180 if your detector is
  effectively 180-periodic.
- Branch 0: upper/attractive/non-contact-like phase branch.
- Branch 1: lower/repulsive/intermittent-contact-like phase branch.

Author: generated with ChatGPT for Richard Liu's FD digital-twin workflow.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple, Union
import copy
import warnings

import numpy as np
from numpy.typing import ArrayLike

try:
    from scipy.optimize import least_squares
except Exception as exc:  # pragma: no cover
    least_squares = None
    _SCIPY_IMPORT_ERROR = exc

try:
    import matplotlib.pyplot as plt
except Exception:  # pragma: no cover
    plt = None


# -----------------------------------------------------------------------------
# Utilities
# -----------------------------------------------------------------------------


def as_1d_float(x: ArrayLike, name: str = "array") -> np.ndarray:
    arr = np.asarray(x, dtype=float).ravel()
    if arr.size == 0:
        raise ValueError(f"{name} is empty")
    if not np.all(np.isfinite(arr)):
        raise ValueError(f"{name} contains NaN/Inf")
    return arr


def wrap_phase_deg(delta_deg: ArrayLike, period_deg: float = 360.0) -> np.ndarray:
    """Wrap phase residuals to [-period/2, period/2]."""
    delta = np.asarray(delta_deg, dtype=float)
    return (delta + 0.5 * period_deg) % period_deg - 0.5 * period_deg


def robust_mad_scale(y: ArrayLike, floor: float = 1e-9) -> float:
    y = np.asarray(y, dtype=float).ravel()
    med = np.nanmedian(y)
    mad = np.nanmedian(np.abs(y - med))
    scale = 1.4826 * mad
    if not np.isfinite(scale) or scale < floor:
        scale = float(np.nanstd(y))
    if not np.isfinite(scale) or scale < floor:
        scale = 1.0
    return float(scale)


def smooth1d(y: np.ndarray, win: int = 7) -> np.ndarray:
    """Small moving-average smoother used only for auto-label initialization."""
    y = np.asarray(y, dtype=float)
    if win <= 1 or y.size < 3:
        return y.copy()
    win = int(win)
    if win % 2 == 0:
        win += 1
    win = min(win, y.size if y.size % 2 == 1 else y.size - 1)
    if win < 3:
        return y.copy()
    pad = win // 2
    yy = np.pad(y, pad, mode="edge")
    kernel = np.ones(win) / win
    return np.convolve(yy, kernel, mode="valid")


def finite_diff_slope(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    if x.size < 3:
        return np.zeros_like(y)
    dx = np.gradient(x)
    dy = np.gradient(y)
    return dy / np.maximum(np.abs(dx), 1e-12)


# -----------------------------------------------------------------------------
# Data containers
# -----------------------------------------------------------------------------


@dataclass
class FDCurve:
    """One FD curve at one drive.

    Parameters
    ----------
    drive_nm:
        Free-drive amplitude or drive label in nm. The code only assumes it is
        a positive scalar passed to the forward model.
    d_nm:
        Distance/height axis used by your FD curves.
    A_nm:
        Measured amplitude.
    phi_deg:
        Measured phase.
    branch:
        Optional branch labels. Use 0 for upper/attractive branch, 1 for lower
        repulsive branch, -1 or NaN for unknown. If omitted, labels are auto-
        initialized from the phase curve.
    name:
        Optional human-readable name.
    """

    drive_nm: float
    d_nm: ArrayLike
    A_nm: ArrayLike
    phi_deg: ArrayLike
    branch: Optional[ArrayLike] = None
    name: str = ""

    def __post_init__(self):
        self.drive_nm = float(self.drive_nm)
        self.d_nm = as_1d_float(self.d_nm, "d_nm")
        self.A_nm = as_1d_float(self.A_nm, "A_nm")
        self.phi_deg = as_1d_float(self.phi_deg, "phi_deg")
        n = self.d_nm.size
        if self.A_nm.size != n or self.phi_deg.size != n:
            raise ValueError("d_nm, A_nm, and phi_deg must have the same length")
        if self.branch is not None:
            b = np.asarray(self.branch).ravel()
            if b.size != n:
                raise ValueError("branch must have the same length as d_nm")
            # preserve unknown labels as -1
            b_float = b.astype(float)
            out = np.full(n, -1, dtype=int)
            finite = np.isfinite(b_float)
            out[finite] = b_float[finite].astype(int)
            self.branch = out

    @property
    def n(self) -> int:
        return self.d_nm.size

    def sorted_by_distance(self) -> "FDCurve":
        idx = np.argsort(self.d_nm)
        branch = None if self.branch is None else self.branch[idx]
        return FDCurve(
            drive_nm=self.drive_nm,
            d_nm=self.d_nm[idx],
            A_nm=self.A_nm[idx],
            phi_deg=self.phi_deg[idx],
            branch=branch,
            name=self.name,
        )


@dataclass
class TwoBranchFitConfig:
    """Configuration for two-branch FD fitting."""

    # Parameters expected by the user's forward_model. Positive params are
    # optimized in log10-space.
    param_names: Tuple[str, ...] = ("C1", "C2", "a0", "Q", "C3")
    positive_params: Tuple[str, ...] = ("C1", "C2", "a0", "Q", "C3")

    # Initial parameter guesses for branch 0 and branch 1. Branch 1 is usually
    # initialized from branch 0 and then allowed to differ.
    p0_branch0: Dict[str, float] = field(default_factory=lambda: {
        "C1": 1e-3,
        "C2": 3e-2,
        "a0": 5e-2,
        "Q": 100.0,
        "C3": 0.1,
    })
    p0_branch1: Optional[Dict[str, float]] = None

    # Bounds. Positive params use log10(bounds). Linear params use raw bounds.
    bounds: Dict[str, Tuple[float, float]] = field(default_factory=lambda: {
        "C1": (1e-6, 1e1),
        "C2": (1e-6, 1e2),
        "a0": (1e-5, 1e1),
        "Q": (1.0, 1e4),
        "C3": (1e-5, 1e2),
    })

    # Whether each physical parameter is shared by the two branches. Start with
    # branch-specific C1/C2/a0/Q and shared or per-drive C3. If branch 1 becomes
    # unphysical, set more entries to True.
    share_param_between_branches: Dict[str, bool] = field(default_factory=lambda: {
        "C1": False,
        "C2": False,
        "a0": False,
        "Q": False,
        "C3": False,
    })

    # Fitted distance and phase offsets per branch. These absorb alignment and
    # lock-in phase offset errors without forcing physical params to compensate.
    fit_d_offset_nm: bool = True
    d_offset_bounds_nm: Tuple[float, float] = (-10.0, 10.0)
    fit_phase_offset_deg: bool = True
    phase_offset_bounds_deg: Tuple[float, float] = (-180.0, 180.0)

    # Residual weights. For your plots, phase should be amplitude-weighted so
    # low-amplitude points do not dominate.
    w_amp: float = 1.0
    w_phi: float = 0.05
    amp_scale: Optional[float] = None
    phi_scale_deg: Optional[float] = None
    phase_period_deg: float = 360.0
    use_amp_weighted_phase: bool = True
    A_floor_frac: float = 0.15
    phase_weight_power: float = 1.0

    # How amplitude is handled. The phase clearly needs two branches. The
    # amplitude often remains almost single-valued, so use "shared_branch0" if
    # branch 1 fixes phase but ruins amplitude.
    # Options: "assigned", "shared_branch0", "best".
    amplitude_mode: str = "shared_branch0"

    # Regularization: keep branch 1 from becoming an arbitrary phase-only model.
    branch_param_reg: float = 0.02
    offset_reg: float = 0.002

    # Global fitting smoothness for per-drive C3 and offsets.
    smooth_C3_reg: float = 0.05
    smooth_offset_reg: float = 0.01

    # Auto-labeling. Branch 1 is usually the low-phase branch below far-field.
    auto_label_phase_margin_deg: float = 8.0
    auto_label_min_low_phase_fraction: float = 0.03
    auto_label_smooth_win: int = 7

    # Optimizer controls.
    max_nfev: int = 2000
    xtol: float = 1e-9
    ftol: float = 1e-9
    gtol: float = 1e-9
    loss: str = "soft_l1"  # "linear", "soft_l1", "huber", "cauchy", "arctan"
    f_scale: float = 1.0
    verbose: int = 0

    def initial_branch1(self) -> Dict[str, float]:
        if self.p0_branch1 is None:
            return dict(self.p0_branch0)
        p = dict(self.p0_branch0)
        p.update(self.p0_branch1)
        return p


@dataclass
class TwoBranchFitResult:
    """Fit result for one curve."""

    drive_nm: float
    params_branch0: Dict[str, float]
    params_branch1: Dict[str, float]
    d_offset_branch0_nm: float
    d_offset_branch1_nm: float
    phi_offset_branch0_deg: float
    phi_offset_branch1_deg: float
    labels: np.ndarray
    success: bool
    cost: float
    message: str
    raw_result: object = None

    def params_for_branch(self, branch: int) -> Dict[str, float]:
        return self.params_branch0 if int(branch) == 0 else self.params_branch1

    def d_offset_for_branch(self, branch: int) -> float:
        return self.d_offset_branch0_nm if int(branch) == 0 else self.d_offset_branch1_nm

    def phi_offset_for_branch(self, branch: int) -> float:
        return self.phi_offset_branch0_deg if int(branch) == 0 else self.phi_offset_branch1_deg


@dataclass
class GlobalTwoBranchFitResult:
    """Fit result for multiple curves.

    The global model uses branch-global physical parameters except C3, which is
    fitted per drive/branch by default. It also fits per-drive/branch distance
    and phase offsets. This usually stabilizes the unphysical drive-to-drive
    jumps seen in independent single-curve fitting.
    """

    curves_drive_nm: np.ndarray
    params_branch0_global: Dict[str, float]
    params_branch1_global: Dict[str, float]
    C3_branch0: np.ndarray
    C3_branch1: np.ndarray
    d_offset_branch0_nm: np.ndarray
    d_offset_branch1_nm: np.ndarray
    phi_offset_branch0_deg: np.ndarray
    phi_offset_branch1_deg: np.ndarray
    labels: List[np.ndarray]
    success: bool
    cost: float
    message: str
    raw_result: object = None

    def single_curve_result(self, i: int, cfg: TwoBranchFitConfig) -> TwoBranchFitResult:
        p0 = dict(self.params_branch0_global)
        p1 = dict(self.params_branch1_global)
        p0["C3"] = float(self.C3_branch0[i])
        p1["C3"] = float(self.C3_branch1[i])
        return TwoBranchFitResult(
            drive_nm=float(self.curves_drive_nm[i]),
            params_branch0=p0,
            params_branch1=p1,
            d_offset_branch0_nm=float(self.d_offset_branch0_nm[i]),
            d_offset_branch1_nm=float(self.d_offset_branch1_nm[i]),
            phi_offset_branch0_deg=float(self.phi_offset_branch0_deg[i]),
            phi_offset_branch1_deg=float(self.phi_offset_branch1_deg[i]),
            labels=self.labels[i],
            success=self.success,
            cost=self.cost,
            message=self.message,
            raw_result=self.raw_result,
        )


# -----------------------------------------------------------------------------
# Label initialization
# -----------------------------------------------------------------------------


def estimate_far_field_phase(phi_deg: np.ndarray, d_nm: np.ndarray, frac: float = 0.2) -> float:
    """Robust far-field phase estimate from the largest-distance part."""
    d = np.asarray(d_nm, dtype=float)
    phi = np.asarray(phi_deg, dtype=float)
    n = d.size
    k = max(5, int(frac * n))
    idx = np.argsort(d)[-k:]
    return float(np.nanmedian(phi[idx]))


def auto_label_two_phase_branches(curve: FDCurve, cfg: TwoBranchFitConfig) -> np.ndarray:
    """Initialize labels for upper/lower phase branches.

    Branch 1 is assigned to points clearly below far-field phase. This matches
    the large-drive curves in your screenshot where the lower loop sits around
    60--110 deg while far field is near 120 deg.
    """
    if curve.branch is not None and np.any(curve.branch >= 0):
        labels = np.asarray(curve.branch, dtype=int).copy()
        unknown = labels < 0
    else:
        labels = np.zeros(curve.n, dtype=int)
        unknown = np.ones(curve.n, dtype=bool)

    phi_s = smooth1d(curve.phi_deg, cfg.auto_label_smooth_win)
    phi_far = estimate_far_field_phase(phi_s, curve.d_nm)
    low = phi_s < (phi_far - cfg.auto_label_phase_margin_deg)

    # Avoid inventing branch 1 if only a few noisy points are low.
    if np.mean(low) >= cfg.auto_label_min_low_phase_fraction:
        labels[unknown & low] = 1
        labels[unknown & ~low] = 0
    else:
        labels[unknown] = 0

    return labels


def reassign_labels_by_model(
    curve: FDCurve,
    fit: TwoBranchFitResult,
    forward_model: Callable[[np.ndarray, float, Mapping[str, float]], Tuple[np.ndarray, np.ndarray]],
    cfg: TwoBranchFitConfig,
    keep_known_labels: bool = True,
) -> np.ndarray:
    """Reassign unknown labels to the lower-loss branch using phase residual."""
    labels = np.zeros(curve.n, dtype=int)
    losses = []
    for b in (0, 1):
        p = dict(fit.params_for_branch(b))
        d_eff = curve.d_nm + fit.d_offset_for_branch(b)
        A_pred, phi_pred = forward_model(d_eff, curve.drive_nm, p)
        phi_pred = np.asarray(phi_pred, dtype=float) + fit.phi_offset_for_branch(b)
        r_phi = wrap_phase_deg(curve.phi_deg - phi_pred, cfg.phase_period_deg)
        loss_b = (r_phi / _phi_scale(curve, cfg)) ** 2
        losses.append(loss_b)
    losses = np.vstack(losses)
    labels[:] = np.argmin(losses, axis=0)

    if keep_known_labels and curve.branch is not None:
        known = np.asarray(curve.branch) >= 0
        labels[known] = np.asarray(curve.branch, dtype=int)[known]
    return labels


# -----------------------------------------------------------------------------
# Parameter packing/unpacking for one-curve fit
# -----------------------------------------------------------------------------


def _is_positive_param(name: str, cfg: TwoBranchFitConfig) -> bool:
    return name in set(cfg.positive_params)


def _to_internal(name: str, value: float, cfg: TwoBranchFitConfig) -> float:
    value = float(value)
    if _is_positive_param(name, cfg):
        return float(np.log10(max(value, 1e-300)))
    return value


def _from_internal(name: str, value: float, cfg: TwoBranchFitConfig) -> float:
    value = float(value)
    if _is_positive_param(name, cfg):
        return float(10.0 ** value)
    return value


def _internal_bounds(name: str, cfg: TwoBranchFitConfig) -> Tuple[float, float]:
    lo, hi = cfg.bounds[name]
    if _is_positive_param(name, cfg):
        return float(np.log10(lo)), float(np.log10(hi))
    return float(lo), float(hi)


def _amp_scale(curve: FDCurve, cfg: TwoBranchFitConfig) -> float:
    if cfg.amp_scale is not None:
        return float(cfg.amp_scale)
    return max(robust_mad_scale(curve.A_nm), 0.05 * max(np.nanmax(np.abs(curve.A_nm)), 1.0), 1e-6)


def _phi_scale(curve: FDCurve, cfg: TwoBranchFitConfig) -> float:
    if cfg.phi_scale_deg is not None:
        return float(cfg.phi_scale_deg)
    return max(robust_mad_scale(curve.phi_deg), 5.0)


def _phase_weights(curve: FDCurve, cfg: TwoBranchFitConfig) -> np.ndarray:
    if not cfg.use_amp_weighted_phase:
        return np.ones(curve.n)
    A0 = float(np.nanmax(np.abs(curve.A_nm)))
    floor = max(cfg.A_floor_frac * A0, 1e-9)
    w = curve.A_nm / np.sqrt(curve.A_nm**2 + floor**2)
    w = np.clip(w, 0.0, 1.0) ** cfg.phase_weight_power
    return w


def pack_one_curve_params(
    p0: Mapping[str, float],
    p1: Mapping[str, float],
    d_offsets: Tuple[float, float],
    phi_offsets: Tuple[float, float],
    cfg: TwoBranchFitConfig,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, List[Tuple[str, int]]]:
    """Pack one-curve parameters into optimizer vector.

    Returns x0, lb, ub, spec. spec contains (param_name, branch), with special
    param names '__d_offset__' and '__phi_offset__'.
    """
    x0: List[float] = []
    lb: List[float] = []
    ub: List[float] = []
    spec: List[Tuple[str, int]] = []

    for name in cfg.param_names:
        if cfg.share_param_between_branches.get(name, False):
            x0.append(_to_internal(name, p0[name], cfg))
            lo, hi = _internal_bounds(name, cfg)
            lb.append(lo); ub.append(hi)
            spec.append((name, -1))  # shared
        else:
            for b, p in ((0, p0), (1, p1)):
                x0.append(_to_internal(name, p[name], cfg))
                lo, hi = _internal_bounds(name, cfg)
                lb.append(lo); ub.append(hi)
                spec.append((name, b))

    if cfg.fit_d_offset_nm:
        for b in (0, 1):
            x0.append(float(d_offsets[b]))
            lb.append(float(cfg.d_offset_bounds_nm[0]))
            ub.append(float(cfg.d_offset_bounds_nm[1]))
            spec.append(("__d_offset__", b))

    if cfg.fit_phase_offset_deg:
        for b in (0, 1):
            x0.append(float(phi_offsets[b]))
            lb.append(float(cfg.phase_offset_bounds_deg[0]))
            ub.append(float(cfg.phase_offset_bounds_deg[1]))
            spec.append(("__phi_offset__", b))

    return np.asarray(x0), np.asarray(lb), np.asarray(ub), spec


def unpack_one_curve_params(
    x: np.ndarray,
    spec: Sequence[Tuple[str, int]],
    cfg: TwoBranchFitConfig,
) -> Tuple[Dict[str, float], Dict[str, float], Tuple[float, float], Tuple[float, float]]:
    p0: Dict[str, float] = {}
    p1: Dict[str, float] = {}
    d_offsets = [0.0, 0.0]
    phi_offsets = [0.0, 0.0]

    for val, (name, branch) in zip(x, spec):
        if name == "__d_offset__":
            d_offsets[branch] = float(val)
        elif name == "__phi_offset__":
            phi_offsets[branch] = float(val)
        else:
            v = _from_internal(name, float(val), cfg)
            if branch == -1:
                p0[name] = v
                p1[name] = v
            elif branch == 0:
                p0[name] = v
            elif branch == 1:
                p1[name] = v
            else:
                raise ValueError(f"Invalid branch {branch}")

    # Fill branch params for shared cases not explicitly assigned.
    for name in cfg.param_names:
        if name not in p0:
            p0[name] = cfg.p0_branch0[name]
        if name not in p1:
            p1[name] = cfg.initial_branch1()[name]

    return p0, p1, (d_offsets[0], d_offsets[1]), (phi_offsets[0], phi_offsets[1])


# -----------------------------------------------------------------------------
# One-curve fit
# -----------------------------------------------------------------------------


def residual_one_curve(
    x: np.ndarray,
    spec: Sequence[Tuple[str, int]],
    curve: FDCurve,
    labels: np.ndarray,
    forward_model: Callable[[np.ndarray, float, Mapping[str, float]], Tuple[np.ndarray, np.ndarray]],
    cfg: TwoBranchFitConfig,
) -> np.ndarray:
    p0, p1, d_offsets, phi_offsets = unpack_one_curve_params(x, spec, cfg)
    amp_scale = _amp_scale(curve, cfg)
    phi_scale = _phi_scale(curve, cfg)
    phase_w = _phase_weights(curve, cfg)

    res: List[np.ndarray] = []

    # Predict both branches once.
    pred = {}
    for b, p in ((0, p0), (1, p1)):
        d_eff = curve.d_nm + d_offsets[b]
        A_pred, phi_pred = forward_model(d_eff, curve.drive_nm, p)
        A_pred = np.asarray(A_pred, dtype=float).ravel()
        phi_pred = np.asarray(phi_pred, dtype=float).ravel() + phi_offsets[b]
        if A_pred.size != curve.n or phi_pred.size != curve.n:
            raise ValueError("forward_model must return arrays with the same length as d_nm")
        pred[b] = (A_pred, phi_pred)

    # Amplitude residual.
    if cfg.amplitude_mode == "shared_branch0":
        A_pred = pred[0][0]
        res.append(np.sqrt(cfg.w_amp) * (curve.A_nm - A_pred) / amp_scale)
    elif cfg.amplitude_mode == "assigned":
        rA = np.zeros(curve.n)
        for b in (0, 1):
            m = labels == b
            if np.any(m):
                rA[m] = curve.A_nm[m] - pred[b][0][m]
        res.append(np.sqrt(cfg.w_amp) * rA / amp_scale)
    elif cfg.amplitude_mode == "best":
        r0 = np.abs(curve.A_nm - pred[0][0])
        r1 = np.abs(curve.A_nm - pred[1][0])
        rA = np.minimum(r0, r1) * np.sign((curve.A_nm - pred[0][0]))
        res.append(np.sqrt(cfg.w_amp) * rA / amp_scale)
    else:
        raise ValueError(f"Unknown amplitude_mode: {cfg.amplitude_mode}")

    # Phase residual, branch assigned.
    rphi = np.zeros(curve.n)
    for b in (0, 1):
        m = labels == b
        if np.any(m):
            rphi[m] = wrap_phase_deg(curve.phi_deg[m] - pred[b][1][m], cfg.phase_period_deg)
    res.append(np.sqrt(cfg.w_phi) * phase_w * rphi / phi_scale)

    # Regularize branch parameters toward each other in internal space.
    if cfg.branch_param_reg > 0:
        branch_res = []
        for name in cfg.param_names:
            if cfg.share_param_between_branches.get(name, False):
                continue
            v0 = _to_internal(name, p0[name], cfg)
            v1 = _to_internal(name, p1[name], cfg)
            branch_res.append(v1 - v0)
        if branch_res:
            res.append(np.sqrt(cfg.branch_param_reg) * np.asarray(branch_res, dtype=float))

    # Keep offsets modest unless the data demand otherwise.
    if cfg.offset_reg > 0:
        off = []
        if cfg.fit_d_offset_nm:
            scale_d = max(abs(cfg.d_offset_bounds_nm[1] - cfg.d_offset_bounds_nm[0]), 1.0)
            off.extend([d_offsets[0] / scale_d, d_offsets[1] / scale_d])
        if cfg.fit_phase_offset_deg:
            scale_phi = max(abs(cfg.phase_offset_bounds_deg[1] - cfg.phase_offset_bounds_deg[0]), 1.0)
            off.extend([phi_offsets[0] / scale_phi, phi_offsets[1] / scale_phi])
        if off:
            res.append(np.sqrt(cfg.offset_reg) * np.asarray(off, dtype=float))

    return np.concatenate([np.ravel(r) for r in res])


def fit_one_curve_two_branch(
    curve: FDCurve,
    forward_model: Callable[[np.ndarray, float, Mapping[str, float]], Tuple[np.ndarray, np.ndarray]],
    cfg: Optional[TwoBranchFitConfig] = None,
    labels: Optional[np.ndarray] = None,
    n_em: int = 2,
    previous_fit: Optional[TwoBranchFitResult] = None,
) -> TwoBranchFitResult:
    """Fit one FD curve with two phase branches.

    Parameters
    ----------
    curve:
        FDCurve at one drive.
    forward_model:
        Your RK45/simulator wrapper. Signature: (d_nm, drive_nm, params) ->
        (A_pred_nm, phi_pred_deg).
    cfg:
        TwoBranchFitConfig.
    labels:
        Optional initial branch labels. If None, labels are auto-initialized.
    n_em:
        Number of label-refit iterations. Use 0 if branch labels are trusted.
    previous_fit:
        If supplied, use its parameters as initialization. Useful when sweeping
        drives from low to high.
    """
    if least_squares is None:  # pragma: no cover
        raise ImportError(f"scipy.optimize.least_squares is required: {_SCIPY_IMPORT_ERROR}")
    if cfg is None:
        cfg = TwoBranchFitConfig()

    if labels is None:
        labels = auto_label_two_phase_branches(curve, cfg)
    else:
        labels = np.asarray(labels, dtype=int).ravel()
        if labels.size != curve.n:
            raise ValueError("labels length must match curve length")

    if previous_fit is not None:
        p0 = dict(previous_fit.params_branch0)
        p1 = dict(previous_fit.params_branch1)
        d_offsets = (previous_fit.d_offset_branch0_nm, previous_fit.d_offset_branch1_nm)
        phi_offsets = (previous_fit.phi_offset_branch0_deg, previous_fit.phi_offset_branch1_deg)
    else:
        p0 = dict(cfg.p0_branch0)
        p1 = cfg.initial_branch1()
        # Initialize C3 roughly proportional to drive if user left default C3.
        if "C3" in cfg.param_names and cfg.p0_branch0.get("C3", None) == 0.1:
            p0["C3"] = max(1e-4, 0.005 * curve.drive_nm)
            p1["C3"] = max(1e-4, 0.005 * curve.drive_nm)
        d_offsets = (0.0, 0.0)
        phi_offsets = (0.0, 0.0)

    x0, lb, ub, spec = pack_one_curve_params(p0, p1, d_offsets, phi_offsets, cfg)
    x_best = x0
    raw = None
    labels_current = labels.copy()

    for em_iter in range(max(1, int(n_em) + 1)):
        raw = least_squares(
            residual_one_curve,
            x_best,
            bounds=(lb, ub),
            args=(spec, curve, labels_current, forward_model, cfg),
            loss=cfg.loss,
            f_scale=cfg.f_scale,
            max_nfev=cfg.max_nfev,
            xtol=cfg.xtol,
            ftol=cfg.ftol,
            gtol=cfg.gtol,
            verbose=cfg.verbose,
        )
        x_best = raw.x
        p0_fit, p1_fit, d_fit, phi_fit = unpack_one_curve_params(x_best, spec, cfg)
        fit_tmp = TwoBranchFitResult(
            drive_nm=curve.drive_nm,
            params_branch0=p0_fit,
            params_branch1=p1_fit,
            d_offset_branch0_nm=d_fit[0],
            d_offset_branch1_nm=d_fit[1],
            phi_offset_branch0_deg=phi_fit[0],
            phi_offset_branch1_deg=phi_fit[1],
            labels=labels_current.copy(),
            success=bool(raw.success),
            cost=float(raw.cost),
            message=str(raw.message),
            raw_result=raw,
        )
        if em_iter < int(n_em):
            labels_new = reassign_labels_by_model(curve, fit_tmp, forward_model, cfg)
            # If labels stop changing, terminate early.
            if np.array_equal(labels_new, labels_current):
                labels_current = labels_new
                break
            labels_current = labels_new

    p0_fit, p1_fit, d_fit, phi_fit = unpack_one_curve_params(x_best, spec, cfg)
    return TwoBranchFitResult(
        drive_nm=curve.drive_nm,
        params_branch0=p0_fit,
        params_branch1=p1_fit,
        d_offset_branch0_nm=d_fit[0],
        d_offset_branch1_nm=d_fit[1],
        phi_offset_branch0_deg=phi_fit[0],
        phi_offset_branch1_deg=phi_fit[1],
        labels=labels_current.copy(),
        success=bool(raw.success) if raw is not None else False,
        cost=float(raw.cost) if raw is not None else np.inf,
        message=str(raw.message) if raw is not None else "not run",
        raw_result=raw,
    )


def fit_curves_sequential_two_branch(
    curves: Sequence[FDCurve],
    forward_model: Callable[[np.ndarray, float, Mapping[str, float]], Tuple[np.ndarray, np.ndarray]],
    cfg: Optional[TwoBranchFitConfig] = None,
    n_em: int = 2,
    sort_by_drive: bool = True,
) -> List[TwoBranchFitResult]:
    """Fit curves one-by-one, using the previous drive as initialization."""
    if cfg is None:
        cfg = TwoBranchFitConfig()
    curves_list = list(curves)
    order = np.arange(len(curves_list))
    if sort_by_drive:
        order = np.argsort([c.drive_nm for c in curves_list])
    results_tmp: Dict[int, TwoBranchFitResult] = {}
    prev = None
    for idx in order:
        fit = fit_one_curve_two_branch(
            curves_list[idx],
            forward_model,
            cfg=cfg,
            n_em=n_em,
            previous_fit=prev,
        )
        results_tmp[int(idx)] = fit
        prev = fit
    return [results_tmp[i] for i in range(len(curves_list))]


# -----------------------------------------------------------------------------
# Global multi-drive fit
# -----------------------------------------------------------------------------


def _pack_global(curves: Sequence[FDCurve], cfg: TwoBranchFitConfig):
    """Pack global params.

    Global design:
    - C1/C2/a0/Q are branch-global.
    - C3 is per curve per branch unless share_param_between_branches['C3']=True.
    - d_offset and phi_offset are per curve per branch.
    """
    x0: List[float] = []
    lb: List[float] = []
    ub: List[float] = []
    spec: List[Tuple[str, int, int]] = []  # (name, branch, curve_index), curve_index=-1 for global

    p0 = dict(cfg.p0_branch0)
    p1 = cfg.initial_branch1()
    ncurves = len(curves)

    global_names = [name for name in cfg.param_names if name != "C3"]
    for name in global_names:
        if cfg.share_param_between_branches.get(name, False):
            x0.append(_to_internal(name, p0[name], cfg))
            lo, hi = _internal_bounds(name, cfg)
            lb.append(lo); ub.append(hi)
            spec.append((name, -1, -1))
        else:
            for b, p in ((0, p0), (1, p1)):
                x0.append(_to_internal(name, p[name], cfg))
                lo, hi = _internal_bounds(name, cfg)
                lb.append(lo); ub.append(hi)
                spec.append((name, b, -1))

    # C3 per curve. Initialization proportional to drive unless user supplied.
    if "C3" in cfg.param_names:
        for i, c in enumerate(curves):
            c3_init0 = p0.get("C3", 0.005 * c.drive_nm)
            c3_init1 = p1.get("C3", 0.005 * c.drive_nm)
            if cfg.p0_branch0.get("C3", 0.1) == 0.1:
                c3_init0 = max(1e-4, 0.005 * c.drive_nm)
            if cfg.p0_branch1 is None or cfg.initial_branch1().get("C3", 0.1) == 0.1:
                c3_init1 = max(1e-4, 0.005 * c.drive_nm)
            if cfg.share_param_between_branches.get("C3", False):
                x0.append(_to_internal("C3", c3_init0, cfg))
                lo, hi = _internal_bounds("C3", cfg)
                lb.append(lo); ub.append(hi)
                spec.append(("C3", -1, i))
            else:
                for b, c3_init in ((0, c3_init0), (1, c3_init1)):
                    x0.append(_to_internal("C3", c3_init, cfg))
                    lo, hi = _internal_bounds("C3", cfg)
                    lb.append(lo); ub.append(hi)
                    spec.append(("C3", b, i))

    if cfg.fit_d_offset_nm:
        for i in range(ncurves):
            for b in (0, 1):
                x0.append(0.0)
                lb.append(float(cfg.d_offset_bounds_nm[0]))
                ub.append(float(cfg.d_offset_bounds_nm[1]))
                spec.append(("__d_offset__", b, i))

    if cfg.fit_phase_offset_deg:
        for i in range(ncurves):
            for b in (0, 1):
                x0.append(0.0)
                lb.append(float(cfg.phase_offset_bounds_deg[0]))
                ub.append(float(cfg.phase_offset_bounds_deg[1]))
                spec.append(("__phi_offset__", b, i))

    return np.asarray(x0), np.asarray(lb), np.asarray(ub), spec


def _unpack_global(x: np.ndarray, spec: Sequence[Tuple[str, int, int]], curves: Sequence[FDCurve], cfg: TwoBranchFitConfig):
    n = len(curves)
    p0_global: Dict[str, float] = {}
    p1_global: Dict[str, float] = {}
    C3_0 = np.full(n, cfg.p0_branch0.get("C3", 0.1), dtype=float)
    C3_1 = np.full(n, cfg.initial_branch1().get("C3", 0.1), dtype=float)
    d0 = np.zeros(n, dtype=float)
    d1 = np.zeros(n, dtype=float)
    ph0 = np.zeros(n, dtype=float)
    ph1 = np.zeros(n, dtype=float)

    for val, (name, branch, i) in zip(x, spec):
        if name == "__d_offset__":
            if branch == 0:
                d0[i] = float(val)
            else:
                d1[i] = float(val)
        elif name == "__phi_offset__":
            if branch == 0:
                ph0[i] = float(val)
            else:
                ph1[i] = float(val)
        elif name == "C3":
            v = _from_internal("C3", float(val), cfg)
            if branch == -1:
                C3_0[i] = v
                C3_1[i] = v
            elif branch == 0:
                C3_0[i] = v
            else:
                C3_1[i] = v
        else:
            v = _from_internal(name, float(val), cfg)
            if branch == -1:
                p0_global[name] = v
                p1_global[name] = v
            elif branch == 0:
                p0_global[name] = v
            else:
                p1_global[name] = v

    for name in cfg.param_names:
        if name == "C3":
            continue
        if name not in p0_global:
            p0_global[name] = cfg.p0_branch0[name]
        if name not in p1_global:
            p1_global[name] = cfg.initial_branch1()[name]

    return p0_global, p1_global, C3_0, C3_1, d0, d1, ph0, ph1


def residual_global(
    x: np.ndarray,
    spec: Sequence[Tuple[str, int, int]],
    curves: Sequence[FDCurve],
    labels_list: Sequence[np.ndarray],
    forward_model: Callable[[np.ndarray, float, Mapping[str, float]], Tuple[np.ndarray, np.ndarray]],
    cfg: TwoBranchFitConfig,
) -> np.ndarray:
    p0g, p1g, C3_0, C3_1, d0, d1, ph0, ph1 = _unpack_global(x, spec, curves, cfg)
    res: List[np.ndarray] = []

    for i, curve in enumerate(curves):
        labels = labels_list[i]
        amp_scale = _amp_scale(curve, cfg)
        phi_scale = _phi_scale(curve, cfg)
        phase_w = _phase_weights(curve, cfg)

        pred = {}
        for b in (0, 1):
            p = dict(p0g if b == 0 else p1g)
            p["C3"] = float(C3_0[i] if b == 0 else C3_1[i])
            d_eff = curve.d_nm + (d0[i] if b == 0 else d1[i])
            A_pred, phi_pred = forward_model(d_eff, curve.drive_nm, p)
            pred[b] = (
                np.asarray(A_pred, dtype=float).ravel(),
                np.asarray(phi_pred, dtype=float).ravel() + (ph0[i] if b == 0 else ph1[i]),
            )

        if cfg.amplitude_mode == "shared_branch0":
            rA = curve.A_nm - pred[0][0]
        elif cfg.amplitude_mode == "assigned":
            rA = np.zeros(curve.n)
            for b in (0, 1):
                m = labels == b
                if np.any(m):
                    rA[m] = curve.A_nm[m] - pred[b][0][m]
        elif cfg.amplitude_mode == "best":
            r0 = np.abs(curve.A_nm - pred[0][0])
            r1 = np.abs(curve.A_nm - pred[1][0])
            rA = np.minimum(r0, r1) * np.sign(curve.A_nm - pred[0][0])
        else:
            raise ValueError(f"Unknown amplitude_mode: {cfg.amplitude_mode}")
        res.append(np.sqrt(cfg.w_amp) * rA / amp_scale)

        rphi = np.zeros(curve.n)
        for b in (0, 1):
            m = labels == b
            if np.any(m):
                rphi[m] = wrap_phase_deg(curve.phi_deg[m] - pred[b][1][m], cfg.phase_period_deg)
        res.append(np.sqrt(cfg.w_phi) * phase_w * rphi / phi_scale)

    # Branch parameter regularization in internal space.
    if cfg.branch_param_reg > 0:
        branch_res = []
        for name in cfg.param_names:
            if name == "C3" or cfg.share_param_between_branches.get(name, False):
                continue
            branch_res.append(_to_internal(name, p1g[name], cfg) - _to_internal(name, p0g[name], cfg))
        if branch_res:
            res.append(np.sqrt(cfg.branch_param_reg) * np.asarray(branch_res, dtype=float))

    # Smooth C3 as a function of drive, separately for each branch, in log-space.
    if cfg.smooth_C3_reg > 0 and len(curves) >= 3:
        drives = np.asarray([c.drive_nm for c in curves], dtype=float)
        order = np.argsort(drives)
        for C3 in (C3_0, C3_1):
            y = np.log10(np.maximum(C3[order], 1e-300))
            second = y[:-2] - 2 * y[1:-1] + y[2:]
            res.append(np.sqrt(cfg.smooth_C3_reg) * second)

    # Smooth offsets as a function of drive.
    if cfg.smooth_offset_reg > 0 and len(curves) >= 3:
        order = np.argsort([c.drive_nm for c in curves])
        for arr, scale in ((d0, 5.0), (d1, 5.0), (ph0, 30.0), (ph1, 30.0)):
            y = arr[order] / scale
            second = y[:-2] - 2 * y[1:-1] + y[2:]
            res.append(np.sqrt(cfg.smooth_offset_reg) * second)

    return np.concatenate([np.ravel(r) for r in res])


def fit_global_two_branch(
    curves: Sequence[FDCurve],
    forward_model: Callable[[np.ndarray, float, Mapping[str, float]], Tuple[np.ndarray, np.ndarray]],
    cfg: Optional[TwoBranchFitConfig] = None,
    labels_list: Optional[Sequence[np.ndarray]] = None,
    n_em: int = 1,
) -> GlobalTwoBranchFitResult:
    """Fit multiple drive curves with a stabilized two-branch model.

    This is usually better than independent per-drive fitting because C1/C2/a0/Q
    are not allowed to jump arbitrarily with drive. C3 and offsets still vary by
    drive.
    """
    if least_squares is None:  # pragma: no cover
        raise ImportError(f"scipy.optimize.least_squares is required: {_SCIPY_IMPORT_ERROR}")
    if cfg is None:
        cfg = TwoBranchFitConfig()
    curves = list(curves)
    if len(curves) == 0:
        raise ValueError("curves is empty")

    # Sort by drive for smoothness regularization. Return result in sorted order.
    curves = [curves[i] for i in np.argsort([c.drive_nm for c in curves])]

    if labels_list is None:
        labels_current = [auto_label_two_phase_branches(c, cfg) for c in curves]
    else:
        labels_current = [np.asarray(lab, dtype=int).ravel() for lab in labels_list]
        if len(labels_current) != len(curves):
            raise ValueError("labels_list length must match curves")
        for c, lab in zip(curves, labels_current):
            if lab.size != c.n:
                raise ValueError("each labels array must match its curve length")

    x0, lb, ub, spec = _pack_global(curves, cfg)
    x_best = x0
    raw = None

    for em_iter in range(max(1, int(n_em) + 1)):
        raw = least_squares(
            residual_global,
            x_best,
            bounds=(lb, ub),
            args=(spec, curves, labels_current, forward_model, cfg),
            loss=cfg.loss,
            f_scale=cfg.f_scale,
            max_nfev=cfg.max_nfev,
            xtol=cfg.xtol,
            ftol=cfg.ftol,
            gtol=cfg.gtol,
            verbose=cfg.verbose,
        )
        x_best = raw.x
        result_tmp = _make_global_result_from_x(x_best, spec, curves, labels_current, raw, cfg)
        if em_iter < int(n_em):
            new_labels = []
            changed = False
            for i, c in enumerate(curves):
                single = result_tmp.single_curve_result(i, cfg)
                lab = reassign_labels_by_model(c, single, forward_model, cfg)
                changed = changed or (not np.array_equal(lab, labels_current[i]))
                new_labels.append(lab)
            labels_current = new_labels
            if not changed:
                break

    return _make_global_result_from_x(x_best, spec, curves, labels_current, raw, cfg)


def _make_global_result_from_x(
    x: np.ndarray,
    spec: Sequence[Tuple[str, int, int]],
    curves: Sequence[FDCurve],
    labels_current: Sequence[np.ndarray],
    raw,
    cfg: TwoBranchFitConfig,
) -> GlobalTwoBranchFitResult:
    p0g, p1g, C3_0, C3_1, d0, d1, ph0, ph1 = _unpack_global(x, spec, curves, cfg)
    return GlobalTwoBranchFitResult(
        curves_drive_nm=np.asarray([c.drive_nm for c in curves], dtype=float),
        params_branch0_global=p0g,
        params_branch1_global=p1g,
        C3_branch0=C3_0.copy(),
        C3_branch1=C3_1.copy(),
        d_offset_branch0_nm=d0.copy(),
        d_offset_branch1_nm=d1.copy(),
        phi_offset_branch0_deg=ph0.copy(),
        phi_offset_branch1_deg=ph1.copy(),
        labels=[np.asarray(l, dtype=int).copy() for l in labels_current],
        success=bool(raw.success) if raw is not None else False,
        cost=float(raw.cost) if raw is not None else np.inf,
        message=str(raw.message) if raw is not None else "not run",
        raw_result=raw,
    )


# -----------------------------------------------------------------------------
# Prediction and plotting
# -----------------------------------------------------------------------------


def predict_two_branch(
    d_nm: ArrayLike,
    drive_nm: float,
    fit: TwoBranchFitResult,
    forward_model: Callable[[np.ndarray, float, Mapping[str, float]], Tuple[np.ndarray, np.ndarray]],
    branch: int,
) -> Tuple[np.ndarray, np.ndarray]:
    d = as_1d_float(d_nm, "d_nm")
    p = dict(fit.params_for_branch(branch))
    A, phi = forward_model(d + fit.d_offset_for_branch(branch), float(drive_nm), p)
    return np.asarray(A, dtype=float), np.asarray(phi, dtype=float) + fit.phi_offset_for_branch(branch)


def plot_two_branch_fit(
    curve: FDCurve,
    fit: TwoBranchFitResult,
    forward_model: Callable[[np.ndarray, float, Mapping[str, float]], Tuple[np.ndarray, np.ndarray]],
    cfg: Optional[TwoBranchFitConfig] = None,
    ax=None,
    title: Optional[str] = None,
):
    if plt is None:  # pragma: no cover
        raise ImportError("matplotlib is required for plotting")
    if cfg is None:
        cfg = TwoBranchFitConfig()
    if ax is None:
        fig, ax = plt.subplots(1, 2, figsize=(10, 4))
    else:
        fig = ax[0].figure

    d_grid = np.linspace(np.nanmin(curve.d_nm), np.nanmax(curve.d_nm), 600)
    colors = {0: "C1", 1: "C3"}
    names = {0: "branch 0 / upper", 1: "branch 1 / lower"}

    # Measurements colored by assigned branch.
    for b in (0, 1):
        m = fit.labels == b
        if np.any(m):
            ax[0].plot(curve.d_nm[m], curve.A_nm[m], ".", ms=4, color=colors[b], alpha=0.55)
            ax[1].plot(curve.d_nm[m], curve.phi_deg[m], ".", ms=4, color=colors[b], alpha=0.55)

    # Model predictions.
    for b in (0, 1):
        A_pred, phi_pred = predict_two_branch(d_grid, curve.drive_nm, fit, forward_model, b)
        if cfg.amplitude_mode == "shared_branch0" and b == 1:
            # Still show branch-1 amplitude faintly because it diagnoses whether
            # the branch-1 physical params are amplitude-compatible.
            ax[0].plot(d_grid, A_pred, "--", lw=1.3, color=colors[b], alpha=0.35)
        else:
            ax[0].plot(d_grid, A_pred, "-", lw=2.0, color=colors[b], label=names[b])
        ax[1].plot(d_grid, phi_pred, "-", lw=2.0, color=colors[b], label=names[b])

    ax[0].set_xlabel("Distance / height (nm)")
    ax[0].set_ylabel("Amplitude (nm)")
    ax[1].set_xlabel("Distance / height (nm)")
    ax[1].set_ylabel("Phase (deg)")
    ax[0].legend(frameon=False)
    ax[1].legend(frameon=False)
    if title is None:
        title = f"Drive = {curve.drive_nm:.4g}, cost={fit.cost:.3g}"
    fig.suptitle(title)
    fig.tight_layout()
    return fig, ax


def plot_global_two_branch_fit(
    curves: Sequence[FDCurve],
    fit: GlobalTwoBranchFitResult,
    forward_model: Callable[[np.ndarray, float, Mapping[str, float]], Tuple[np.ndarray, np.ndarray]],
    cfg: Optional[TwoBranchFitConfig] = None,
    drive_indices: Optional[Sequence[int]] = None,
):
    if plt is None:  # pragma: no cover
        raise ImportError("matplotlib is required for plotting")
    if cfg is None:
        cfg = TwoBranchFitConfig()
    curves = [curves[i] for i in np.argsort([c.drive_nm for c in curves])]
    if drive_indices is None:
        drive_indices = np.linspace(0, len(curves) - 1, min(6, len(curves))).astype(int)
    figs = []
    for i in drive_indices:
        single = fit.single_curve_result(int(i), cfg)
        fig, ax = plot_two_branch_fit(curves[int(i)], single, forward_model, cfg)
        figs.append(fig)
    return figs


def plot_global_parameters(fit: GlobalTwoBranchFitResult):
    if plt is None:  # pragma: no cover
        raise ImportError("matplotlib is required for plotting")
    drives = fit.curves_drive_nm
    fig, ax = plt.subplots(2, 3, figsize=(13, 7))
    axes = ax.ravel()
    params = ["C1", "C2", "a0", "Q"]
    for j, name in enumerate(params):
        axes[j].semilogy(drives, np.full_like(drives, fit.params_branch0_global[name]), "o-", label="branch 0")
        axes[j].semilogy(drives, np.full_like(drives, fit.params_branch1_global[name]), "o-", label="branch 1")
        axes[j].set_title(name)
        axes[j].set_xlabel("Drive amplitude")
    axes[4].semilogy(drives, fit.C3_branch0, "o-", label="branch 0")
    axes[4].semilogy(drives, fit.C3_branch1, "o-", label="branch 1")
    axes[4].set_title("C3")
    axes[4].set_xlabel("Drive amplitude")
    axes[5].plot(drives, fit.phi_offset_branch0_deg, "o-", label="phi offset b0")
    axes[5].plot(drives, fit.phi_offset_branch1_deg, "o-", label="phi offset b1")
    axes[5].plot(drives, fit.d_offset_branch0_nm, "s--", label="d offset b0")
    axes[5].plot(drives, fit.d_offset_branch1_nm, "s--", label="d offset b1")
    axes[5].set_title("Offsets")
    axes[5].set_xlabel("Drive amplitude")
    for a in axes:
        a.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    return fig, ax


# -----------------------------------------------------------------------------
# Adapter templates and example data preparation
# -----------------------------------------------------------------------------


def make_forward_model_template():
    """Template for wrapping your existing RK45 FD simulator.

    Replace the body with your current single-fit simulator call. The only
    requirement is that it returns A_pred_nm and phi_pred_deg at the requested
    d_nm points.
    """

    def forward_model(d_nm: np.ndarray, drive_nm: float, params: Mapping[str, float]):
        # Example skeleton:
        # out = simulate_fd_curve_rk45(
        #     height_nm=d_nm,
        #     drive_nm=drive_nm,
        #     C1=params["C1"],
        #     C2=params["C2"],
        #     a0=params["a0"],
        #     Q=params["Q"],
        #     C3=params["C3"],
        # )
        # return out["A_nm"], out["phi_deg"]
        raise NotImplementedError(
            "Replace make_forward_model_template() with a wrapper around your existing RK45 FD solver."
        )

    return forward_model


def build_curves_from_arrays(
    drives: ArrayLike,
    d_2d: ArrayLike,
    A_2d: ArrayLike,
    phi_2d: ArrayLike,
    branches_2d: Optional[ArrayLike] = None,
) -> List[FDCurve]:
    """Convert common measured arrays into a list of FDCurve objects.

    Accepts either:
    - d_2d/A_2d/phi_2d shape (n_drive, n_points), or
    - d_2d shape (n_points,), shared by all drives.
    """
    drives = as_1d_float(drives, "drives")
    A = np.asarray(A_2d, dtype=float)
    phi = np.asarray(phi_2d, dtype=float)
    if A.ndim != 2 or phi.ndim != 2:
        raise ValueError("A_2d and phi_2d must have shape (n_drive, n_points)")
    if A.shape != phi.shape:
        raise ValueError("A_2d and phi_2d must have the same shape")
    if A.shape[0] != drives.size:
        raise ValueError("A_2d.shape[0] must match len(drives)")

    d_arr = np.asarray(d_2d, dtype=float)
    if d_arr.ndim == 1:
        d_arr = np.tile(d_arr[None, :], (drives.size, 1))
    if d_arr.shape != A.shape:
        raise ValueError("d_2d must have shape (n_points,) or (n_drive, n_points)")

    b_arr = None
    if branches_2d is not None:
        b_arr = np.asarray(branches_2d)
        if b_arr.shape != A.shape:
            raise ValueError("branches_2d must have same shape as A_2d")

    curves = []
    for i, drv in enumerate(drives):
        branch = None if b_arr is None else b_arr[i]
        finite = np.isfinite(d_arr[i]) & np.isfinite(A[i]) & np.isfinite(phi[i])
        curves.append(FDCurve(drv, d_arr[i, finite], A[i, finite], phi[i, finite], branch=None if branch is None else branch[finite]))
    return curves


# -----------------------------------------------------------------------------
# Optional empirical toy forward model for testing only.
# -----------------------------------------------------------------------------


def toy_forward_model(d_nm: np.ndarray, drive_nm: float, params: Mapping[str, float]) -> Tuple[np.ndarray, np.ndarray]:
    """A cheap empirical curve, useful only to test the fitter plumbing.

    This is NOT the physical simulator. Do not use it for your final physics.
    """
    d = np.asarray(d_nm, dtype=float)
    A0 = drive_nm * 0.75
    contact_slope = max(params.get("C2", 0.03), 1e-6) * 300.0
    d_contact = 8.0 + 30.0 * params.get("a0", 0.05)
    A = np.minimum(A0, np.maximum(0.0, contact_slope * (d - d_contact) + 0.25 * A0))
    phi_far = 120.0
    strength = 80.0 * params.get("C1", 1e-3) / (params.get("C1", 1e-3) + 1e-3)
    width = 4.0 + 30.0 / max(params.get("Q", 100.0), 1.0)
    phi = phi_far + strength / (1.0 + np.exp((d - d_contact) / width))
    # Let larger C3 create lower branch phase.
    if params.get("branch_sign", 1.0) < 0:
        phi = phi_far - strength / (1.0 + np.exp((d - d_contact) / width))
    return A, phi


if __name__ == "__main__":
    # Minimal smoke test with toy data.
    rng = np.random.default_rng(0)
    d = np.linspace(0, 70, 300)
    drive = 60.0
    p_upper = {"C1": 2e-3, "C2": 0.03, "a0": 0.05, "Q": 100.0, "C3": 0.3, "branch_sign": 1.0}
    p_lower = {"C1": 2e-3, "C2": 0.03, "a0": 0.05, "Q": 100.0, "C3": 0.3, "branch_sign": -1.0}
    A, phi_u = toy_forward_model(d, drive, p_upper)
    _, phi_l = toy_forward_model(d, drive, p_lower)
    labels = np.zeros_like(d, dtype=int)
    labels[(d > 8) & (d < 30)] = 1
    phi = np.where(labels == 0, phi_u, phi_l) + rng.normal(0, 1.0, size=d.size)
    A = A + rng.normal(0, 0.15, size=d.size)
    curve = FDCurve(drive, d, A, phi, labels)

    # To test branch-specific behavior with toy model, include a nonphysical
    # branch_sign parameter as a linear parameter.
    cfg = TwoBranchFitConfig(
        param_names=("C1", "C2", "a0", "Q", "C3", "branch_sign"),
        positive_params=("C1", "C2", "a0", "Q", "C3"),
        p0_branch0={"C1": 1e-3, "C2": 0.03, "a0": 0.05, "Q": 100.0, "C3": 0.3, "branch_sign": 1.0},
        p0_branch1={"C1": 1e-3, "C2": 0.03, "a0": 0.05, "Q": 100.0, "C3": 0.3, "branch_sign": -1.0},
        bounds={"C1": (1e-5, 1e-1), "C2": (1e-3, 1.0), "a0": (1e-3, 1.0), "Q": (5, 1e3), "C3": (1e-4, 10), "branch_sign": (-1.2, 1.2)},
        share_param_between_branches={"C1": False, "C2": True, "a0": True, "Q": True, "C3": True, "branch_sign": False},
        amplitude_mode="shared_branch0",
        fit_d_offset_nm=True,
        fit_phase_offset_deg=True,
        max_nfev=300,
    )
    fit = fit_one_curve_two_branch(curve, toy_forward_model, cfg, n_em=0)
    print(fit.success, fit.cost)
    print(fit.params_branch0)
    print(fit.params_branch1)
