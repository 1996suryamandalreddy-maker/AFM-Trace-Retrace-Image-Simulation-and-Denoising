"""
fd_surrogate_calibration.py
===========================

Surrogate-accelerated FD calibration of material parameters (E_star, H, a0).

Strategy
--------
1. BUILD a coarse parameter library ONCE:
     for each (E_star_i, H_j, a0_k) on a regular grid,
     for each drive in drives_si,
        run the RK45 approach simulator -> store (A_hat[d_hat], phi[d_hat])
   The result is a 5-D table:  (n_E, n_H, n_a0, n_drive, n_d_hat)
   This step is parallelizable and cacheable to .npz.

2. AT OPTIMIZATION TIME, evaluate the loss by interpolating in the
   library (scipy.RegularGridInterpolator over (E_star, H, a0)).  No
   ODE solves.  A loss eval costs milliseconds, so DE / Powell run
   in seconds.

3. OPTIONAL VERIFICATION: at the end, run one full-fidelity simulation
   at the optimum and confirm the surrogate's prediction.

This pairs with `fd_only_calibration.py` (same FDCalibrationCurve schema,
same loss decomposition: phase-curve + free-phase + threshold).

Compute budget guideline
------------------------
Default grid 6 x 6 x 6 = 216 param combos x 15 drives = 3240 RK45 sims.
At ~0.5 s per sim (numba-jit, 160 d_hat points) -> ~25 min serial,
~3 min on 8 cores.  Re-use forever.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

import os
import time
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import differential_evolution, minimize
from scipy.interpolate import RegularGridInterpolator

from spm_fd_multidrive_alignment import (
    RK45Options,
    SPMRK45ApproachModel,
    build_normalized_spm_params,
)

# Re-use the FDCalibrationCurve / detect_threshold_setpoint from the
# previous module so we don't duplicate the data schema.
from fd_only_calibration import (
    FDCalibrationCurve,
    detect_threshold_setpoint,
)


# ============================================================
# 1) PARAMETER LIBRARY
# ============================================================
@dataclass
class FDParamLibrary:
    """5-D pre-computed FD library indexed by (E_star, H, a0, drive, d_hat)."""
    E_grid: np.ndarray         # (n_E,)
    H_grid: np.ndarray         # (n_H,)
    a0_grid: np.ndarray        # (n_a0,)
    drives_si: np.ndarray      # (n_drive,)  drive amplitudes in m
    d_hat_grid: np.ndarray     # (n_d_hat,)  shared distance grid
    A_table: np.ndarray        # (n_E, n_H, n_a0, n_drive, n_d_hat)
    phi_table: np.ndarray      # same shape, phase in deg (NO offset applied)
    base_params: Dict[str, float]
    conversions: Dict[str, float]
    solver: Dict[str, Any] = field(default_factory=dict)
    attrs: Dict[str, Any] = field(default_factory=dict)

    # ---------- save / load ----------
    def save(self, path: str) -> None:
        np.savez_compressed(
            path,
            E_grid=self.E_grid, H_grid=self.H_grid, a0_grid=self.a0_grid,
            drives_si=self.drives_si, d_hat_grid=self.d_hat_grid,
            A_table=self.A_table, phi_table=self.phi_table,
            base_params_keys=np.array(list(self.base_params.keys())),
            base_params_vals=np.array(list(self.base_params.values()), dtype=float),
            conversions_keys=np.array(list(self.conversions.keys())),
            conversions_vals=np.array(list(self.conversions.values()), dtype=float),
        )

    @classmethod
    def load(cls, path: str) -> "FDParamLibrary":
        z = np.load(path, allow_pickle=False)
        bp = {str(k): float(v) for k, v in zip(z["base_params_keys"], z["base_params_vals"])}
        cv = {str(k): float(v) for k, v in zip(z["conversions_keys"], z["conversions_vals"])}
        return cls(
            E_grid=z["E_grid"], H_grid=z["H_grid"], a0_grid=z["a0_grid"],
            drives_si=z["drives_si"], d_hat_grid=z["d_hat_grid"],
            A_table=z["A_table"], phi_table=z["phi_table"],
            base_params=bp, conversions=cv,
        )

    # ---------- geometry ----------
    @property
    def shape(self):
        return self.A_table.shape  # (n_E, n_H, n_a0, n_drive, n_d_hat)


# ============================================================
# 2) BUILDER
# ============================================================
def _simulate_one(args):
    """Top-level helper for joblib / multiprocessing pickling."""
    (E, H, a0, drv, base_params, conversions, solver_kw,
     d_start_hat, d_end_hat, n_d_hat) = args
    p = dict(base_params)
    p["E_star"] = float(E)
    p["H"] = float(H)
    p["a0"] = float(a0)
    spm_params, param_norm = build_normalized_spm_params(
        params=p, conversions=conversions, drive_si=float(drv),
        omega_drive_hat=1.0, omega_ref_hat=1.0,
    )
    solver = RK45Options(**solver_kw)
    model = SPMRK45ApproachModel(spm_params, solver=solver)
    d0 = float(param_norm["A"]) * float(d_start_hat)
    curve = model.approach_curve(
        d_start_hat=d0, d_end_hat=float(d_end_hat),
        n_points=int(n_d_hat), z0_hat=0.0, v0_hat=0.0, warm_start=True,
    )
    # Re-sample onto a fixed d_hat grid so all curves share the same axis.
    d_grid = np.linspace(float(d_start_hat * float(param_norm["A"])), float(d_end_hat), int(n_d_hat))
    order = np.argsort(curve["d_hat"])
    d_sorted = curve["d_hat"][order]
    A_sorted = curve["A_hat"][order]
    phi_sorted = curve["phi_deg"][order]
    A_resamp = np.interp(d_grid, d_sorted, A_sorted)
    phi_resamp = np.interp(d_grid, d_sorted, phi_sorted)
    return A_resamp, phi_resamp, d_grid


def build_fd_param_library(
    base_params: Dict[str, float],
    conversions: Dict[str, float],
    E_grid: np.ndarray,
    H_grid: np.ndarray,
    a0_grid: np.ndarray,
    drives_si: np.ndarray,
    solver: Optional[RK45Options] = None,
    n_d_hat: int = 160,
    d_start_factor: float = 1.25,   # d_start_hat = drive_hat * factor
    d_end_hat: float = -8.0,
    n_jobs: int = 1,
    verbose: bool = True,
    cache_path: Optional[str] = None,
) -> FDParamLibrary:
    """
    Build an FD library on the (E_star, H, a0) x drive grid.

    If `cache_path` exists, the library is loaded from there and the build
    is skipped.  After building, the library is saved to `cache_path`.
    """
    if cache_path is not None and os.path.exists(cache_path):
        if verbose:
            print(f"[lib] loading cached library from {cache_path}")
        return FDParamLibrary.load(cache_path)

    E_grid = np.asarray(E_grid, dtype=float).ravel()
    H_grid = np.asarray(H_grid, dtype=float).ravel()
    a0_grid = np.asarray(a0_grid, dtype=float).ravel()
    drives_si = np.asarray(drives_si, dtype=float).ravel()

    n_E, n_H, n_a0, n_drv = E_grid.size, H_grid.size, a0_grid.size, drives_si.size
    total = n_E * n_H * n_a0 * n_drv

    if solver is None:
        solver = RK45Options()
    solver_kw = dict(
        N_cycles=solver.N_cycles, max_windows=solver.max_windows,
        settle_windows=solver.settle_windows, tol_A=solver.tol_A,
        tol_phi_deg=solver.tol_phi_deg, consecutive=solver.consecutive,
        demod_per_ref_cycle=solver.demod_per_ref_cycle, rtol=solver.rtol,
        atol=solver.atol, dt0=solver.dt0, dt_min=solver.dt_min, dt_max=solver.dt_max,
        max_steps_per_window=solver.max_steps_per_window,
    )

    # the d_hat grid depends on drive (via d_start_hat = drive_hat * factor),
    # so per-drive we'll use a normalized [0,1] axis and store d_hat too.
    # For interpolation simplicity we pick a SINGLE d_hat grid that spans
    # the largest drive's d_start; smaller drives get clipped/extrapolated.
    largest_drive_hat = float(drives_si.max() * conversions["A"])
    d_start_hat_global = largest_drive_hat * float(d_start_factor)
    d_hat_global = np.linspace(d_start_hat_global, float(d_end_hat), int(n_d_hat))

    A_table = np.full((n_E, n_H, n_a0, n_drv, n_d_hat), np.nan, dtype=float)
    phi_table = np.full_like(A_table, np.nan)

    # build job list
    jobs = []
    idx_map = []
    for iE, E in enumerate(E_grid):
        for iH, H in enumerate(H_grid):
            for ia, a0v in enumerate(a0_grid):
                for idr, drv in enumerate(drives_si):
                    jobs.append((
                        E, H, a0v, drv,
                        base_params, conversions, solver_kw,
                        d_start_factor, d_end_hat, n_d_hat,
                    ))
                    idx_map.append((iE, iH, ia, idr))

    if verbose:
        print(f"[lib] building {total} sims  "
              f"(n_E={n_E}, n_H={n_H}, n_a0={n_a0}, n_drive={n_drv}, n_d_hat={n_d_hat})  "
              f"on {n_jobs} job(s)")

    t0 = time.time()
    if n_jobs == 1:
        for k, args in enumerate(jobs):
            A_resamp, phi_resamp, d_grid = _simulate_one(args)
            iE, iH, ia, idr = idx_map[k]
            A_table[iE, iH, ia, idr, :] = np.interp(d_hat_global, d_grid, A_resamp,
                                                     left=np.nan, right=np.nan)
            phi_table[iE, iH, ia, idr, :] = np.interp(d_hat_global, d_grid, phi_resamp,
                                                       left=np.nan, right=np.nan)
            if verbose and (k + 1) % max(1, total // 20) == 0:
                el = time.time() - t0
                eta = el / (k + 1) * (total - k - 1)
                print(f"  [{k+1:5d}/{total}]  elapsed {el:6.1f}s  ETA {eta:6.1f}s")
    else:
        try:
            from joblib import Parallel, delayed
        except ImportError as exc:
            raise RuntimeError("Install joblib (pip install joblib) to use n_jobs > 1") from exc
        results = Parallel(n_jobs=n_jobs, verbose=10 if verbose else 0)(
            delayed(_simulate_one)(args) for args in jobs
        )
        for k, (A_resamp, phi_resamp, d_grid) in enumerate(results):
            iE, iH, ia, idr = idx_map[k]
            A_table[iE, iH, ia, idr, :] = np.interp(d_hat_global, d_grid, A_resamp,
                                                     left=np.nan, right=np.nan)
            phi_table[iE, iH, ia, idr, :] = np.interp(d_hat_global, d_grid, phi_resamp,
                                                       left=np.nan, right=np.nan)

    el = time.time() - t0
    if verbose:
        print(f"[lib] done in {el:.1f}s  ({el/total*1000:.1f} ms/sim)")

    lib = FDParamLibrary(
        E_grid=E_grid, H_grid=H_grid, a0_grid=a0_grid,
        drives_si=drives_si, d_hat_grid=d_hat_global,
        A_table=A_table, phi_table=phi_table,
        base_params=dict(base_params), conversions=dict(conversions),
        solver=solver_kw,
        attrs={"d_start_factor": float(d_start_factor),
               "d_end_hat": float(d_end_hat), "n_d_hat": int(n_d_hat),
               "build_time_s": float(el)},
    )
    if cache_path is not None:
        lib.save(cache_path)
        if verbose:
            print(f"[lib] saved to {cache_path}")
    return lib


# ============================================================
# 3) SURROGATE INTERPOLATOR
# ============================================================
class FDSurrogate:
    """
    Cheap evaluator: given (E_star, H, a0) -> per-drive (A_hat[d], phi[d]) curves.

    Uses scipy RegularGridInterpolator (linear) over the 3-D parameter grid;
    drive index and d_hat are sampled discretely.
    """

    def __init__(self, library: FDParamLibrary, method: str = "linear"):
        self.lib = library
        # Interpolators: one per (drive_idx, channel) returning the (n_d_hat,) vector.
        # Trick: pack (n_drive, n_d_hat) into the trailing dims and let RGI broadcast.
        # values shape -> (n_E, n_H, n_a0, n_drive*n_d_hat)
        n_E, n_H, n_a0, n_drv, n_d = library.A_table.shape
        A_flat = library.A_table.reshape(n_E, n_H, n_a0, n_drv * n_d)
        phi_flat = library.phi_table.reshape(n_E, n_H, n_a0, n_drv * n_d)
        pts = (library.E_grid, library.H_grid, library.a0_grid)
        self._interp_A = RegularGridInterpolator(pts, A_flat, method=method,
                                                   bounds_error=False, fill_value=np.nan)
        self._interp_phi = RegularGridInterpolator(pts, phi_flat, method=method,
                                                    bounds_error=False, fill_value=np.nan)
        self._n_drv = n_drv
        self._n_d = n_d

    def evaluate(self, E_star: float, H: float, a0: float):
        """Return (A_table[n_drive, n_d], phi_table[n_drive, n_d]) at (E*, H, a0)."""
        q = np.array([[float(E_star), float(H), float(a0)]])
        A = self._interp_A(q).reshape(self._n_drv, self._n_d)
        phi = self._interp_phi(q).reshape(self._n_drv, self._n_d)
        return A, phi


# ============================================================
# 4) SURROGATE CALIBRATOR
# ============================================================
@dataclass
class SurrogateCalibrationConfig:
    fit_keys: Tuple[str, ...] = ("E_star", "H", "a0", "phase_offset_deg")
    phase_weight: float = 1.0
    free_phase_weight: float = 2.0
    threshold_weight: float = 6.0
    setpoint_min_pct: float = 30.0
    setpoint_max_pct: float = 92.0
    threshold_phase_deg: float = 90.0
    jump_min_deg: float = 15.0
    bistable_jump_penalty: float = 100.0
    interp_branch: str = "auto"


class FDSurrogateCalibrator:
    """
    Same loss decomposition as FDOnlyCalibrator, but evaluates the forward
    model via interpolation in the precomputed library, NOT via the ODE.
    """

    def __init__(self,
                 library: FDParamLibrary,
                 fd_curves: Sequence[FDCalibrationCurve],
                 config: Optional[SurrogateCalibrationConfig] = None,
                 surrogate_method: str = "linear"):
        self.lib = library
        self.fd_curves = list(fd_curves)
        self.config = config if config is not None else SurrogateCalibrationConfig()
        self.surr = FDSurrogate(library, method=surrogate_method)

        # Map each experimental curve to a library drive index (nearest).
        self._drive_idx = []
        for fd in self.fd_curves:
            i = int(np.argmin(np.abs(self.lib.drives_si - float(fd.drive_si))))
            err_pct = abs(self.lib.drives_si[i] - fd.drive_si) / fd.drive_si * 100.0
            if err_pct > 5.0:
                print(f"[warn] drive {fd.drive_si*1e9:.2f} nm not in library "
                      f"(nearest = {self.lib.drives_si[i]*1e9:.2f} nm, err {err_pct:.1f}%)")
            self._drive_idx.append(i)

        # Auto-detect thresholds in the experimental data once.
        for fd in self.fd_curves:
            if fd.threshold_setpoint_pct is None:
                fd.threshold_setpoint_pct = detect_threshold_setpoint(
                    fd.setpoint_pct, fd.phase_deg,
                    self.config.threshold_phase_deg,
                    self.config.jump_min_deg,
                )

    # ---- branch-aware sim → setpoint axis interpolation ----
    @staticmethod
    def _sim_to_setpoint(d_hat, A_hat, phi):
        far = int(np.argmax(d_hat))
        A_free = float(A_hat[far])
        if A_free <= 0 or not np.isfinite(A_free):
            return None, None, None, np.nan
        return A_hat / A_free * 100.0, phi, d_hat, A_free

    @staticmethod
    def _interp_phase_at(sp_sim, phi_sim, sp_query):
        order = np.argsort(sp_sim)
        sp_s = sp_sim[order]
        phi_s = phi_sim[order]
        keep = np.concatenate([[True], np.diff(sp_s) > 1e-9])
        return np.interp(sp_query, sp_s[keep], phi_s[keep], left=np.nan, right=np.nan)

    @staticmethod
    def _find_threshold_sp(sp_sim, phi_sim, d_sim, threshold_phase_deg=90.0):
        order = np.argsort(-d_sim)
        sp = sp_sim[order]
        ph = phi_sim[order]
        for i in range(1, ph.size):
            if ph[i - 1] >= threshold_phase_deg > ph[i]:
                if ph[i] == ph[i - 1]:
                    return float(0.5 * (sp[i - 1] + sp[i]))
                t = (threshold_phase_deg - ph[i - 1]) / (ph[i] - ph[i - 1])
                return float(sp[i - 1] + t * (sp[i] - sp[i - 1]))
        return np.nan

    # ---- loss ----
    def loss(self, theta: Dict[str, float]) -> float:
        cfg = self.config
        E = float(theta.get("E_star", self.lib.base_params["E_star"]))
        H = float(theta.get("H", self.lib.base_params["H"]))
        a0 = float(theta.get("a0", self.lib.base_params["a0"]))
        phase_offset = float(theta.get("phase_offset_deg", 0.0))

        try:
            A_all, phi_all = self.surr.evaluate(E, H, a0)
        except Exception:
            return 1e20
        if not np.all(np.isfinite(A_all)) or not np.all(np.isfinite(phi_all)):
            return 1e20

        d_sim = self.lib.d_hat_grid
        total = 0.0
        n_terms = 0

        for k, fd in enumerate(self.fd_curves):
            j = self._drive_idx[k]
            A_hat = A_all[j]
            phi = phi_all[j] + phase_offset
            sp_sim, phi_sim, d_arr, A_free_hat = self._sim_to_setpoint(d_sim, A_hat, phi)
            if sp_sim is None:
                return 1e20

            # phase curve term
            if cfg.phase_weight > 0:
                m = (fd.setpoint_pct >= cfg.setpoint_min_pct) & (fd.setpoint_pct <= cfg.setpoint_max_pct)
                if np.any(m):
                    phi_at = self._interp_phase_at(sp_sim, phi_sim, fd.setpoint_pct[m])
                    valid = np.isfinite(phi_at)
                    if np.any(valid):
                        r = phi_at[valid] - fd.phase_deg[m][valid]
                        total += cfg.phase_weight * float(np.mean(r * r))
                        n_terms += 1

            # free-phase term
            if cfg.free_phase_weight > 0:
                far_sim = float(phi_sim[int(np.argmax(d_arr))])
                r = far_sim - float(fd.free_phase_deg)
                total += cfg.free_phase_weight * float(r * r)
                n_terms += 1

            # threshold term
            if cfg.threshold_weight > 0 and fd.threshold_setpoint_pct is not None:
                sp_th_sim = self._find_threshold_sp(sp_sim, phi_sim, d_arr, cfg.threshold_phase_deg)
                if np.isfinite(sp_th_sim):
                    r = sp_th_sim - float(fd.threshold_setpoint_pct)
                    total += cfg.threshold_weight * float(r * r)
                else:
                    total += cfg.threshold_weight * cfg.bistable_jump_penalty
                n_terms += 1

        return float(total / max(n_terms, 1))

    # ---- fit ----
    def fit(self, bounds: Dict[str, Tuple[float, float]],
            method: str = "differential_evolution",
            de_maxiter: int = 60, seed: int = 0, polish: bool = True,
            x0: Optional[Dict[str, float]] = None, verbose: bool = False):
        names = list(bounds.keys())
        bnds = [bounds[n] for n in names]

        def vec_to_theta(x):
            return {n: float(x[i]) for i, n in enumerate(names)}

        def obj(x):
            v = self.loss(vec_to_theta(x))
            if verbose:
                print(f"  loss={v:.5f}  theta={vec_to_theta(x)}")
            return v

        if method == "differential_evolution":
            res = differential_evolution(obj, bounds=bnds, maxiter=de_maxiter, seed=seed,
                                          polish=False)
            x_best = res.x.copy()
            f_best = float(res.fun)
            if polish:
                res2 = minimize(obj, x_best, method="Powell", bounds=bnds)
                if float(res2.fun) < f_best:
                    x_best, f_best = res2.x.copy(), float(res2.fun)
        else:
            x0_arr = (np.array([x0[n] for n in names])
                      if x0 is not None else
                      np.array([0.5 * (b[0] + b[1]) for b in bnds]))
            res = minimize(obj, x0_arr, method=method, bounds=bnds)
            x_best = res.x.copy()
            f_best = float(res.fun)

        return {
            "theta_best": vec_to_theta(x_best),
            "loss_best": f_best,
            "result": res,
        }

    # ---- diagnostic plot ----
    def plot_fit(self, theta, figsize=(11, 8), only_drive_indices=None):
        E = float(theta.get("E_star", self.lib.base_params["E_star"]))
        H = float(theta.get("H", self.lib.base_params["H"]))
        a0 = float(theta.get("a0", self.lib.base_params["a0"]))
        po = float(theta.get("phase_offset_deg", 0.0))
        A_all, phi_all = self.surr.evaluate(E, H, a0)
        d_sim = self.lib.d_hat_grid

        fig, ax = plt.subplots(figsize=figsize)
        idxs = range(len(self.fd_curves)) if only_drive_indices is None else only_drive_indices
        colors = plt.cm.viridis(np.linspace(0, 0.92, len(list(idxs))))
        for col, k in zip(colors, idxs):
            fd = self.fd_curves[k]
            j = self._drive_idx[k]
            A_hat, phi = A_all[j], phi_all[j] + po
            sp_sim, phi_sim, d_arr, _ = self._sim_to_setpoint(d_sim, A_hat, phi)
            ax.plot(fd.setpoint_pct, fd.phase_deg, "-", color=col, lw=1.6,
                    label=f"Exp d={fd.drive_si*1e9:.0f}nm")
            order = np.argsort(-d_arr)
            ax.plot(sp_sim[order], phi_sim[order], "--", color=col, lw=1.2, alpha=0.75)
        ax.set_xlabel("Setpoint (%)")
        ax.set_ylabel("Phase (deg)")
        ax.set_xlim(0, 100); ax.set_ylim(0, 180)
        ax.grid(alpha=0.3); ax.legend(fontsize=8, ncol=2)
        ax.set_title(f"Surrogate fit  loss={self.loss(theta):.3g}  "
                      f"(E={E:.2g}, H={H:.2g}, a0={a0:.2e})")
        fig.tight_layout()
        return fig, ax


# ============================================================
# 5) END-TO-END WORKFLOW EXAMPLE
# ============================================================
if __name__ == "__main__":
    # ---- (i) base setup, identical to your main script ----
    base_params = {
        "k": 1.0, "A": 100e-9, "d0": 100e-9 * 1.25,
        "a0": 0.164e-9, "R": 20e-9, "f0": 75e3, "Q": 200,
        "E_star": 1 / ((1 - 0.3 ** 2) / 130e9 + (1 - 0.3 ** 2) / 1.2e9),
        "H": 7.1e-20,
    }
    conversions = {
        "k": 1, "A": 1e9, "d0": 1e9, "a0": 1e9, "R": 1e9,
        "f0": 1 / (2 * np.pi * base_params["f0"]), "Q": 1,
        "E_star": 1e-9 / base_params["k"],
        "H": 1 / (base_params["k"] * (1e-9) ** 2),
    }
    solver = RK45Options(N_cycles=15, max_windows=25, settle_windows=1,
                          tol_A=2e-4, tol_phi_deg=2e-2, consecutive=2,
                          demod_per_ref_cycle=24, rtol=1e-5, atol=1e-8,
                          dt0=0.02, dt_min=1e-10, dt_max=0.3,
                          max_steps_per_window=120000)

    drives_si = np.array([7, 13, 18, 24, 29, 34, 39, 45, 50, 53,
                          66, 79, 92, 105, 117], dtype=float) * 1e-9

    # ---- (ii) BUILD library ONCE (cached after first run) ----
    # Use a SUBSET of 5-6 drives for material fitting; library stores them all.
    E0 = base_params["E_star"]
    H0 = base_params["H"]
    a0_0 = base_params["a0"]
    E_grid = np.geomspace(E0 * 0.4, E0 * 2.5, 6)     # log-spaced (~3 decades robust)
    H_grid = np.geomspace(H0 * 0.4, H0 * 2.5, 6)
    a0_grid = np.linspace(a0_0 * 0.6, a0_0 * 1.8, 6)  # linear
    lib = build_fd_param_library(
        base_params=base_params, conversions=conversions,
        E_grid=E_grid, H_grid=H_grid, a0_grid=a0_grid,
        drives_si=drives_si, solver=solver,
        n_d_hat=140, d_start_factor=1.25, d_end_hat=-7.0,
        n_jobs=1,                    # bump to 4-8 if joblib available
        cache_path="fd_param_library.npz",
        verbose=True,
    )

    # ---- (iii) load YOUR experimental FD curves ----
    # Replace this stub with your actual loader (see fast-calibration script).
    n_pix = 1007
    amplitude_nm = np.empty((drives_si.size, n_pix))
    phase_deg = np.empty((drives_si.size, n_pix))
    for i, drv in enumerate(drives_si):
        sp = np.linspace(95, 5, n_pix)
        amplitude_nm[i] = drv * 1e9 * sp / 100.0
        phase_deg[i] = 90.0 + 18.0 * np.exp(-((sp - 70) ** 2) / 200.0) - 55.0 * (sp < 50)
    fd_curves = [
        FDCalibrationCurve(drive_si=float(drives_si[i]),
                            amplitude_nm=amplitude_nm[i], phase_deg=phase_deg[i])
        for i in range(drives_si.size)
    ]

    # ---- (iv) instantiate surrogate calibrator and FIT (seconds!) ----
    cfg = SurrogateCalibrationConfig(
        fit_keys=("E_star", "H", "a0", "phase_offset_deg"),
        phase_weight=1.0, free_phase_weight=2.0, threshold_weight=8.0,
        setpoint_min_pct=30.0, setpoint_max_pct=92.0,
    )
    cal = FDSurrogateCalibrator(lib, fd_curves, cfg, surrogate_method="linear")
    bounds = {
        "E_star": (E_grid.min(), E_grid.max()),
        "H":      (H_grid.min(), H_grid.max()),
        "a0":     (a0_grid.min(), a0_grid.max()),
        "phase_offset_deg": (-20.0, 20.0),
    }

    t0 = time.time()
    res = cal.fit(bounds, method="differential_evolution", de_maxiter=80,
                   seed=0, polish=True, verbose=False)
    print(f"[fit] done in {time.time()-t0:.1f}s    loss={res['loss_best']:.4f}")
    print("theta_best =", res["theta_best"])

    # ---- (v) optional verification: one full-fidelity sim at the optimum ----
    # from fd_only_calibration import FDOnlyCalibrator, FDCalibrationConfig
    # verify_cfg = FDCalibrationConfig(**cfg.__dict__)
    # verify = FDOnlyCalibrator(fd_curves, base_params, conversions, solver, verify_cfg)
    # full_loss = verify.loss(res["theta_best"])
    # print(f"surrogate-loss = {res['loss_best']:.4f}, full-fidelity-loss = {full_loss:.4f}")

    cal.plot_fit(res["theta_best"])
    plt.show()
