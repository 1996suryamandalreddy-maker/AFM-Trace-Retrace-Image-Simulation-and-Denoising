# 11.4  plot_figure_4 — fully self-contained Figure 4 for the expscan dataset.
def plot_figure_4(bundle, save_to=None, stem='figure_4_expscan_PI_fit_nature'):
    """Render Figure 4 from a bundle dict.

    Layout (3x3):
      row 1: (a) synthetic h_truth (median of cleanest exp traces) vs traces
             (b) PI loss surface for the cleanest GP-train condition
             (c) fitted log10(P,I) vs GP-predicted log10(P,I)
      row 2: (d) optimal held-out condition overlay
             (e) sub-optimal (P85) held-out condition overlay
             (f) DT-vs-exp scan-quality scatter
      row 3: (g, h, i) best / median / P85 held-out trace overlays
    """
    setup_style()
    traces_exp = bundle['traces_exp']
    h_truth = bundle['h_truth']
    fit_idx = bundle['fit_idx']; test_idx = bundle['test_idx']
    dt_PI = bundle['dt_PI']
    drive = bundle['drive']; sp = bundle['setpoint']; ig = bundle['igain']
    P_all = bundle['P_all']; I_all = bundle['I_all']
    clean_pick = bundle['clean_pick']
    q_exp = bundle['q_exp']; q_PI = bundle['q_PI']
    oracle = bundle['oracle_PI']

    fig = plt.figure(figsize=(7.2, 8.2), constrained_layout=False)
    gs = gridspec.GridSpec(3, 3, figure=fig,
                            height_ratios=[1.0, 1.05, 1.05],
                            width_ratios=[1.05, 1.0, 1.1])
    fig.subplots_adjust(left=0.085, right=0.985, bottom=0.085, top=0.88,
                        wspace=0.55, hspace=0.80)
    fig.suptitle('Calibrating the PI loop of the digital twin against experimental scan lines',
                 x=0.06, y=0.96, ha='left', fontsize=9.7, fontweight='bold')

    # (a) h_truth vs clean experimental traces
    ax = fig.add_subplot(gs[0, 0]); panel_label(ax, 'a')
    for k, ci in enumerate(clean_pick[:6]):
        ax.plot(_center(traces_exp[int(ci), 0]), lw=0.7,
                color=PALETTE['grey'], alpha=0.7,
                label='clean experimental traces' if k == 0 else None)
    ax.plot(_center(h_truth), color=PALETTE['blue'], lw=1.7,
            label=r'synthetic $h_{\mathrm{truth}}$')
    ax.set_xlabel('pixel'); ax.set_ylabel('height (nm)')
    ax.set_title('Synthetic profile mirrors\nthe topo geometry')
    ax.legend(frameon=False, loc='lower center', fontsize=6.6)

    # (b) PI loss surface for the cleanest GP-train condition
    ax = fig.add_subplot(gs[0, 1]); panel_label(ax, 'b')
    P_grid = bundle['loss_P_grid']; I_grid = bundle['loss_I_grid']; L = bundle['loss_L']
    cond_for_surf = int(bundle['loss_cond'])
    im = ax.pcolormesh(np.log10(P_grid), np.log10(I_grid),
                       np.log10(np.maximum(L, 1e-12)).T,
                       shading='auto', cmap='magma_r')
    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.025)
    cb.set_label(r'$\log_{10}$ loss')
    if cond_for_surf in oracle:
        p_star = oracle[cond_for_surf]['log10_P']
        i_star = oracle[cond_for_surf]['log10_I']
        ax.plot(p_star, i_star, marker='*', color=PALETTE['teal'], markersize=10,
                markeredgecolor='white', markeredgewidth=0.8,
                label=f"fitted (P*,I*) = ({oracle[cond_for_surf]['P']:.2f},{oracle[cond_for_surf]['I']:.2f})")
        ax.legend(frameon=False, fontsize=6.2, loc='lower right')
    ax.set_xlabel(r'$\log_{10} P$'); ax.set_ylabel(r'$\log_{10} I$')
    ax.set_title(f'PI loss surface\n(cond {cond_for_surf})')

    # (c) fitted (P,I) vs GP-predicted, with R^2 + best-fit slope annotation.
    # The P-gain points lie tight to y=x while the I-gain points scatter,
    # which is the headline message — quantify it inline.
    ax = fig.add_subplot(gs[0, 2]); panel_label(ax, 'c')
    o_idx = bundle['oracle_cond']
    fit_log10P = bundle['oracle_log10P']; fit_log10I = bundle['oracle_log10I']
    pred_logP = np.log10(np.maximum(P_all[o_idx], 1e-12))
    pred_logI = np.log10(np.maximum(I_all[o_idx], 1e-12))

    def _fit_stats(x, y):
        m = np.isfinite(x) & np.isfinite(y)
        if m.sum() < 3: return float('nan'), float('nan'), float('nan')
        x, y = x[m], y[m]
        slope, intercept = np.polyfit(x, y, 1)
        ss_res = float(np.sum((y - (slope*x + intercept))**2))
        ss_tot = float(np.sum((y - np.mean(y))**2)) + 1e-12
        r2 = 1.0 - ss_res / ss_tot
        return float(slope), float(intercept), float(r2)

    sP, iP, r2P = _fit_stats(fit_log10P, pred_logP)
    sI, iI, r2I = _fit_stats(fit_log10I, pred_logI)

    ax.scatter(fit_log10P, pred_logP, s=14, color=PALETTE['blue'],
               edgecolor='white', lw=0.4, label=f'P  ($R^2$={r2P:.2f}, slope={sP:.2f})')
    ax.scatter(fit_log10I, pred_logI, s=14, color=PALETTE['orange'],
               marker='D', edgecolor='white', lw=0.4, label=f'I  ($R^2$={r2I:.2f}, slope={sI:.2f})')
    lo = float(min(fit_log10P.min(), fit_log10I.min(), pred_logP.min(), pred_logI.min()))
    hi = float(max(fit_log10P.max(), fit_log10I.max(), pred_logP.max(), pred_logI.max()))
    xs = np.linspace(lo, hi, 64)
    # Highlight the P linear fit (this is the headline observation).
    if np.isfinite(sP):
        ax.plot(xs, sP * xs + iP, color=PALETTE['blue'], lw=1.0, alpha=0.85,
                label='P linear fit')
    ax.plot([lo, hi], [lo, hi], color=PALETTE['muted'], lw=0.6, ls='--', label='y = x')
    ax.set_xlabel(r'fitted $\log_{10}$ (P or I)')
    ax.set_ylabel(r'GP-predicted')
    ax.set_title('GP map generalizes\nacross controls')
    ax.legend(frameon=False, fontsize=6.0, loc='upper left')
    # Anchor a one-line take-away below the legend.
    ax.text(0.02, 0.04,
            r'P: tight linear map ($R^2$' + f'={r2P:.2f}); I: weaker map',
            transform=ax.transAxes, fontsize=5.8, color=PALETTE['muted'],
            ha='left', va='bottom')

    # Row 2: optimal / sub-optimal selection from the held-out set.
    # The PI loop saturates on some test conditions producing 1000+ nm outputs;
    # pick the sub-optimal at the 85th percentile (not the absolute worst).
    q_test = q_exp[test_idx]
    order_t = np.argsort(q_test)
    cond_opt = int(test_idx[order_t[0]])
    n_t = len(order_t)
    cond_sub = int(test_idx[order_t[max(0, int(0.85 * n_t) - 1)]])
    for axslot, i, ttl, c, lbl in [
        (gs[1, 0], cond_opt, 'Optimal condition',     PALETTE['blue'], 'd'),
        (gs[1, 1], cond_sub, 'Sub-optimal condition', PALETTE['red'],  'e')]:
        ax = fig.add_subplot(axslot); panel_label(ax, lbl)
        ax.plot(_center(traces_exp[i, 0]), color=PALETTE['ink'], lw=1.0)
        ax.plot(_center(traces_exp[i, 1]), color=PALETTE['ink'], lw=0.9, ls=':', alpha=0.85)
        ax.plot(_center(dt_PI[i, 0]), color=c, lw=1.0)
        ax.plot(_center(dt_PI[i, 1]), color=c, lw=0.9, ls=':', alpha=0.85)
        ax.set_xlabel('pixel'); ax.set_ylabel('height (nm)')
        ax.set_title(f'{ttl}\nd={float(drive[i]):.1f} nm, sp={float(sp[i]):.2f}, '
                     f'Ig={float(ig[i]):.0f}')

    # (f) DT-vs-exp scan-quality scatter
    ax = fig.add_subplot(gs[1, 2]); panel_label(ax, 'f')
    ax.scatter(q_exp[fit_idx], q_PI[fit_idx], s=8, color=PALETTE['blue'],
               edgecolor='white', lw=0.2, alpha=0.65, label='train')
    ax.scatter(q_exp[test_idx], q_PI[test_idx], s=18, color=PALETTE['orange'],
               marker='D', edgecolor='white', lw=0.3, label='held-out')
    qmax = float(np.nanpercentile(np.concatenate([
        q_exp[fit_idx], q_PI[fit_idx], q_exp[test_idx], q_PI[test_idx]]), 90))
    qmax = max(qmax, 8.0)
    ax.plot([0, qmax], [0, qmax], color=PALETTE['muted'], lw=0.6, ls='--')
    ax.set_xlim(0, qmax); ax.set_ylim(0, qmax)
    ax.set_xlabel('experimental scan quality (nm)')
    ax.set_ylabel('DT-simulated scan quality (nm)')
    ax.set_title('Scan-quality recovery')
    ax.legend(frameon=False, fontsize=6.4, loc='upper left')

    # Row 3: best / median / P85 held-out trace overlays, filtered for plausibility.
    def _bounded(i, max_abs=50.0):
        v = dt_PI[i][np.isfinite(dt_PI[i])]
        return v.size and float(np.max(np.abs(v))) < max_abs
    order = np.argsort(q_exp[test_idx])
    bounded_test = [int(test_idx[k]) for k in order if _bounded(int(test_idx[k]))]
    if not bounded_test:
        bounded_test = [int(test_idx[k]) for k in order]
    picks = [bounded_test[0],
             bounded_test[len(bounded_test) // 2],
             bounded_test[max(0, int(0.85 * len(bounded_test)) - 1)]]
    titles = ['best held-out', 'median held-out', 'P85 held-out']
    for col, (i, ttl) in enumerate(zip(picks, titles)):
        ax = fig.add_subplot(gs[2, col]); panel_label(ax, 'ghi'[col])
        ax.plot(_center(traces_exp[i, 0]), color=PALETTE['ink'], lw=0.9)
        ax.plot(_center(traces_exp[i, 1]), color=PALETTE['ink'], lw=0.9, ls=':', alpha=0.8)
        ax.plot(_center(dt_PI[i, 0]), color=PALETTE['blue'], lw=0.9)
        ax.plot(_center(dt_PI[i, 1]), color=PALETTE['blue'], lw=0.9, ls=':', alpha=0.8)
        ax.set_xlabel('pixel'); ax.set_ylabel('height (nm)')
        ax.set_title(f'{ttl}\nd={float(drive[i]):.1f} nm, sp={float(sp[i]):.2f}, '
                     f'Ig={float(ig[i]):.0f}')

    leg_handles = [
        Line2D([0],[0], color=PALETTE['ink'],  lw=1.0, label='experiment (trace)'),
        Line2D([0],[0], color=PALETTE['ink'],  lw=0.9, ls=':', label='experiment (retrace)'),
        Line2D([0],[0], color=PALETTE['blue'], lw=1.0, label='DT trace (PI-fit)'),
        Line2D([0],[0], color=PALETTE['blue'], lw=0.9, ls=':', label='DT retrace (PI-fit)'),
        Line2D([0],[0], color=PALETTE['red'],  lw=1.0, label='DT trace (sub-optimal cond.)'),
    ]
    fig.legend(handles=leg_handles, loc='lower center',
               bbox_to_anchor=(0.5, 0.005), ncol=5, frameon=False,
               fontsize=6.4, handletextpad=0.5, columnspacing=1.2)

    if save_to is not None:
        paths = save_pub(fig, save_to, stem)
        print('Saved Figure 4:', paths['png'])
    return fig
