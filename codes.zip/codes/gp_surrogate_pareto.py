"""
GP surrogate + Pareto exploration for SPM digital-twin operating-point design.

Stage-2 helper for a calibrated SPM digital twin.  Given a scanner DT, this
module:

  (1) samples a design over (drive_nm, setpoint, P, I, scan_speed_hat),
  (2) simulates Q (quality) and S (safety) at each design point with K
      replicate ground-truth surfaces drawn from the same roughness as the real
      sample,
  (3) fits heteroscedastic Gaussian-process surrogates for Q and S,
  (4) extracts the constrained Pareto frontier (max Q subject to S >= S_thresh),
  (5) proposes the next experiment by constrained expected improvement, and
  (6) validates the surrogate by holding out a portion of the design points.

The scanner and synthetic-surface APIs are abstracted behind small adapters
near the top of the file; edit `default_extract`, `generate_truth_ensemble`,
and the `simulate_at_point` call site to match your exact signatures.

Notes
-----
* Uses scikit-learn for the GP so the file runs without torch / BoTorch.  For
  true multi-objective Bayesian optimisation with EHVI the recommended upgrade
  is BoTorch; the API here is structured so the GP and acquisition can be
  swapped without touching the rest of the pipeline.
* The Q metric here is trace/retrace agreement normalised by truth roughness;
  the S metric is the probability that the cantilever amplitude never drops
  below `A_crash`.  Both are easy to extend - they are reduced to scalars in
  `quality_one` / `safety_one`.
* Heteroscedasticity is handled by passing per-point variance as `alpha` to
  `GaussianProcessRegressor`, and by using a Beta(1+s, 1+K-s) posterior for the
  Bernoulli safety variance so the GP does not see zero noise when all K
  replicates agree.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional, Sequence

import numpy as np
from scipy.stats import norm, qmc
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel, Matern
from sklearn.preprocessing import StandardScaler


# ---------------------------------------------------------------------------
# 1. Design space and sampling
# ---------------------------------------------------------------------------

@dataclass
class DesignSpace:
    """Bounds on the five controllable variables.  Edit to match your rig."""
    drive_nm:       tuple = (5.0, 25.0)
    setpoint:       tuple = (0.3, 0.9)
    P:              tuple = (1.0, 30.0)    # already in scanner units (post 50x)
    I:              tuple = (1.0, 40.0)
    scan_speed_hat: tuple = (0.2, 5.0)

    @property
    def bounds(self) -> np.ndarray:
        return np.array([self.drive_nm, self.setpoint, self.P, self.I,
                         self.scan_speed_hat], dtype=float)

    @property
    def names(self) -> list:
        return ["drive_nm", "setpoint", "P", "I", "scan_speed_hat"]


def sample_design(space: DesignSpace, n: int, seed: int = 0) -> np.ndarray:
    """Scrambled-Sobol design of `n` points; returns array (n, 5)."""
    sampler = qmc.Sobol(d=5, scramble=True, seed=seed)
    u = sampler.random(n)
    lo, hi = space.bounds[:, 0], space.bounds[:, 1]
    return lo + u * (hi - lo)


# ---------------------------------------------------------------------------
# 2. Adapters to your scanner and synthetic-surface generator.
#    Edit these to match your real API; the rest of the module is generic.
# ---------------------------------------------------------------------------

def make_fd_cache(scanner, drives_nm: Sequence[float],
                  n_d: int = 4096) -> dict:
    """Pre-compute one FD table per (rounded) drive amplitude."""
    cache: dict = {}
    for d in drives_nm:
        key = round(float(d), 2)
        if key not in cache:
            cache[key] = scanner.prepare_fd_table_for_drive(drive_nm=key, n_d=n_d)
    return cache


def get_fd(scanner, fd_cache: dict, drive_nm: float, n_d: int = 4096):
    """Look up (or build and cache) the FD table for one drive amplitude."""
    key = round(float(drive_nm), 2)
    if key not in fd_cache:
        fd_cache[key] = scanner.prepare_fd_table_for_drive(drive_nm=key, n_d=n_d)
    return fd_cache[key]


def generate_truth_ensemble(generate_synthetic_scan_line, h_map, K: int,
                            n_pixels: int = 256, dx_hat: float = 1.0,
                            scan_speed_hat_gen: float = 1e3,
                            corr_sigma_px: float = 1.0,
                            seed0: int = 0) -> list:
    """Draw K synthetic ground-truth lines with the same roughness as h_map."""
    surfaces = []
    for k in range(K):
        pack = generate_synthetic_scan_line(
            h_map,
            n_pixels=n_pixels,
            dx_hat=dx_hat,
            scan_speed_hat=scan_speed_hat_gen,
            mode="filtered_iid",
            direction="x",
            corr_sigma_px=corr_sigma_px,
            random_state=seed0 + k,
        )
        surfaces.append(np.asarray(pack["generated"]["h_hat"]))
    return surfaces


def default_extract(out: dict) -> dict:
    """Extract trace/retrace h and amplitude trajectories from one DT call.

    EDIT THIS if your scanner's output dict uses different keys."""
    return {
        "h_T": np.asarray(out["trace"]["h"]),
        "h_R": np.asarray(out["retrace"]["h"]),
        "A_T": np.asarray(out["trace"]["A"]),
        "A_R": np.asarray(out["retrace"]["A"]),
    }


# ---------------------------------------------------------------------------
# 3. Quality and safety reductions
# ---------------------------------------------------------------------------

def quality_one(h_T: np.ndarray, h_R: np.ndarray,
                h_truth: np.ndarray) -> float:
    """Trace-retrace agreement normalised by truth roughness.

    Q = 1 - RMSE(trace, retrace) / Rq(truth).
    Q = 1 means perfect trace/retrace overlap; Q can go negative for very poor
    tracking.
    """
    Rq_truth = float(np.std(h_truth)) + 1e-12
    rmse_tr = float(np.sqrt(np.mean((h_T - h_R) ** 2)))
    return 1.0 - rmse_tr / Rq_truth


def safety_one(A_T: np.ndarray, A_R: np.ndarray, A_crash: float,
               F_proxy_max: Optional[float] = None,
               h_T: Optional[np.ndarray] = None,
               h_R: Optional[np.ndarray] = None) -> int:
    """Return 1 if the line is safe, 0 otherwise.

    Safety = (min amplitude > A_crash) AND optional (max |dh/dx| < F_proxy_max).
    """
    a_min = min(float(np.min(A_T)), float(np.min(A_R)))
    if a_min <= A_crash:
        return 0
    if F_proxy_max is not None and h_T is not None and h_R is not None:
        g = np.concatenate([np.diff(h_T), np.diff(h_R)])
        if float(np.max(np.abs(g))) > F_proxy_max:
            return 0
    return 1


def simulate_at_point(scanner, h_truth_ensemble: list, point: np.ndarray,
                      fd_cache: dict, A_crash: float = 0.2,
                      F_proxy_max: Optional[float] = None,
                      n_substeps: int = 50, dx_hat: float = 1.0,
                      h_smooth_sigma_px: float = 0.0,
                      extract: Callable = default_extract) -> dict:
    """Run K replicates of the DT at one design point.

    Returns
    -------
    dict with keys Q_mean, Q_var, S_mean, S_var, K.

    Q_var is the standard-error variance of the mean of K i.i.d. estimates.
    S_var uses a Beta(1+s, 1+K-s) posterior so it stays > 0 even when all K
    replicates agree, which is what the heteroscedastic GP needs.
    """
    drive_nm, setpoint, P, I, scan_speed_hat = (float(v) for v in point)
    fd = get_fd(scanner, fd_cache, drive_nm)

    Qs: list = []
    Ss: list = []
    for h_truth in h_truth_ensemble:
        out = scanner.simulate_trace_retrace_substeps_fast(
            h_truth,
            drive_nm=drive_nm,
            setpoint=setpoint,
            P=P,
            I=I,
            scan_speed_hat=scan_speed_hat,
            dx_hat=dx_hat,
            n_substeps=n_substeps,
            fd_table=fd,
            h_smooth_sigma_px=h_smooth_sigma_px,
            d_init_hat=0,
            A_meas_init_hat=1,
        )
        ch = extract(out)
        Qs.append(quality_one(ch["h_T"], ch["h_R"], h_truth))
        Ss.append(safety_one(ch["A_T"], ch["A_R"], A_crash, F_proxy_max,
                             ch["h_T"], ch["h_R"]))

    Qa = np.asarray(Qs, dtype=float)
    Sa = np.asarray(Ss, dtype=float)
    K = len(Qa)
    s_sum = int(Sa.sum())
    p_post = (1.0 + s_sum) / (2.0 + K)
    s_var = p_post * (1.0 - p_post) / (3.0 + K)
    q_var = float(np.var(Qa, ddof=1) / K) if K > 1 else 1e-3
    return {
        "Q_mean": float(np.mean(Qa)),
        "Q_var": max(q_var, 1e-6),
        "S_mean": float(s_sum / K),
        "S_var": float(s_var),
        "K": K,
    }


# ---------------------------------------------------------------------------
# 4. Heteroscedastic GP surrogate
# ---------------------------------------------------------------------------

class HeteroscedasticGP:
    """sklearn GPR wrapped with input scaling and per-point noise variance.

    The kernel is Matern(nu=2.5) * constant; inputs are z-scored before fitting
    so a single ARD-free length scale is well-behaved across all five
    dimensions.  If you have many design points (>500) consider switching to
    GPyTorch or BoTorch for ARD and faster inference.
    """

    def __init__(self, length_scale_bounds: tuple = (1e-2, 1e2),
                 nu: float = 2.5, noise_floor: float = 1e-6):
        self.kernel = (ConstantKernel(1.0, (1e-3, 1e3))
                       * Matern(length_scale=1.0,
                                length_scale_bounds=length_scale_bounds,
                                nu=nu))
        self.noise_floor = noise_floor
        self.scaler = StandardScaler()
        self.gp: Optional[GaussianProcessRegressor] = None
        self.y_mean = 0.0

    def fit(self, X: np.ndarray, y: np.ndarray,
            y_var: np.ndarray) -> "HeteroscedasticGP":
        Xs = self.scaler.fit_transform(np.asarray(X, dtype=float))
        y = np.asarray(y, dtype=float)
        self.y_mean = float(np.mean(y))
        alpha = np.maximum(np.asarray(y_var, dtype=float), self.noise_floor)
        self.gp = GaussianProcessRegressor(
            kernel=self.kernel, alpha=alpha,
            normalize_y=False, n_restarts_optimizer=4, random_state=0,
        )
        self.gp.fit(Xs, y - self.y_mean)
        return self

    def predict(self, X: np.ndarray, return_std: bool = True):
        assert self.gp is not None, "Call fit() first."
        Xs = self.scaler.transform(np.asarray(X, dtype=float))
        mu, std = self.gp.predict(Xs, return_std=True)
        mu = mu + self.y_mean
        if return_std:
            return mu, std
        return mu


def fit_surrogates(X: np.ndarray, Q_mean: np.ndarray, Q_var: np.ndarray,
                   S_mean: np.ndarray, S_var: np.ndarray):
    gp_Q = HeteroscedasticGP().fit(X, Q_mean, Q_var)
    gp_S = HeteroscedasticGP().fit(X, S_mean, S_var)
    return gp_Q, gp_S


# ---------------------------------------------------------------------------
# 5. Pareto frontier
# ---------------------------------------------------------------------------

def pareto_mask(Y: np.ndarray) -> np.ndarray:
    """Non-dominated mask for an (N, M) array; higher is better in all M dims.

    O(N^2) - fine for thousands of points.  Replace with a sweep-based
    algorithm if N grows past ~10^5.
    """
    Y = np.asarray(Y, dtype=float)
    N = len(Y)
    keep = np.ones(N, dtype=bool)
    for i in range(N):
        if not keep[i]:
            continue
        ge = np.all(Y >= Y[i], axis=1)
        gt = np.any(Y >  Y[i], axis=1)
        dominators = ge & gt
        dominators[i] = False
        if np.any(dominators):
            keep[i] = False
    return keep


def constrained_quality_frontier(Q: np.ndarray, S: np.ndarray,
                                 S_thresh: float) -> np.ndarray:
    """Indices of feasible points (S >= S_thresh) sorted by descending Q."""
    Q = np.asarray(Q); S = np.asarray(S)
    feas = np.where(S >= S_thresh)[0]
    if len(feas) == 0:
        return feas
    return feas[np.argsort(-Q[feas])]


# ---------------------------------------------------------------------------
# 6. Acquisition: constrained expected improvement
# ---------------------------------------------------------------------------

def expected_improvement(mu: np.ndarray, sigma: np.ndarray,
                         y_best: float, xi: float = 0.01) -> np.ndarray:
    sigma = np.maximum(sigma, 1e-9)
    z = (mu - y_best - xi) / sigma
    return (mu - y_best - xi) * norm.cdf(z) + sigma * norm.pdf(z)


def prob_feasible(mu_S: np.ndarray, sigma_S: np.ndarray,
                  S_thresh: float) -> np.ndarray:
    sigma = np.maximum(sigma_S, 1e-9)
    return 1.0 - norm.cdf((S_thresh - mu_S) / sigma)


def constrained_ei(gp_Q: HeteroscedasticGP, gp_S: HeteroscedasticGP,
                   X_cand: np.ndarray, Q_best_feas: float,
                   S_thresh: float) -> np.ndarray:
    mu_Q, sd_Q = gp_Q.predict(X_cand, return_std=True)
    mu_S, sd_S = gp_S.predict(X_cand, return_std=True)
    ei = expected_improvement(mu_Q, sd_Q, Q_best_feas)
    pf = prob_feasible(mu_S, sd_S, S_thresh)
    return ei * pf


def propose_next(gp_Q: HeteroscedasticGP, gp_S: HeteroscedasticGP,
                 space: DesignSpace, K_cand: int = 20000,
                 S_thresh: float = 0.95, Q_best_feas: float = 0.0,
                 seed: int = 1) -> dict:
    """Pick the candidate maximising constrained EI from a large Sobol set."""
    X_cand = sample_design(space, K_cand, seed=seed)
    acq = constrained_ei(gp_Q, gp_S, X_cand, Q_best_feas, S_thresh)
    j = int(np.argmax(acq))
    mu_Q, sd_Q = gp_Q.predict(X_cand[j:j + 1], return_std=True)
    mu_S, sd_S = gp_S.predict(X_cand[j:j + 1], return_std=True)
    return {
        "x": X_cand[j],
        "acquisition": float(acq[j]),
        "pred_Q": (float(mu_Q[0]), float(sd_Q[0])),
        "pred_S": (float(mu_S[0]), float(sd_S[0])),
    }


# ---------------------------------------------------------------------------
# 7. Training-set construction and hold-out validation
# ---------------------------------------------------------------------------

def build_training_set(scanner, h_truth_ensemble: list,
                       design_points: np.ndarray, fd_cache: dict,
                       verbose: bool = True, **sim_kwargs):
    """Run `simulate_at_point` over every row of `design_points`."""
    Q_mean: list = []
    Q_var:  list = []
    S_mean: list = []
    S_var:  list = []
    n = len(design_points)
    for i, x in enumerate(design_points):
        r = simulate_at_point(scanner, h_truth_ensemble, x, fd_cache, **sim_kwargs)
        Q_mean.append(r["Q_mean"]); Q_var.append(r["Q_var"])
        S_mean.append(r["S_mean"]); S_var.append(r["S_var"])
        if verbose and (i + 1) % 25 == 0:
            print(f"  simulated {i+1}/{n} design points")
    return (np.asarray(Q_mean), np.asarray(Q_var),
            np.asarray(S_mean), np.asarray(S_var))


def validate_holdout(X_train, Q_train, S_train, Q_var_train, S_var_train,
                     X_test, Q_test, S_test) -> dict:
    """Fit on (X_train,...) and report RMSE and 1-sigma coverage on the test."""
    gp_Q = HeteroscedasticGP().fit(X_train, Q_train, Q_var_train)
    gp_S = HeteroscedasticGP().fit(X_train, S_train, S_var_train)
    muQ, sdQ = gp_Q.predict(X_test, return_std=True)
    muS, sdS = gp_S.predict(X_test, return_std=True)
    def cov(y, mu, sd):
        return float(np.mean(np.abs(np.asarray(y) - mu) <= sd))
    return {
        "Q_rmse":  float(np.sqrt(np.mean((muQ - Q_test) ** 2))),
        "S_rmse":  float(np.sqrt(np.mean((muS - S_test) ** 2))),
        "Q_cov1s": cov(Q_test, muQ, sdQ),
        "S_cov1s": cov(S_test, muS, sdS),
        "muQ": muQ, "sdQ": sdQ, "muS": muS, "sdS": sdS,
    }


# ---------------------------------------------------------------------------
# 8. Self-contained demo with a stub scanner (so the file runs as-is).
#    In real use, replace _StubScanner / _stub_synth with your modules.
# ---------------------------------------------------------------------------

class _StubScanner:
    """Toy scanner that mimics the API closely enough to exercise the pipeline.

    The model is intentionally crude - it is NOT a physically meaningful AFM
    simulator; it just produces traces with sensible Q/S behaviour as P, I,
    setpoint, drive, and speed vary.
    """

    def prepare_fd_table_for_drive(self, drive_nm: float, n_d: int = 4096):
        d = np.linspace(0.0, 3.0, n_d)
        A = drive_nm * (1.0 - np.exp(-2.0 * d))
        return {"d": d, "A": A, "drive_nm": drive_nm}

    def simulate_trace_retrace_substeps_fast(self, h_truth, drive_nm, setpoint,
                                             P, I, scan_speed_hat, dx_hat,
                                             n_substeps, fd_table,
                                             h_smooth_sigma_px, d_init_hat,
                                             A_meas_init_hat):
        rng = np.random.default_rng(int(abs(hash((float(P), float(I),
                                                  float(setpoint),
                                                  float(scan_speed_hat),
                                                  float(drive_nm))) % (2**31))))
        n = len(h_truth)
        # response speed grows with sqrt(P*I), degrades at high scan speed
        loop_speed = np.sqrt(P * I) / max(scan_speed_hat, 1e-3)
        alpha = np.clip(0.05 + 0.4 * np.tanh(loop_speed / 20.0), 0.01, 0.95)

        # forward (trace)
        z = float(h_truth[0])
        h_T = np.zeros(n)
        for k in range(n):
            z = z + alpha * (h_truth[k] - z) + 0.005 * rng.standard_normal()
            h_T[k] = z
        # backward (retrace) with a small hysteretic lag
        z = float(h_truth[-1])
        h_R = np.zeros(n)
        for k in range(n - 1, -1, -1):
            z = z + alpha * (h_truth[k] - z) + 0.005 * rng.standard_normal()
            h_R[k] = z
        # tiny bias on retrace inversely proportional to loop_speed
        h_R = h_R + 0.02 / max(loop_speed, 0.5) * np.sin(
            np.linspace(0.0, np.pi, n))

        # amplitude: drops when controller lags (large |h_truth - z|)
        err_T = h_truth - h_T
        err_R = h_truth - h_R
        A_target = setpoint * drive_nm
        A_T = np.clip(A_target * (1.0 - 1.5 * np.abs(err_T) / max(drive_nm, 1.0)),
                      0.0, drive_nm)
        A_R = np.clip(A_target * (1.0 - 1.5 * np.abs(err_R) / max(drive_nm, 1.0)),
                      0.0, drive_nm)
        return {"trace":   {"h": h_T, "A": A_T},
                "retrace": {"h": h_R, "A": A_R}}


def _stub_synth(h_map, n_pixels, dx_hat, scan_speed_hat, mode, direction,
                corr_sigma_px, random_state):
    rng = np.random.default_rng(random_state)
    base = rng.standard_normal(n_pixels)
    # crude correlated profile: cumulative sum, recentre, rescale
    h = np.cumsum(base) / np.sqrt(n_pixels)
    h -= np.mean(h)
    h *= float(np.std(h_map)) / (float(np.std(h)) + 1e-12)
    return {"generated": {"h_hat": h}}


def _demo():
    print("=" * 70)
    print("Stage-2 GP-surrogate + Pareto demo (stub scanner)")
    print("=" * 70)
    rng = np.random.default_rng(0)
    h_map = rng.standard_normal((128, 128)) * 0.5

    scanner = _StubScanner()
    space = DesignSpace()

    fd_cache = make_fd_cache(scanner, np.linspace(*space.drive_nm, 11))

    K = 6
    h_truth_ensemble = generate_truth_ensemble(_stub_synth, h_map, K=K,
                                               n_pixels=256)

    n_design = 64
    X = sample_design(space, n_design, seed=2)
    print(f"\n[1] Simulating {n_design} design points x K={K} replicates ...")
    Qm, Qv, Sm, Sv = build_training_set(scanner, h_truth_ensemble, X, fd_cache,
                                        A_crash=0.5)
    print(f"    Q range : [{Qm.min():+.3f}, {Qm.max():+.3f}]")
    print(f"    S range : [{Sm.min():.2f}, {Sm.max():.2f}]")

    print("\n[2] Fitting heteroscedastic GPs ...")
    gp_Q, gp_S = fit_surrogates(X, Qm, Qv, Sm, Sv)

    S_thresh = 0.80
    feas_order = constrained_quality_frontier(Qm, Sm, S_thresh)
    print(f"\n[3] Feasible training points (S >= {S_thresh}): "
          f"{len(feas_order)}/{n_design}")
    if len(feas_order):
        best = feas_order[0]
        print(f"    best feasible Q = {Qm[best]:+.3f} at "
              f"{dict(zip(space.names, X[best].round(3)))}")
        Q_best_feas = float(Qm[best])
    else:
        Q_best_feas = float(Qm.max())

    print("\n[4] Surrogate-predicted top operating points (constraint S>=Sth):")
    X_cand = sample_design(space, 5000, seed=99)
    muQ_c, sdQ_c = gp_Q.predict(X_cand, return_std=True)
    muS_c, sdS_c = gp_S.predict(X_cand, return_std=True)
    feas_c = muS_c >= S_thresh
    if feas_c.any():
        idxs = np.where(feas_c)[0]
        topk = idxs[np.argsort(-muQ_c[idxs])[:5]]
        for i, idx in enumerate(topk):
            settings = dict(zip(space.names, X_cand[idx].round(3)))
            print(f"    #{i+1}  Q={muQ_c[idx]:+.3f}+/-{sdQ_c[idx]:.3f}  "
                  f"S={muS_c[idx]:.2f}+/-{sdS_c[idx]:.2f}  {settings}")
    else:
        print("    (no candidate predicted feasible; loosen S_thresh)")

    print("\n[5] Surrogate Pareto in (Q, S):")
    Y = np.column_stack([muQ_c, muS_c])
    pmask = pareto_mask(Y)
    print(f"    {int(pmask.sum())} non-dominated candidates out of "
          f"{len(X_cand)}")

    print("\n[6] Next-experiment proposal (constrained EI):")
    proposal = propose_next(gp_Q, gp_S, space, K_cand=20000,
                            S_thresh=S_thresh, Q_best_feas=Q_best_feas, seed=7)
    print(f"    acq    = {proposal['acquisition']:.3e}")
    print(f"    pred Q = {proposal['pred_Q'][0]:+.3f} "
          f"+/- {proposal['pred_Q'][1]:.3f}")
    print(f"    pred S = {proposal['pred_S'][0]:.2f} "
          f"+/- {proposal['pred_S'][1]:.2f}")
    print(f"    x      = {dict(zip(space.names, proposal['x'].round(3)))}")

    print("\n[7] Hold-out validation (train on 48, test on 16) ...")
    cut = 48
    rep = validate_holdout(X[:cut], Qm[:cut], Sm[:cut], Qv[:cut], Sv[:cut],
                           X[cut:], Qm[cut:], Sm[cut:])
    print(f"    Q RMSE = {rep['Q_rmse']:.3f},   "
          f"1-sigma coverage = {rep['Q_cov1s']:.0%}")
    print(f"    S RMSE = {rep['S_rmse']:.3f},   "
          f"1-sigma coverage = {rep['S_cov1s']:.0%}")

    print("\nDone.")


if __name__ == "__main__":
    _demo()
