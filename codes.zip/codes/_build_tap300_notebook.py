"""Create the descriptor-aligned framework notebook for the Tap300 probe.

The Tap300 dataset differs from the cali_fd (Multi75) dataset in three ways:

1. Cantilever: k = 25 N/m, f0 = 270 kHz, Q_air = 200 (Multi75 was k = 3 N/m,
   f0 = 75 kHz, Q_air = 200).
2. FD library: output/Tap300_AlScN.npz with 30 approach curves over a wider
   drive range, persisted fit in output/fd_calibration_Tap300_v2_results.joblib.
   The repulsive-mode transition occurs at smaller distances than on Multi75
   because the stiffer cantilever has shorter contact-approach length.
3. Scanning archive: output/dt_controller_fit_figures/figure_45_expscan_data_bundle.npz
   from the AlScN expscan dataset (900 conditions, 225 held-out).  The bundle's
   control keys are `drive`, `setpoint`, `igain` (not `drive_exp`, etc.) so the
   new notebook aliases them at load time.

This script reads the existing Multi75 notebook, replaces the dataset-specific
cells in place, and writes the new notebook to the project root.
"""
import json
from pathlib import Path

ROOT     = Path(__file__).resolve().parents[1]
NB_IN    = ROOT / 'Descriptor-aligned DT-SPM framework.ipynb'
NB_OUT   = ROOT / 'Descriptor-aligned DT-SPM framework — Tap300.ipynb'


def _md(text):
    return {'cell_type': 'markdown', 'metadata': {},
            'source': [l + '\n' for l in text.splitlines()]}
def _code(text):
    return {'cell_type': 'code', 'metadata': {}, 'execution_count': None,
            'outputs': [], 'source': [l + '\n' for l in text.splitlines()]}


# -------------------------------------------------------------------------
CELL_2 = '''from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import Optional, Dict, List
import sys, json, math
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt

PROJECT_ROOT = Path(
    '/Users/richardmbp14/Library/CloudStorage/GoogleDrive-yu93liu@gmail.com/'
    'My Drive/Shared/Coding/Digital Twins - SPM'
)
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

FIG_DIR = PROJECT_ROOT / 'output' / 'descriptor_framework_Tap300'
FIG_DIR.mkdir(parents=True, exist_ok=True)

PALETTE = {
    'exp':       '#1f2933', 'PI':         '#2A6FBB',
    'hybrid':    '#7C3AED', 'data-driven':'#D97706',
    'slow':      '#D97706', 'optimal':    '#1B9E8A',
    'unstable':  '#C2410C', 'unknown':    '#9CA3AF',
}
mpl.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'DejaVu Sans'],
    'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False,
    'savefig.dpi': 200, 'savefig.bbox': 'tight',
})

# Tap300 dataset paths (this is the new file)
FD_PATH     = PROJECT_ROOT / 'output' / 'Tap300_AlScN.npz'
BUNDLE_PATH = (PROJECT_ROOT / 'output' / 'dt_controller_fit_figures'
                / 'figure_45_expscan_data_bundle.npz')
assert FD_PATH.exists(),     f'Missing FD library at {FD_PATH}'
assert BUNDLE_PATH.exists(), f'Missing bundle at {BUNDLE_PATH}'
print('FD library :', FD_PATH.name)
print('Bundle     :', BUNDLE_PATH.name)
'''


# Cell 4 (UserInputs) — Tap300 defaults
CELL_4 = '''@dataclass
class UserInputs:
    """Inputs the user supplies (separately measured); the framework treats these as constants.

    PATCH (Tap300 notebook): defaults aligned with the Tap300 cantilever used
    to acquire the AlScN FD library and expscan archive: k = 25 N/m,
    f0 = 270 kHz, Q_air = 200.  Verified against the persisted fit in
    output/fd_calibration_Tap300_v2_results.joblib (K_N_PER_M = 25.0,
    F0_HZ = 270000, Q_TARGET = 200).  The Tap300 is the stiffer cantilever
    used for AlScN piezoelectric characterisation; the repulsive-mode
    transition (phi crosses 90°) occurs at smaller distances than on Multi75.
    """
    # Cantilever / probe
    k_NperM:        float = 25.0    # Tap300 nominal stiffness, Sader / thermal
    f0_Hz:          float = 270_000 # Tap300 free-air resonance (thermal spectrum)
    Q_air:          float = 200.0   # Tap300 free-air Q factor
    tip_radius_nm:  float = 7.0     # nominal tip radius (vendor)
    tip_half_angle_deg: float = 18.0
    # Detector / piezo calibration
    InvOLS_nm_per_V: float = 50.0   # optical-lever inverse sensitivity
    drive_V_to_nm:   float = 1.0    # piezo drive calibration
    # Sample priors (optional)
    sample_E_GPa:   Optional[float] = None
    # Provenance
    cantilever_id:  str = 'Tap300'
    sample_id:      str = 'AlScN'

    def __post_init__(self):
        assert 0.1 <= self.k_NperM <= 1000.0
        assert 1e4 <= self.f0_Hz <= 5e6
        assert 5.0  <= self.Q_air <= 5_000.0
        assert 0.5  <= self.tip_radius_nm <= 200.0
        assert 0.1  <= self.InvOLS_nm_per_V <= 500.0

USER = UserInputs()
print(json.dumps(asdict(USER), indent=2))
'''


# Cell 9 (load FD library) — Tap300 reads npz keys, 30 curves not 15
CELL_9 = '''fd = np.load(FD_PATH)
fd_drive_raw = fd['drive']     # length 31 — includes one extra boundary
# Tap300_AlScN.npz layout: amp/height/phase are approach (30 curves x 1000 px);
# amp2/height2/phase2 are retract.  We use approach only here.
fd_amp    = fd['amp']           # (30, 1000)
fd_height = fd['height']
fd_phase  = fd['phase']
fd_drive_nm = np.array([np.nanmean(fd_amp[i, -10:]) for i in range(fd_amp.shape[0])], float)
print(f'FD library: {fd_amp.shape[0]} curves, drives span '
       f'[{fd_drive_nm.min():.1f}, {fd_drive_nm.max():.1f}] nm')

def _crossing_descriptors_at(d, A, phi, target_A):
    """Return (d_c, slope_c, phi_c) at the first d where A crosses target_A."""
    cidx = np.where(np.diff(np.sign(A - target_A)) != 0)[0]
    if cidx.size == 0:
        return float('nan'), float('nan'), float('nan')
    k = cidx[0]
    denom = (A[k+1] - A[k]) + 1e-12
    d_c = float(d[k] + (target_A - A[k]) / denom * (d[k+1] - d[k]))
    if k + 4 < d.size:
        slope_c = float(- (A[k+4] - A[k]) / (d[k+4] - d[k] + 1e-12))
    else:
        slope_c = float(- (A[k+1] - A[k]) / (d[k+1] - d[k] + 1e-12))
    phi_c = float(np.interp(d_c, d, phi))
    return d_c, slope_c, phi_c


def extract_stage1(d, A, phi, *, contact_frac=0.2,
                     soft_levels=(0.5, 0.7)) -> Stage1Descriptors:
    """Read the contact-regime + far-field descriptors from one FD curve."""
    d = np.asarray(d, float).ravel(); A = np.asarray(A, float).ravel()
    phi = np.asarray(phi, float).ravel()
    order = np.argsort(d); d, A, phi = d[order], A[order], phi[order]
    valid = np.isfinite(d) & np.isfinite(A) & np.isfinite(phi)
    if valid.sum() < 8: return Stage1Descriptors()
    d, A, phi = d[valid], A[valid], phi[valid]
    A0 = float(np.nanmedian(A[-max(5, int(0.1 * A.size)):]))

    # Contact-regime descriptors (Tap300 sweeps reach into contact at most drives)
    cross = np.where(np.diff(np.sign(phi - 90.0)) != 0)[0]
    if cross.size > 0:
        k = cross[-1]
        d_AR = float(d[k] + (90 - phi[k]) / (phi[k+1] - phi[k] + 1e-12) * (d[k+1] - d[k]))
        A_AR = float(np.interp(d_AR, d, A))
    else:
        d_AR = A_AR = float('nan')
    d_c, sc, phi_c = _crossing_descriptors_at(d, A, phi, contact_frac * A0)
    dphi = (float(phi_c - np.nanmedian(phi[-5:])) if np.isfinite(phi_c) else float('nan'))
    soft = (A > 0.3 * A0) & (A < 0.7 * A0)
    branch = (1.0 if soft.sum() >= 4 and np.polyfit(A[soft], phi[soft], 1)[0] > 0
                else -1.0 if soft.sum() >= 4 else float('nan'))

    d_50, slope_50, phi_50 = _crossing_descriptors_at(d, A, phi, soft_levels[0] * A0)
    d_70, slope_70, phi_70 = _crossing_descriptors_at(d, A, phi, soft_levels[1] * A0)

    return Stage1Descriptors(
        A0=A0,
        d_AR=d_AR, A_AR=A_AR,
        d_contact=d_c, slope_contact=sc,
        dphi_total=dphi, branch=branch,
        d_50=d_50, slope_50=slope_50, phi_50=phi_50,
        d_70=d_70, slope_70=slope_70, phi_70=phi_70,
    )

fd_desc_exp = [extract_stage1(fd_height[i], fd_amp[i], fd_phase[i])
                for i in range(fd_amp.shape[0])]
fd_desc_df_exp = pd.DataFrame([asdict(d) for d in fd_desc_exp])
fd_desc_df_exp['drive_nm'] = fd_drive_nm
print()
print('Per-descriptor finite count across the {} FD curves:'.format(fd_amp.shape[0]))
print((fd_desc_df_exp.notna()).sum().to_dict())
print()
print('Median A→R transition distance on Tap300:',
       float(np.nanmedian(fd_desc_df_exp['d_AR'])), 'nm')
print('(Compare: cali_fd / Multi75 had A→R typically NaN because curves stopped before contact.)')
fd_desc_df_exp.round(2)
'''


# Cell 10 (load FD fit + analytic_FD_real) — Tap300 joblib path
CELL_10 = '''# Stage-1 analytic prior: real RK45 driven-cantilever solver, driven by the
# persisted Tap300 fit in `output/fd_calibration_Tap300_v2_results.joblib`.
# The PINN learns only a sparse correction overlay; the analytic backbone is
# evaluated outside the autograd graph.

from joblib import load as _jload
from codes.spm_fd_rk45_extended_calibration import (
    simulate_curve_rk45_extended_python,
    transform_phase_deg,
    estimate_phase_offset_far_field,
)

_FD_FIT_PATH = PROJECT_ROOT / 'output' / 'fd_calibration_Tap300_v2_results.joblib'

def load_FD_fit_results(path=_FD_FIT_PATH):
    """Load the persisted FD calibration fit (output of FD_calibration_Tap300_v2)."""
    d = _jload(str(path))
    return dict(
        p_glob       = d.get('p_glob_D') or d.get('p_glob_C') or d.get('p_glob'),
        conv_L       = float(d['conv_L']),
        curves_train = d['curves_train'],
        sel_train    = d['sel_train'],
        curves_app_sub = d['curves_app_sub'],
        rk45_plot    = d['rk45_plot_options'],
        phase_mode   = d.get('PHASE_MODE', 'raw'),
    )

FD_FIT = load_FD_fit_results()
print('Tap300 FD calibration fit loaded:')
print(f'  conv_L          = {FD_FIT["conv_L"]:.5g}')
print(f'  shared params   : C1={FD_FIT["p_glob"]["C1"]:.3g}, C2={FD_FIT["p_glob"]["C2"]:.3g}, a0={FD_FIT["p_glob"]["a0"]:.3g}, Q={FD_FIT["p_glob"]["Q"]:.1f}')
print(f'  fitted on       : {len(FD_FIT["sel_train"])} training curves')

_OMEGA_BASE = 1.0 + float(FD_FIT['p_glob']['domega'])


def _nearest_train_curve_idx(V_nm: float) -> int:
    train_drives = np.array(
        [FD_FIT['curves_app_sub'][k]['drive_nm'] for k in FD_FIT['sel_train']],
        float)
    return int(np.argmin(np.abs(train_drives - V_nm)))


def analytic_FD_real(d_grid_nm, V_nm, *, user: UserInputs,
                       params: 'Stage1FittingParameters' = None):
    """Real Tier-A analytic prior for Tap300 — RK45 simulator driven by the
    Tap300 fit parameters.  Same calling convention as the Multi75 notebook."""
    pg = FD_FIT['p_glob']; conv_L = FD_FIT['conv_L']
    d_hat = np.asarray(d_grid_nm, float).ravel() * conv_L
    k = _nearest_train_curve_idx(float(V_nm))
    A_sim_hat, phi_sim_deg, *_ = simulate_curve_rk45_extended_python(
        d_hat,
        C1=pg['C1'], C2=pg['C2'], a0=pg['a0'], Q=pg['Q'],
        C3=pg['C3'][k],
        omega_drive_hat=_OMEGA_BASE, omega_ref_hat=_OMEGA_BASE,
        d_offset_hat=pg['d_off'][k],
        w_contact=pg['w_contact'], gamma_lr=pg['gamma_lr'],
        lambda_lr=pg['lambda_lr'], gamma_contact=pg['gamma_contact'],
        **FD_FIT['rk45_plot'],
    )
    phi_use = transform_phase_deg(phi_sim_deg, mode=FD_FIT['phase_mode'])
    curve = FD_FIT['curves_app_sub'][FD_FIT['sel_train'][k]]
    phi_auto = estimate_phase_offset_far_field(
        phi_use, curve['phi_deg'], curve['d_hat'], frac=0.15, period_deg=360.0)
    phi_use = phi_use + phi_auto + pg['p_off'][k]
    A_nm = A_sim_hat / conv_L
    return A_nm, phi_use


def analytic_FD_TierA(d_grid, V, *, user: UserInputs,
                       params: 'Stage1FittingParameters'):
    return analytic_FD_real(d_grid, V, user=user, params=params)


pg = FD_FIT['p_glob']
init_params = Stage1FittingParameters(
    omega0_offset=float(pg['domega']),
    Q_contact=float(pg['Q']),
    C1=float(pg['C1']), C2=float(pg['C2']),
    C3_global=float(np.nanmean(pg['C3'])),
    Estar_GPa=50.0,
    d0_nm=float(np.nanmedian(
        [d.d_contact for d in fd_desc_exp if np.isfinite(d.d_contact)]) or 10.0),
)
print()
print('Initial Stage-1 fitting parameters (from persisted Tap300 fit):')
print(init_params)

fd_desc_sim_init = []
for i, V in enumerate(fd_drive_nm):
    A_sim, phi_sim = analytic_FD_real(fd_height[i], V, user=USER)
    fd_desc_sim_init.append(extract_stage1(fd_height[i], A_sim, phi_sim))
fd_desc_df_sim = pd.DataFrame([asdict(d) for d in fd_desc_sim_init])
fd_desc_df_sim['drive_nm'] = fd_drive_nm
print('\\nReal-analytic-prior sim descriptors:')
fd_desc_df_sim.round(2)
'''


# Cell 15 (load expscan bundle) — alias key names
CELL_15 = '''b = np.load(BUNDLE_PATH, allow_pickle=False)

# PATCH (Tap300 notebook): the expscan bundle uses control keys `drive`,
# `setpoint`, `igain` (the cali_fd bundle had `drive_exp`, etc.).  Alias them
# here so the rest of the notebook reads the same variable names as the
# Multi75 version.
drive_exp    = b['drive']
setpoint_exp = b['setpoint']
igain_exp    = b['igain']
fit_idx      = b['fit_idx']
test_idx     = b['test_idx']
traces_exp   = b['traces_exp']
dt_PI        = b['dt_PI']
dd           = b['dd']
hyb          = b['hyb']
print(f'Loaded Tap300 expscan bundle: {traces_exp.shape[0]} conditions, '
       f'{fit_idx.size} fit / {test_idx.size} held-out')
print(f'  drive   span: [{drive_exp.min():.1f}, {drive_exp.max():.1f}] nm')
print(f'  setpoint    : [{setpoint_exp.min():.2f}, {setpoint_exp.max():.2f}]')
print(f'  I-gain      : [{igain_exp.min():.0f}, {igain_exp.max():.0f}]')

# Operating-point computation reuses the calibrated Stage-1 surface.
from scipy.interpolate import interp1d
fd_drive_sorted = np.argsort(fd_drive_nm)
interp_A0 = interp1d(fd_drive_nm[fd_drive_sorted],
                      np.array([d.A0 for d in fd_desc_exp])[fd_drive_sorted],
                      kind='linear', fill_value='extrapolate')
interp_dAR = interp1d(fd_drive_nm[fd_drive_sorted],
                       np.array([d.d_AR for d in fd_desc_exp])[fd_drive_sorted],
                       kind='linear', fill_value='extrapolate')

def operating_point(V, sp) -> Stage2Descriptors:
    A0 = float(interp_A0(V)); A_op = float(sp * A0)
    idx = int(np.argmin(np.abs(fd_drive_nm - V)))
    d, A, phi = fd_height[idx], fd_amp[idx], fd_phase[idx]
    order = np.argsort(d); d, A, phi = d[order], A[order], phi[order]
    try:
        d_op = float(np.interp(A_op, A[::-1], d[::-1]))
        phi_op = float(np.interp(d_op, d, phi))
        slope = float(np.gradient(A, d)[np.argmin(np.abs(d - d_op))])
    except Exception:
        d_op = phi_op = slope = float('nan')
    return Stage2Descriptors(d_op=d_op, A_op=A_op, phi_op=phi_op,
                              loop_gain=float(slope * 1.0),
                              PI_margin=float('nan'))

op_records = []
for i in range(traces_exp.shape[0]):
    op = operating_point(float(drive_exp[i]), float(setpoint_exp[i]))
    op_records.append(dict(cond=i, drive=float(drive_exp[i]),
                            setpoint=float(setpoint_exp[i]),
                            igain=float(igain_exp[i]),
                            **asdict(op)))
op_df = pd.DataFrame(op_records)
op_df.head(10)
'''


def main():
    nb = json.load(open(NB_IN))

    # Update the title (cell 0 markdown)
    cell0 = ''.join(nb['cells'][0]['source'])
    cell0 = cell0.replace(
        '# Descriptor-aligned DT-SPM framework',
        '# Descriptor-aligned DT-SPM framework — Tap300 probe'
    ).replace(
        'persisted bundles produced by the existing calibration-grating and AlScN notebooks',
        'persisted bundles produced by the AlScN expscan v2 notebook + the Tap300 FD calibration'
    )
    nb['cells'][0]['source'] = cell0.splitlines(keepends=True)

    # Swap the dataset-specific cells.  Cell indices match the Multi75 layout
    # confirmed above.
    def _set(idx, source_text):
        nb['cells'][idx]['source']        = source_text.splitlines(keepends=True)
        nb['cells'][idx]['outputs']       = []
        nb['cells'][idx]['execution_count'] = None

    _set(2,  CELL_2)
    _set(4,  CELL_4)
    _set(9,  CELL_9)
    _set(10, CELL_10)
    _set(15, CELL_15)

    json.dump(nb, open(NB_OUT, 'w'), indent=1)
    print('Wrote', NB_OUT)
    # Sanity report
    nb_check = json.load(open(NB_OUT))
    print('Cells in new notebook:', len(nb_check['cells']))
    for idx in (2, 4, 9, 10, 15):
        src = ''.join(nb_check['cells'][idx]['source'])
        keys = []
        if 'Tap300' in src: keys.append('Tap300')
        if 'descriptor_framework_Tap300' in src: keys.append('FIG_DIR')
        if 'fd_calibration_Tap300_v2_results' in src: keys.append('Tap300 joblib')
        if "b['drive']" in src: keys.append('aliased keys')
        print(f'  cell {idx:2d}: {keys}')


if __name__ == '__main__':
    main()
