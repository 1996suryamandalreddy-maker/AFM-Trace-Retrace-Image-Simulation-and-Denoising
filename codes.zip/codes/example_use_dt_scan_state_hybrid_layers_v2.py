
"""
example_use_dt_scan_state_hybrid_layers_v2.py

Example calls for dt_scan_state_hybrid_layers_v2.py.

Assumes you already have:
    scanner
    scanner_cfg
    traces_exp            # height, shape (5, 11, 8, 5, 2, 256)
    traces_amp_exp        # amplitude, same shape
    traces_phase_exp      # phase, same shape
    synthetic_lines       # list/array of h_line_dt
    scan_rate
    drive_exp
    setpoint_exp
    igain_exp
    P_grid, I_grid        # GP-predicted simulator gains, shape (5,11,8,5)
"""

import numpy as np

from codes.dt_scan_state_hybrid_layers_v2 import (
    FDTableCache,
    ResidualDatasetConfig,
    StaticScanStateConfig,
    DynamicScanStateConfig,
    PureDataConfig,
    build_residual_dataset,
    split_condition_keys,
    fit_static_scan_state_layer,
    add_static_and_dynamic_targets,
    fit_dynamic_scan_state_layer,
    fit_pure_data_layer,
    evaluate_scan_state_models,
    residual_summary,
    predict_corrected_channels_for_out,
)

# ---------------------------------------------------------------------
# 0. Optional: clip GP-predicted P/I to the range used during local fitting.
# ---------------------------------------------------------------------

# Use your actual gp_cfg.bounds_logPI if available.
# P_grid = np.clip(P_grid, 1e-4, 1e2)
# I_grid = np.clip(I_grid, 1e-5, 1e3)


# ---------------------------------------------------------------------
# 1. Build per-pixel scan-state residual dataset.
# ---------------------------------------------------------------------

fd_cache = FDTableCache(
    scanner=scanner,
    n_d=scanner_cfg.fd_n_d,
)

resid_cfg = ResidualDatasetConfig(
    # Use "pixel" only if h_line_dt is the actual/reconstructed measured line.
    # For synthetic lines with matched roughness distribution, use quantile pairing.
    pairing="quantile_by_A",

    max_points_per_direction=128,
    n_synthetic_lines_per_condition=1,
    random_state=0,

    # Use 180.0 if your phase is 180-periodic.
    phase_period_deg=360.0,

    stable_only=True,
    min_A_frac_of_A95=0.03,

    include_retrace=True,
    trim_edges=5,
)

df_base = build_residual_dataset(
    scanner,
    traces_exp_height=traces_exp,
    traces_exp_amp=traces_amp_exp,
    traces_exp_phase=traces_phase_exp,
    synthetic_lines=synthetic_lines,

    scan_speeds_hat=scan_rate,
    drives_nm=drive_exp,
    setpoints=setpoint_exp,
    i_gains_exp=igain_exp,

    scanner_cfg=scanner_cfg,

    # From static GP controller calibration:
    P_grid=P_grid,
    I_grid=I_grid,

    fd_cache=fd_cache,
    cfg=resid_cfg,
)

print("df_base:", df_base.shape)
print(residual_summary(df_base))


# ---------------------------------------------------------------------
# 2. Split by condition, not by pixel.
# ---------------------------------------------------------------------

train_keys, test_keys = split_condition_keys(
    df_base,
    test_frac=0.2,
    seed=0,
)

df_train_base = df_base[df_base["cond_key"].isin(train_keys)].copy()
df_test_base = df_base[df_base["cond_key"].isin(test_keys)].copy()

print("train rows:", len(df_train_base))
print("test rows:", len(df_test_base))


# ---------------------------------------------------------------------
# 3. Fit static scan-state residual.
#
# This is the model that captures the setpoint-dependent amplitude-phase clouds:
#
#   delta_A0, delta_phi0 = f(drive, setpoint, d_DT, A_FD, phi_FD)
# ---------------------------------------------------------------------

static_cfg = StaticScanStateConfig(
    feature_cols=("drive_nm", "setpoint", "d_dt", "A_fd", "phi_fd"),
    target_cols=("delta_A_raw", "delta_phi_raw"),

    model_type="histgb",
    max_iter=300,
    learning_rate=0.05,
    max_leaf_nodes=31,
    min_samples_leaf=20,

    max_train_points=50000,
    random_state=0,
)

static_layer, static_info = fit_static_scan_state_layer(
    df_train_base,
    cfg=static_cfg,
)

print("static_info:", static_info)


# ---------------------------------------------------------------------
# 4. Create dynamic residual targets after applying the static layer.
# ---------------------------------------------------------------------

df_dyn = add_static_and_dynamic_targets(
    df_base,
    static_layer,
    fd_cache,
    phase_period_deg=360.0,
    use_target_deff_for_dynamic_targets=True,
)

print("df_dyn:", df_dyn.shape)
print(residual_summary(df_dyn))

df_train_dyn = df_dyn[df_dyn["cond_key"].isin(train_keys)].copy()
df_test_dyn = df_dyn[df_dyn["cond_key"].isin(test_keys)].copy()


# ---------------------------------------------------------------------
# 5. Fit dynamic scan-state residual.
#
# This learns:
#   delta_d_dyn, delta_A_dyn, delta_phi_dyn, delta_h_dyn
# from controls + DT state + history.
# ---------------------------------------------------------------------

dyn_cfg = DynamicScanStateConfig(
    model_type="histgb",

    max_iter=400,
    learning_rate=0.04,
    max_leaf_nodes=31,
    min_samples_leaf=30,

    max_train_points=100000,
    random_state=0,
)

dynamic_layer, dynamic_info = fit_dynamic_scan_state_layer(
    df_train_dyn,
    cfg=dyn_cfg,
)

print("dynamic_info:", dynamic_info)


# ---------------------------------------------------------------------
# 6. Fit pure data-driven baseline.
#
# This does not use FD features or DT state. It directly learns:
#   controls + direction + x_exp_norm -> A_exp, phi_exp, h_exp
# ---------------------------------------------------------------------

pure_cfg = PureDataConfig(
    feature_cols=(
        "log_scan_speed",
        "drive_nm",
        "setpoint",
        "log_I_exp",
        "direction_sign",
        "x_exp_norm",
    ),
    target_cols=("exp_A", "exp_phi", "exp_h"),

    model_type="histgb",
    max_iter=400,
    learning_rate=0.04,
    max_leaf_nodes=31,
    min_samples_leaf=30,

    max_train_points=100000,
    random_state=0,
)

pure_layer, pure_info = fit_pure_data_layer(
    df_train_base,
    cfg=pure_cfg,
)

print("pure_info:", pure_info)


# ---------------------------------------------------------------------
# 7. Benchmark held-out conditions.
# ---------------------------------------------------------------------

metrics = evaluate_scan_state_models(
    df_test_dyn,
    fd_cache=fd_cache,
    static_layer=static_layer,
    dynamic_layer=dynamic_layer,
    pure_layer=pure_layer,
    phase_period_deg=360.0,
)

print(metrics)


# ---------------------------------------------------------------------
# 8. Apply the trained hybrid layer to one new DT simulation.
# ---------------------------------------------------------------------

si, di, spi, gi = 2, 8, 5, 4

drive = float(drive_exp[di])
setpoint = float(setpoint_exp[spi])
speed = float(scan_rate[si])
I_exp = float(igain_exp[gi])

P_sim = float(P_grid[si, di, spi, gi])
I_sim = float(I_grid[si, di, spi, gi])

fd_table = fd_cache.get(drive, drive_index=di)

h_line_dt = synthetic_lines[0]

out = scanner.simulate_trace_retrace_substeps_fast(
    h_line_dt,
    drive_nm=drive,
    setpoint=setpoint,
    P=P_sim,
    I=I_sim,
    scan_speed_hat=speed,
    dx_hat=1.0,
    n_substeps=scanner_cfg.n_substeps,
    fd_table=fd_table,
    h_smooth_sigma_px=scanner_cfg.h_smooth_sigma_px,
    d_init_hat=scanner_cfg.d_init_hat,
    A_meas_init_hat=scanner_cfg.A_meas_init_hat,
)

corrected = predict_corrected_channels_for_out(
    out,
    controls={
        "scan_speed_hat": speed,
        "drive_nm": drive,
        "setpoint": setpoint,
        "I_exp": I_exp,
        "P_sim": P_sim,
        "I_sim": I_sim,
        "di": di,
    },
    fd_table=fd_table,
    static_layer=static_layer,
    dynamic_layer=dynamic_layer,
    phase_period_deg=360.0,
    static_at_deff=True,
)

A_trace_pred = corrected["trace"]["A_pred"]
phi_trace_pred = corrected["trace"]["phi_pred"]
h_trace_pred = corrected["trace"]["h_pred"]

print(A_trace_pred.shape, phi_trace_pred.shape, h_trace_pred.shape)
