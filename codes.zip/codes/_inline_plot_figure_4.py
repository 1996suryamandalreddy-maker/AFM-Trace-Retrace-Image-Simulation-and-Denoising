# 15.4  plot_figure_4 — fully self-contained Figure 4.  Edit freely.
def plot_figure_4(bundle, save_to=None, stem='figure_4_cali_PI_fit_nature'):
    """Render Figure 4 from a bundle dict.

    Layout (3x3):
      row 1: (a) synthetic h_truth + clean experimental traces
             (b) PI loss surface for the cleanest condition
             (c) fitted log10(P,I) vs ridge-predicted log10(P,I)
      row 2: (d, e, f) three I-gain regime overlays — small / optimal / large
      row 3: (g) DT-vs-exp scan-quality scatter
             (h) behavioural signatures: sim (bars) vs exp (dots), log1p scale
             (i) loss-component fractional contribution per regime
    """
    setup_style()
    traces_exp   = bundle['traces_exp']
    h_truth      = bundle['h_truth']
    fit_idx      = bundle['fit_idx']
    test_idx     = bundle['test_idx']
    dt_PI        = bundle['dt_PI']
    drive_exp    = bundle['drive_exp']
    setpoint_exp = bundle['setpoint_exp']
    igain_exp    = bundle.get('igain_exp', np.full(traces_exp.shape[0], np.nan))
    P_all = bundle['P_all']; I_all = bundle['I_all']
    clean_pick = bundle['clean_pick']
    q_exp = bundle['q_exp']; q_PI = bundle['q_PI']
    oracle = bundle['oracle_PI']
    has_demo = ('demo_cond_idx' in bundle and bundle['demo_cond_idx'].size == 3)

    fig = plt.figure(figsize=(7.2, 8.4), constrained_layout=False)
    gs = gridspec.GridSpec(3, 3, figure=fig,
                            height_ratios=[1.0, 1.05, 1.05],
                            width_ratios=[1.05, 1.0, 1.15])
    fig.subplots_adjust(left=0.08, right=0.95, bottom=0.085, top=0.88,
                        wspace=0.60, hspace=0.80)
    fig.suptitle('Calibrating the PI loop of the digital twin against experimental scan lines',
                 x=0.06, y=0.96, ha='left', fontsize=9.7, fontweight='bold')

    # (a) synthetic h_truth over clean experimental traces
    ax = fig.add_subplot(gs[0, 0]); panel_label(ax, 'a')
    for k, ci in enumerate(clean_pick[:6]):
        ax.plot(_center(traces_exp[int(ci), 0]), lw=0.7,
                color=PALETTE['grey'], alpha=0.7,
                label='clean experimental traces' if k == 0 else None)
    ax.plot(_center(h_truth), color=PALETTE['blue'], lw=1.7,
            label=r'synthetic $h_{\mathrm{truth}}$')
    ax.set_xlabel('pixel'); ax.set_ylabel('height (nm)')
    ax.set_title('Synthetic profile mirrors\nthe grating geometry')
    ax.legend(frameon=False, loc='lower center', fontsize=6.6)

    # (b) PI loss surface for the cleanest condition
    ax = fig.add_subplot(gs[0, 1]); panel_label(ax, 'b')
    Pg = bundle['loss_P_grid']; Ig = bundle['loss_I_grid']; L = bundle['loss_L']
    cond_for_surf = int(bundle['loss_cond'])
    im = ax.pcolormesh(np.log10(Pg), np.log10(Ig),
                       np.log10(np.maximum(L, 1e-12)).T,
                       shading='auto', cmap='magma')
    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.025)
    cb.set_label(r'$\log_{10}$ loss (nm$^2$)')
    if cond_for_surf in oracle:
        p_star = oracle[cond_for_surf]['log10_P']
        i_star = oracle[cond_for_surf]['log10_I']
        ax.plot(p_star, i_star, marker='*', color=PALETTE['teal'], markersize=10,
                markeredgecolor='white', markeredgewidth=0.8,
                label=f"fitted (P*,I*) = ({oracle[cond_for_surf]['P']:.2f},{oracle[cond_for_surf]['I']:.2f})")
        ax.legend(frameon=False, fontsize=6.2, loc='lower right')
    ax.set_xlabel(r'$\log_{10} P$'); ax.set_ylabel(r'$\log_{10} I$')
    ax.set_title(f'PI loss surface\n(cond {cond_for_surf})')

    # (c) fitted (P,I) vs ridge-predicted
    ax = fig.add_subplot(gs[0, 2]); panel_label(ax, 'c')
    fit_log10P = np.array([oracle[int(i)]['log10_P'] for i in fit_idx if int(i) in oracle])
    fit_log10I = np.array([oracle[int(i)]['log10_I'] for i in fit_idx if int(i) in oracle])
    pred_logP  = np.log10(np.array([P_all[int(i)] for i in fit_idx if int(i) in oracle]))
    pred_logI  = np.log10(np.array([I_all[int(i)] for i in fit_idx if int(i) in oracle]))
    ax.scatter(fit_log10P, pred_logP, s=14, color=PALETTE['blue'],
               edgecolor='white', lw=0.4, label='P')
    ax.scatter(fit_log10I, pred_logI, s=14, color=PALETTE['orange'],
               marker='D', edgecolor='white', lw=0.4, label='I')
    lo = float(min(fit_log10P.min(), fit_log10I.min(), pred_logP.min(), pred_logI.min()))
    hi = float(max(fit_log10P.max(), fit_log10I.max(), pred_logP.max(), pred_logI.max()))
    ax.plot([lo, hi], [lo, hi], color=PALETTE['muted'], lw=0.6, ls='--')
    ax.set_xlabel(r'fitted $\log_{10}$ (P or I)')
    ax.set_ylabel(r'ridge-predicted')
    ax.set_title('PI map generalizes\nacross controls')
    ax.legend(frameon=False, fontsize=6.5, loc='upper left')

    # Row 2: three I-gain regime overlays
    if has_demo:
        regimes = [('Too small I', PALETTE['orange']),
                   ('Optimal I',   PALETTE['blue']),
                   ('Too large I', PALETTE['red'])]
        demo_idx = bundle['demo_cond_idx']
        demo_tr  = bundle['demo_sim_tr']; demo_rt = bundle['demo_sim_rt']
        demo_PI  = bundle['demo_PI']
        for col, ((ttl, c), ci, P, I) in enumerate(
                zip(regimes,
                    [int(demo_idx[k]) for k in range(3)],
                    demo_PI[:, 0], demo_PI[:, 1])):
            ax = fig.add_subplot(gs[1, col]); panel_label(ax, 'def'[col])
            ax.plot(_center(traces_exp[ci, 0]), color=PALETTE['ink'], lw=1.0)
            ax.plot(_center(traces_exp[ci, 1]), color=PALETTE['ink'], lw=0.9, ls=':', alpha=0.85)
            ax.plot(_center(np.asarray(demo_tr[col])), color=c, lw=1.0)
            ax.plot(_center(np.asarray(demo_rt[col])), color=c, lw=0.9, ls=':', alpha=0.85)
            ax.set_xlabel('pixel'); ax.set_ylabel('height (nm)')
            ax.set_title(f'{ttl}\ncond {ci}: Ig$_\\mathrm{{exp}}$={float(igain_exp[ci]):.0f}, '
                         f'P*={P:.2g}, I*={I:.2g}')
    else:
        q_test = q_exp[test_idx]; order_t = np.argsort(q_test)
        cond_opt = int(test_idx[order_t[0]]); cond_sub = int(test_idx[order_t[-1]])
        for axslot, i, ttl, c, lbl in [
            (gs[1, 0], cond_opt, 'Optimal condition',     PALETTE['blue'], 'd'),
            (gs[1, 1], cond_sub, 'Sub-optimal condition', PALETTE['red'],  'e')]:
            ax = fig.add_subplot(axslot); panel_label(ax, lbl)
            ax.plot(_center(traces_exp[i, 0]), color=PALETTE['ink'], lw=1.0)
            ax.plot(_center(traces_exp[i, 1]), color=PALETTE['ink'], lw=0.9, ls=':', alpha=0.85)
            ax.plot(_center(dt_PI[i, 0]), color=c, lw=1.0)
            ax.plot(_center(dt_PI[i, 1]), color=c, lw=0.9, ls=':', alpha=0.85)
            ax.set_xlabel('pixel'); ax.set_ylabel('height (nm)')
            ax.set_title(f'{ttl}\nd={float(drive_exp[i]):.0f} nm, sp={float(setpoint_exp[i]):.2f}')

    # Row 3
    if has_demo:
        ax = fig.add_subplot(gs[2, 0]); panel_label(ax, 'g')
        ax.scatter(q_exp[fit_idx], q_PI[fit_idx], s=14, color=PALETTE['blue'],
                   edgecolor='white', lw=0.4, label='fit conditions')
        ax.scatter(q_exp[test_idx], q_PI[test_idx], s=22, color=PALETTE['orange'],
                   marker='D', edgecolor='white', lw=0.4, label='held-out')
        qmax = max(float(np.nanpercentile(np.concatenate([
            q_exp[fit_idx], q_PI[fit_idx], q_exp[test_idx], q_PI[test_idx]]), 95)), 25.0)
        ax.plot([0, qmax], [0, qmax], color=PALETTE['muted'], lw=0.6, ls='--')
        ax.set_xlim(0, qmax); ax.set_ylim(0, qmax)
        ax.set_xlabel('experimental scan quality (nm)')
        ax.set_ylabel('DT-simulated scan quality (nm)')
        ax.set_title('Scan-quality recovery')
        ax.legend(frameon=False, fontsize=6.4, loc='upper left')

        ex_bytes = bundle.get('three_examples_json', np.array(''))
        ex_text  = str(ex_bytes) if ex_bytes.size else ''
        try:
            examples = _json.loads(ex_text)
        except Exception:
            examples = []
        ax = fig.add_subplot(gs[2, 1]); panel_label(ax, 'h')
        names_h = ['small\nI', 'optimal\nI', 'large\nI']
        colors  = [PALETTE['orange'], PALETTE['blue'], PALETTE['red']]
        stats = ['trrt', 'hf_tr', 'gm_tr']
        stat_labels = ['trace-retrace\nRMSE', 'high-freq\nresidual', 'gradient\nMAD']
        x_pos = np.arange(len(stats)); w = 0.22
        if examples:
            for k, ex in enumerate(examples):
                sim = [ex['sim_sig'][s] for s in stats]
                exp = [ex['exp_sig'][s] for s in stats]
                ax.bar(x_pos + (k-1)*w*1.05, np.log1p(sim), width=w*0.95,
                       color=colors[k], alpha=0.55,
                       label=f"sim · {names_h[k].replace(chr(10), ' ')}")
                ax.scatter(x_pos + (k-1)*w*1.05, np.log1p(exp),
                           color=colors[k], edgecolor='black', s=22, zorder=3)
            ax.scatter([], [], color='white', edgecolor='black', s=22,
                       label='exp value')
        ax.set_xticks(x_pos, stat_labels, fontsize=6.2)
        ax.set_ylabel(r'$\log(1 + \mathrm{stat})$')
        ax.set_title('Behavioural signatures\nsim (bars) vs exp (dots)')
        ax.legend(frameon=False, fontsize=5.6, loc='upper left')

        ax = fig.add_subplot(gs[2, 2]); panel_label(ax, 'i')
        if examples:
            comps = np.array([
                [ex['shape_mse'], ex['trrt_term'], ex['hf_term'], ex['grad_term']]
                for ex in examples
            ])
            w_arr = np.array([1.0, 80.0, 300.0, 300.0])
            weighted = comps * w_arr
            tot = np.nansum(weighted, axis=1, keepdims=True) + 1e-12
            frac = weighted / tot
            labels = ['shape MSE', 'trace-retrace', 'HF residual', 'gradient MAD']
            bar_colors = [PALETTE['grey'], PALETTE['teal'], PALETTE['orange'], PALETTE['purple']]
            bottom = np.zeros(len(examples))
            for k in range(4):
                ax.bar(np.arange(len(examples)), frac[:, k], bottom=bottom,
                       color=bar_colors[k], label=labels[k], alpha=0.9)
                bottom += frac[:, k]
            ax.set_xticks(np.arange(len(examples)), names_h, fontsize=6.4)
            ax.set_ylim(0, 1.0)
            ax.set_ylabel('loss component\n(fraction of total)')
            ax.set_title('Where the new loss\nplaces weight')
            ax.legend(frameon=False, fontsize=5.6, loc='center left',
                      bbox_to_anchor=(1.02, 0.5))
    else:
        ax = fig.add_subplot(gs[1, 2]); panel_label(ax, 'f')
        ax.scatter(q_exp[fit_idx], q_PI[fit_idx], s=14, color=PALETTE['blue'],
                   edgecolor='white', lw=0.4, label='fit conditions')
        ax.scatter(q_exp[test_idx], q_PI[test_idx], s=22, color=PALETTE['orange'],
                   marker='D', edgecolor='white', lw=0.4, label='held-out')
        qmax = max(float(np.nanpercentile(np.concatenate([
            q_exp[fit_idx], q_PI[fit_idx], q_exp[test_idx], q_PI[test_idx]]), 95)), 25.0)
        ax.plot([0, qmax], [0, qmax], color=PALETTE['muted'], lw=0.6, ls='--')
        ax.set_xlim(0, qmax); ax.set_ylim(0, qmax)
        ax.set_xlabel('experimental scan quality (nm)')
        ax.set_ylabel('DT-simulated scan quality (nm)')
        ax.set_title('Scan-quality recovery')
        ax.legend(frameon=False, fontsize=6.4, loc='upper left')

        order = np.argsort(q_exp[test_idx])
        picks = [int(test_idx[order[0]]),
                 int(test_idx[order[len(order)//2]]),
                 int(test_idx[order[-1]])]
        titles = ['best held-out', 'median held-out', 'worst held-out']
        for col, (i, ttl) in enumerate(zip(picks, titles)):
            ax = fig.add_subplot(gs[2, col]); panel_label(ax, 'ghi'[col])
            ax.plot(_center(traces_exp[i, 0]), color=PALETTE['ink'], lw=0.9)
            ax.plot(_center(traces_exp[i, 1]), color=PALETTE['ink'], lw=0.9, ls=':', alpha=0.8)
            ax.plot(_center(dt_PI[i, 0]), color=PALETTE['blue'], lw=0.9)
            ax.plot(_center(dt_PI[i, 1]), color=PALETTE['blue'], lw=0.9, ls=':', alpha=0.8)
            ax.set_xlabel('pixel'); ax.set_ylabel('height (nm)')
            ax.set_title(f'{ttl}\nd={float(drive_exp[i]):.0f} nm, sp={float(setpoint_exp[i]):.2f}')

    if has_demo:
        leg_handles = [
            Line2D([0],[0], color=PALETTE['ink'],    lw=1.0, label='experiment (trace)'),
            Line2D([0],[0], color=PALETTE['ink'],    lw=0.9, ls=':', label='experiment (retrace)'),
            Line2D([0],[0], color=PALETTE['orange'], lw=1.0, label='DT — small I'),
            Line2D([0],[0], color=PALETTE['blue'],   lw=1.0, label='DT — optimal I'),
            Line2D([0],[0], color=PALETTE['red'],    lw=1.0, label='DT — large I'),
        ]
    else:
        leg_handles = [
            Line2D([0],[0], color=PALETTE['ink'],  lw=1.0, label='experiment (trace)'),
            Line2D([0],[0], color=PALETTE['ink'],  lw=0.9, ls=':', label='experiment (retrace)'),
            Line2D([0],[0], color=PALETTE['blue'], lw=1.0, label='DT trace (PI-fit)'),
            Line2D([0],[0], color=PALETTE['blue'], lw=0.9, ls=':', label='DT retrace (PI-fit)'),
            Line2D([0],[0], color=PALETTE['red'],  lw=1.0, label='DT trace (sub-optimal cond.)'),
        ]
    fig.legend(handles=leg_handles, loc='lower center',
               bbox_to_anchor=(0.5, 0.005), ncol=5, frameon=False,
               fontsize=6.4, handletextpad=0.5, columnspacing=1.2)

    if save_to is not None:
        paths = save_pub(fig, save_to, stem)
        print('Saved Figure 4:', paths['png'])
    return fig
